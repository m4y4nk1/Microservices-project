package com.vw.eacontext.insight.detector;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.jgrapht.Graph;
import org.springframework.stereotype.Component;

import com.vw.eacontext.ai.EntityDisplayNameResolver;
import com.vw.eacontext.config.InsightProperties;
import com.vw.eacontext.graph.RelationshipEdge;
import com.vw.eacontext.insight.Detector;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.FindingType;
import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.validation.Severity;

import lombok.RequiredArgsConstructor;

/** Two or more applications sharing the same name, or two or more rows sharing the same id. */
@Component
@RequiredArgsConstructor
public class DuplicateApplicationDetector implements Detector {

    private final InsightProperties properties;

    @Override
    public List<Finding> detect(CanonicalModel model, Graph<Application, RelationshipEdge> graph) {
        boolean caseSensitive = properties.isDuplicateNameCaseSensitive();
        Map<String, List<Application>> byName = new LinkedHashMap<>();
        for (Application app : model.applications()) {
            if (DetectorSupport.isBlank(app.name())) {
                continue;
            }
            // Collapse incidental whitespace differences (leading/trailing, doubled
            // internal spaces) before grouping, so "CRM Suite" and "CRM  Suite " are
            // still recognized as the same name.
            String normalized = app.name().trim().replaceAll("\\s+", " ");
            String key = caseSensitive ? normalized : normalized.toLowerCase(Locale.ROOT);
            byName.computeIfAbsent(key, k -> new ArrayList<>()).add(app);
        }

        List<Finding> findings = new ArrayList<>();
        byName.forEach((key, apps) -> {
            if (apps.size() > 1) {
                List<String> ids = apps.stream().map(Application::id).toList();
                String[] formatted = EntityDisplayNameResolver.formatAll(model, ids);
                findings.add(new Finding(FindingType.DUPLICATE_APPLICATION, Severity.WARNING, ids,
                        apps.size() + " applications share the name '" + apps.get(0).name() + "': "
                                + String.join(", ", formatted)));
            }
        });

        // A second, distinct case: two or more application ROWS reusing the same
        // ApplicationID (as opposed to the same-name-different-id case above,
        // which still leaves every row in the graph). GraphBuilderService keeps
        // only the first such row and silently drops the rest — only a server
        // log line, no Finding — so a dropped application would otherwise vanish
        // from every diagram and the AI summary with no trace at all.
        Map<String, List<Application>> byId = new LinkedHashMap<>();
        for (Application app : model.applications()) {
            if (!DetectorSupport.isBlank(app.id())) {
                byId.computeIfAbsent(app.id(), k -> new ArrayList<>()).add(app);
            }
        }
        byId.forEach((id, apps) -> {
            if (apps.size() > 1) {
                String names = apps.stream()
                        .map(app -> DetectorSupport.isBlank(app.name()) ? "(unnamed)" : app.name())
                        .collect(Collectors.joining(", "));
                findings.add(new Finding(FindingType.DUPLICATE_APPLICATION, Severity.WARNING, List.of(id),
                        apps.size() + " application rows share the id '" + id + "' (" + names
                                + ") — only the first is kept in every diagram, the rest are silently dropped"));
            }
        });
        return findings;
    }
}
