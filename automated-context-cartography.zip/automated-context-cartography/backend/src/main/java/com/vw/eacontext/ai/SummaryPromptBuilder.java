package com.vw.eacontext.ai;

import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.vw.eacontext.api.SessionModelStore;
import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.graph.GhostReferenceResolver;
import com.vw.eacontext.graph.GhostReferences;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.FindingType;
import com.vw.eacontext.model.CanonicalModel;

/**
 * Builds the user-prompt text shared by every LLM-backed {@link SummaryGenerator}
 * (Azure OpenAI, LLMaaS). Kept in one place because both providers need the same
 * landscape stats, missing-applications listing and finding list — duplicating
 * this per provider risks fixing a bug (or adding a section) in one and not the
 * other, which is exactly what had already happened here.
 */
final class SummaryPromptBuilder {

    private static final GhostReferenceResolver GHOST_REFERENCE_RESOLVER = new GhostReferenceResolver();

    private SummaryPromptBuilder() {
    }

    static String buildUserPrompt(List<Finding> findings, GraphStats stats, SessionModelStore sessionModelStore) {
        List<Finding> safeFindings = findings == null ? List.of() : findings;
        CanonicalModel model = safeModel(sessionModelStore);

        StringBuilder sb = new StringBuilder();
        if (stats != null) {
            sb.append("Landscape statistics:\n")
                    .append("- applications: ").append(stats.applicationCount()).append('\n')
                    .append("- relationships: ").append(stats.relationshipCount()).append('\n')
                    .append("- interfaces: ").append(stats.interfaceCount()).append('\n')
                    .append("- domains: ").append(stats.domainCount()).append('\n')
                    .append("- business processes: ").append(stats.businessProcessCount()).append('\n')
                    .append("- information flows: ").append(stats.informationObjectCount()).append('\n')
                    .append("- hub applications: ").append(stats.hubCount()).append('\n')
                    // Two different numbers, stated separately: cycleCount is the
                    // number of distinct cycles, applicationsInCyclesCount is how
                    // many applications sit in any of them — they differ whenever
                    // one application belongs to more than one cycle.
                    .append("- circular dependency chains: ").append(stats.cycleCount()).append('\n')
                    .append("- applications involved in a circular dependency: ")
                    .append(applicationsInCyclesCount(safeFindings)).append('\n');
            if (stats.mostConnectedApplicationId() != null) {
                sb.append("- most connected application: ")
                        .append(EntityDisplayNameResolver.format(model, stats.mostConnectedApplicationId()))
                        .append(" (in-degree ").append(stats.maxDegree()).append(")\n");
            }
        }

        sb.append("\nMissing applications (referenced but not in the dataset):\n");
        GhostReferences ghosts = model == null ? GhostReferences.none() : GHOST_REFERENCE_RESOLVER.resolve(model);
        if (ghosts.isEmpty()) {
            sb.append("- none\n");
        } else {
            for (String ghostId : new TreeSet<>(ghosts.ids())) {
                String sources = ghosts.sources(ghostId).stream()
                        .sorted()
                        .map(recordId -> EntityDisplayNameResolver.describeGhostReference(model, ghostId, recordId))
                        .collect(Collectors.joining("; "));
                sb.append("- ").append(ghostId).append(" is referenced by ").append(sources)
                        .append(", but has no application record.\n");
            }
        }

        sb.append("\nFindings (type | severity | related entities | message):\n");
        if (safeFindings.isEmpty()) {
            sb.append("- none\n");
        } else {
            for (Finding f : safeFindings) {
                String[] formatted = EntityDisplayNameResolver.formatAll(model, f.relatedEntityIds());
                sb.append("- ").append(f.type()).append(" | ").append(f.severity())
                        .append(" | ").append(Arrays.toString(formatted)).append(" | ").append(f.message()).append('\n');
            }
        }
        sb.append("\nWrite the executive summary now.");
        return sb.toString();
    }

    private static long applicationsInCyclesCount(List<Finding> findings) {
        return findings.stream()
                .filter(f -> f.type() == FindingType.CIRCULAR_DEPENDENCY)
                .flatMap(f -> f.relatedEntityIds().stream())
                .distinct()
                .count();
    }

    private static CanonicalModel safeModel(SessionModelStore sessionModelStore) {
        try {
            return sessionModelStore == null ? null : sessionModelStore.getModel();
        } catch (Exception ignored) {
            return null;
        }
    }
}
