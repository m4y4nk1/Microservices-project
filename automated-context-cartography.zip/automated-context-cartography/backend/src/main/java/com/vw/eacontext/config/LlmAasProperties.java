package com.vw.eacontext.config;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * Configuration for the VW LLMaaS (OpenAI-compatible) summary generator.
 *
 * <p>Bound from {@code ea.ai.llmaas.*}. Secrets should be supplied via
 * environment variables (no committed defaults for secrets).</p>
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "ea.ai.llmaas")
public class LlmAasProperties {

    /** IDP token URL for client-credentials grant. */
    private String tokenUrl;

    /** OAuth2 client id (secret must not be committed). */
    private String clientId;

    /** OAuth2 client secret (sensitive). */
    private String clientSecret;

    /** LLM API key sent in the X-LLM-API-CLIENT-ID header. */
    private String apiKey;

    /** Base URL of the LLMaaS service (e.g. https://... ). */
    private String baseUrl;

    /** Model name to request in the chat-completions call. */
    private String model;

    /** Overall request timeout. */
    private Duration timeout = Duration.ofSeconds(20);

    /** Maximum completion tokens. */
    private int maxTokens = 500;

    /** Sampling temperature (0 = deterministic). */
    private double temperature = 0.2;

    /** System prompt establishing the assistant's role. */
    private String systemPrompt =
            "You are an enterprise architecture analyst. Given landscape statistics and a list of "
                    + "detected findings, write a concise, executive-level summary (max ~8 sentences) "
                    + "highlighting key risks and recommended priorities. Be factual and specific. "
                    + "Only report what the provided statistics and findings actually state — never "
                    + "assert a dependency, relationship, owner, or risk that is not present in the "
                    + "given data.";
}

