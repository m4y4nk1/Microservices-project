package com.vw.eacontext.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.graph.GhostReferenceResolver;
import com.vw.eacontext.graph.GhostReferences;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.FindingType;
import com.vw.eacontext.validation.Severity;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.api.SessionModelStore;

/**
 * A deterministic, template-based {@link SummaryGenerator} that requires no
 * external AI service. It composes a stable, human-readable summary from the
 * findings and graph statistics, guaranteeing the application works before any
 * LLM is wired in.
 *
 * <p>Output is fully deterministic: entity ids within each section are sorted,
 * so the same input always yields the same summary. Sections are separated by
 * a blank line and headed by a short all-caps label (matching the surrounding
 * UI's own section-heading style) — the frontend renders this text with
 * {@code white-space: pre-line}, so structure here directly becomes visual
 * structure on screen, not a wall of run-on text.</p>
 */
public class TemplateSummaryGenerator implements SummaryGenerator {

    private final SessionModelStore sessionModelStore;
    // Stateless with no dependencies of its own, so it's cheaper to own one
    // directly here than to thread it through every constructor/call site that
    // builds a TemplateSummaryGenerator (this class already has two constructors
    // used from several places — see AiConfig, AzureOpenAiSummaryGenerator and
    // LlmAasSummaryGenerator's fallback fields).
    private final GhostReferenceResolver ghostReferenceResolver = new GhostReferenceResolver();

    public TemplateSummaryGenerator() {
        this.sessionModelStore = null;
    }

    public TemplateSummaryGenerator(SessionModelStore sessionModelStore) {
        this.sessionModelStore = sessionModelStore;
    }

    @Override
    public String summarize(List<Finding> findings, GraphStats stats) {
        List<Finding> safeFindings = findings == null ? List.of() : findings;

        List<String> sections = new ArrayList<>();
        sections.add(overviewSection(stats, safeFindings));
        addIfPresent(sections, ghostsSection());
        addIfPresent(sections, findingsSection(safeFindings));
        addIfPresent(sections, keyMetricsSection(stats));
        return String.join("\n\n", sections);
    }

    private static void addIfPresent(List<String> sections, String section) {
        if (section != null && !section.isBlank()) {
            sections.add(section);
        }
    }

    private String overviewSection(GraphStats stats, List<Finding> findings) {
        StringBuilder sb = new StringBuilder("OVERVIEW\n");
        if (stats == null) {
            sb.append("Analyzed the EA landscape.\n");
        } else {
            sb.append(String.format(
                    "Analyzed %d application(s) across %d domain(s) and %d business process(es), "
                            + "connected by %d relationship(s) and %d interface(s); %d information flow(s) tracked.%n",
                    stats.applicationCount(), stats.domainCount(), stats.businessProcessCount(),
                    stats.relationshipCount(), stats.interfaceCount(), stats.informationObjectCount()));
        }
        if (findings.isEmpty()) {
            sb.append("No issues were detected.");
        } else {
            long errors = findings.stream().filter(f -> f.severity() == Severity.ERROR).count();
            long warnings = findings.stream().filter(f -> f.severity() == Severity.WARNING).count();
            long infos = findings.stream().filter(f -> f.severity() == Severity.INFO).count();
            sb.append(String.format("Detected %d issue(s): %d error(s), %d warning(s), %d informational.",
                    findings.size(), errors, warnings, infos));
        }
        return sb.toString();
    }

    /**
     * Enumerates application ids records reference but which have no
     * application row at all — invisible from the findings list alone, since
     * broken-reference detectors report the referencing record, not a
     * consolidated "these ids don't exist" view.
     */
    private String ghostsSection() {
        CanonicalModel model = safeModel();
        if (model == null) {
            return null;
        }
        GhostReferences ghosts = ghostReferenceResolver.resolve(model);
        if (ghosts.isEmpty()) {
            return null;
        }
        StringBuilder sb = new StringBuilder("MISSING APPLICATIONS\n");
        List<String> lines = new ArrayList<>();
        for (String ghostId : new TreeSet<>(ghosts.ids())) {
            String sources = ghosts.sources(ghostId).stream()
                    .sorted()
                    .map(recordId -> EntityDisplayNameResolver.describeGhostReference(model, ghostId, recordId))
                    .collect(Collectors.joining("; "));
            lines.add(String.format("- %s is referenced by %s, but has no application record.", ghostId, sources));
        }
        sb.append(String.join("\n", lines));
        return sb.toString();
    }

    /** Every non-empty finding-category line, under one "FINDINGS BY CATEGORY" heading. */
    private String findingsSection(List<Finding> findings) {
        List<String> lines = new ArrayList<>();
        addIfPresent(lines, sectionLine(findings, "Hubs (single points of failure)", "application(s)",
                FindingType.HUB));
        addIfPresent(lines, circularDependencyLine(findings));
        addIfPresent(lines, sectionLine(findings, "Broken references", "record(s)",
                FindingType.BROKEN_RELATIONSHIP_REFERENCE, FindingType.DANGLING_INTERFACE_CONSUMER,
                FindingType.BROKEN_INFORMATION_FLOW_REFERENCE, FindingType.UNMAPPED_PROCESS_APPLICATION));
        addIfPresent(lines, sectionLine(findings, "Duplicate applications", "application(s)",
                FindingType.DUPLICATE_APPLICATION));
        addIfPresent(lines, sectionLine(findings, "Orphan applications", "application(s)",
                FindingType.ORPHAN_APPLICATION));
        addIfPresent(lines, sectionLine(findings, "Ownership gaps", "record(s)",
                FindingType.OWNERSHIP_RECORD_MISSING, FindingType.OWNERSHIP_PARTIAL_GAP,
                FindingType.MISSING_OWNER_FIELD));
        addIfPresent(lines, sectionLine(findings, "Lifecycle risks", "record(s)",
                FindingType.LIFECYCLE_RISK_CRITICAL_PROCESS, FindingType.LIFECYCLE_RISK_EOL_PROVIDER,
                FindingType.LIFECYCLE_INCONSISTENCY, FindingType.PHASE_OUT_CRITICAL_PATH));
        addIfPresent(lines, sectionLine(findings, "Deprecated interfaces still in use", "flow(s)",
                FindingType.DEPRECATED_INTERFACE_IN_USE));
        addIfPresent(lines, sectionLine(findings, "Interfaces without a relationship", "interface(s)",
                FindingType.INTERFACE_WITHOUT_RELATIONSHIP));
        addIfPresent(lines, sectionLine(findings, "Sensitive data over insecure flows", "flow(s)",
                FindingType.SENSITIVE_DATA_INSECURE_FLOW));
        if (lines.isEmpty()) {
            return null;
        }
        return "FINDINGS BY CATEGORY\n" + String.join("\n", lines);
    }

    private String sectionLine(List<Finding> findings, String title, String noun, FindingType... types) {
        Set<FindingType> typeSet = Set.of(types);
        List<Finding> matching = findings.stream().filter(f -> typeSet.contains(f.type())).toList();
        if (matching.isEmpty()) {
            return null;
        }
        List<String> ids = matching.stream()
                .flatMap(f -> f.relatedEntityIds().stream())
                .distinct()
                .sorted()
                .toList();
        String[] formatted = formattedIds(ids);
        return String.format("- %s: %d finding(s) touching %s (%s).",
                title, matching.size(), noun, String.join(", ", formatted));
    }

    /**
     * Circular dependencies get their own line rather than going through the
     * generic {@link #sectionLine} helper: the number of distinct cycles and
     * the number of distinct applications spread across them are two different
     * counts (one application can sit in more than one cycle) that must both be
     * stated explicitly, or a reader conflates "N cycles" with "N applications."
     */
    private String circularDependencyLine(List<Finding> findings) {
        List<Finding> cycles = findings.stream().filter(f -> f.type() == FindingType.CIRCULAR_DEPENDENCY).toList();
        if (cycles.isEmpty()) {
            return null;
        }
        List<String> appIds = cycles.stream()
                .flatMap(f -> f.relatedEntityIds().stream())
                .distinct()
                .sorted()
                .toList();
        String[] formatted = formattedIds(appIds);
        return String.format("- Circular dependencies: %d cycle(s) detected, involving %d application(s) in total: %s.",
                cycles.size(), appIds.size(), String.join(", ", formatted));
    }

    private String keyMetricsSection(GraphStats stats) {
        if (stats == null) {
            return null;
        }
        List<String> lines = new ArrayList<>();
        if (stats.mostConnectedApplicationId() != null) {
            lines.add(String.format("- Most connected application: %s (in-degree %d).",
                    formattedId(stats.mostConnectedApplicationId()), stats.maxDegree()));
        }
        if (stats.hubCount() > 0) {
            lines.add(String.format("- %d hub application(s) exceed the dependency threshold.", stats.hubCount()));
        }
        if (stats.cycleCount() > 0) {
            lines.add(String.format("- %d circular dependency chain(s) detected.", stats.cycleCount()));
        }
        if (stats.orphanCount() > 0) {
            lines.add(String.format("- %d application(s) are orphaned (not referenced anywhere).", stats.orphanCount()));
        }
        if (lines.isEmpty()) {
            return null;
        }
        return "KEY METRICS\n" + String.join("\n", lines);
    }

    private CanonicalModel safeModel() {
        try {
            return sessionModelStore == null ? null : sessionModelStore.getModel();
        } catch (Exception ignored) {
            return null;
        }
    }

    private String formattedId(String id) {
        return EntityDisplayNameResolver.format(safeModel(), id);
    }

    private String[] formattedIds(List<String> ids) {
        return EntityDisplayNameResolver.formatAll(safeModel(), ids);
    }
}
