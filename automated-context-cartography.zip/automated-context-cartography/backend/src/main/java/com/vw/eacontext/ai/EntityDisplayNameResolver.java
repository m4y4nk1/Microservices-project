package com.vw.eacontext.ai;

import java.util.List;

import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.ApplicationOwnership;
import com.vw.eacontext.model.BusinessProcess;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Interface;
import com.vw.eacontext.model.InformationObject;
import com.vw.eacontext.model.ProcessMapping;
import com.vw.eacontext.model.Relationship;

/**
 * Helper to resolve an entity identifier to a human-friendly display name.
 *
 * <p>Given the canonical model, returns a string of the form "Name (ID)" when
 * the identifier is known, or "Unknown entity (ID)" when it cannot be
 * resolved. Domains are represented by their raw value as the name.</p>
 */
public final class EntityDisplayNameResolver {

    private EntityDisplayNameResolver() {}

    public static String format(CanonicalModel model, String id) {
        if (id == null) return "Unknown entity (null)";
        if (model != null) {
            // Applications
            for (Application app : model.applications()) {
                if (id.equals(app.id())) return safe(app.name()) + " (" + id + ")";
            }
            // Business processes
            for (BusinessProcess bp : model.businessProcesses()) {
                if (id.equals(bp.id())) return safe(bp.name()) + " (" + id + ")";
            }
            // Interfaces
            for (Interface ifc : model.interfaces()) {
                if (id.equals(ifc.id())) return safe(ifc.name()) + " (" + id + ")";
            }
            // Information objects / flows
            for (InformationObject io : model.informationObjects()) {
                if (id.equals(io.id())) return safe(io.informationObject()) + " (" + id + ")";
            }
            // Domains: domain nodes are represented as raw businessDomain values
            for (Application app : model.applications()) {
                if (id.equals(app.businessDomain())) return safe(app.businessDomain()) + " (" + id + ")";
            }
            // Junction/fact records (relationships, process mappings, ownership
            // records) have no name of their own — a finding's relatedEntityIds
            // often mixes one of these in alongside genuine entity ids (e.g. the
            // relationship's own id next to the application id it references).
            // These are real, existing records, so "Unknown entity" would be
            // actively misleading; describe them by their own kind instead.
            for (Relationship r : model.relationships()) {
                if (id.equals(r.id())) return "Relationship " + id;
            }
            for (ProcessMapping pm : model.processMappings()) {
                if (id.equals(pm.id())) return "Process mapping " + id;
            }
            for (ApplicationOwnership o : model.applicationOwnerships()) {
                if (id.equals(o.id())) return "Ownership record " + id;
            }
        }
        return "Unknown entity (" + id + ")";
    }

    public static String[] formatAll(CanonicalModel model, List<String> ids) {
        return ids.stream().map(id -> format(model, id)).toArray(String[]::new);
    }

    /**
     * Describes the record {@code recordId} in one short readable clause, for use
     * when explaining why a ghost application id is unresolved (see
     * {@code GhostReferenceResolver}). Names the record's other endpoint relative
     * to {@code ghostId} where one exists (e.g. "relationship REL-0065 from Order
     * Management System (APP-0005)"); falls back to the bare record id when it
     * can't be found in the model at all (should not normally happen, since the
     * id always comes from a record actually walked while resolving ghosts).
     */
    public static String describeGhostReference(CanonicalModel model, String ghostId, String recordId) {
        if (model == null || recordId == null) {
            return String.valueOf(recordId);
        }
        for (Relationship r : model.relationships()) {
            if (recordId.equals(r.id())) {
                String other = ghostId.equals(r.targetApplicationId()) ? r.sourceApplicationId() : r.targetApplicationId();
                return "relationship " + recordId + " from " + format(model, other);
            }
        }
        for (Interface i : model.interfaces()) {
            if (recordId.equals(i.id())) {
                String other = ghostId.equals(i.consumerApplicationId()) ? i.providerApplicationId() : i.consumerApplicationId();
                return "interface " + recordId + " (" + safe(i.name()) + ") from " + format(model, other);
            }
        }
        for (InformationObject io : model.informationObjects()) {
            if (recordId.equals(io.id())) {
                String other = ghostId.equals(io.targetApplicationId()) ? io.sourceApplicationId() : io.targetApplicationId();
                return "information flow " + recordId + " (" + safe(io.informationObject()) + ") from " + format(model, other);
            }
        }
        for (ProcessMapping pm : model.processMappings()) {
            if (recordId.equals(pm.id())) {
                return "process mapping " + recordId + " for business process " + format(model, pm.businessProcessId());
            }
        }
        for (ApplicationOwnership o : model.applicationOwnerships()) {
            if (recordId.equals(o.id())) {
                return "ownership record " + recordId;
            }
        }
        return recordId;
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }
}

