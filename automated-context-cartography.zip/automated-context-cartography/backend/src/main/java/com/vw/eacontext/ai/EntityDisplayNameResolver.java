package com.vw.eacontext.ai;

import java.util.List;

import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.BusinessProcess;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Interface;
import com.vw.eacontext.model.InformationObject;

/**
 * Helper to resolve an entity identifier to a human-friendly display name.
 *
 * <p>Given the canonical model, returns a string of the form "Name (ID)" when
 * the identifier is known, or "Unknown entity (ID)" when it cannot be
 * resolved. Domains are represented by their raw value as the name.</p>
 */
public final class EntityDisplayNameResolver {

    private EntityDisplayNameResolver() {}

    public static String format(CanonicalModel model, String id) {
        if (id == null) return "Unknown entity (null)";
        if (model != null) {
            // Applications
            for (Application app : model.applications()) {
                if (id.equals(app.id())) return safe(app.name()) + " (" + id + ")";
            }
            // Business processes
            for (BusinessProcess bp : model.businessProcesses()) {
                if (id.equals(bp.id())) return safe(bp.name()) + " (" + id + ")";
            }
            // Interfaces
            for (Interface ifc : model.interfaces()) {
                if (id.equals(ifc.id())) return safe(ifc.name()) + " (" + id + ")";
            }
            // Information objects / flows
            for (InformationObject io : model.informationObjects()) {
                if (id.equals(io.id())) return safe(io.informationObject()) + " (" + id + ")";
            }
            // Domains: domain nodes are represented as raw businessDomain values
            for (Application app : model.applications()) {
                if (id.equals(app.businessDomain())) return safe(app.businessDomain()) + " (" + id + ")";
            }
        }
        return "Unknown entity (" + id + ")";
    }

    public static String[] formatAll(CanonicalModel model, List<String> ids) {
        return ids.stream().map(id -> format(model, id)).toArray(String[]::new);
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }
}

