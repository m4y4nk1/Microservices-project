package com.vw.eacontext.ai;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicReference;

import org.springframework.http.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.vw.eacontext.config.LlmAasProperties;

import lombok.extern.slf4j.Slf4j;

/**
 * Simple in-memory token cache for LLMaaS OAuth2 client-credentials tokens.
 */
@Slf4j
@Service
public class LlmAasTokenService {

    private final LlmAasProperties properties;
    private final WebClient webClient;

    private static class Token {
        final String accessToken;
        final Instant expiresAt;

        Token(String accessToken, Instant expiresAt) {
            this.accessToken = accessToken;
            this.expiresAt = expiresAt;
        }
    }

    private final AtomicReference<Token> cached = new AtomicReference<>();

    @Autowired
    public LlmAasTokenService(LlmAasProperties properties) {
        this(properties, WebClient.builder().build());
    }

    // No-arg constructor present to satisfy some tooling; real wiring uses the
    // @Autowired constructor above.
    public LlmAasTokenService() {
        this(null, WebClient.builder().build());
    }

    // Visible for testing
    LlmAasTokenService(LlmAasProperties properties, WebClient webClient) {
        this.properties = properties;
        this.webClient = webClient;
    }

    /**
     * Return a valid access token, refreshing it if nearing expiry.
     */
    public synchronized String getAccessToken() {
        Token t = cached.get();
        Instant now = Instant.now();
        if (t != null && now.isBefore(t.expiresAt.minusSeconds(30))) {
            return t.accessToken;
        }

        // Need to request a new token
        try {
            JsonNode resp = webClient.post()
                    .uri(properties.getTokenUrl())
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(BodyInserters.fromFormData("grant_type", "client_credentials")
                            .with("client_id", properties.getClientId() == null ? "" : properties.getClientId())
                            .with("client_secret", properties.getClientSecret() == null ? "" : properties.getClientSecret()))
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .timeout(properties.getTimeout())
                    .block();

            if (resp == null || resp.path("access_token").isMissingNode()) {
                throw new IllegalStateException("token response missing access_token");
            }
            String accessToken = resp.path("access_token").asText();
            long expiresIn = resp.path("expires_in").asLong(300);
            Instant expiresAt = Instant.now().plusSeconds(Math.max(60, expiresIn));
            Token newToken = new Token(accessToken, expiresAt);
            cached.set(newToken);
            return accessToken;
        } catch (Exception e) {
            log.warn("Failed to obtain LLMaaS access token: {}", e.toString());
            throw e;
        }
    }
}

