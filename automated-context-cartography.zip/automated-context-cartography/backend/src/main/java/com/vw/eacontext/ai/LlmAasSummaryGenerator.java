package com.vw.eacontext.ai;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.vw.eacontext.config.LlmAasProperties;
import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.api.SessionModelStore;
import com.vw.eacontext.ai.EntityDisplayNameResolver;

import lombok.extern.slf4j.Slf4j;

/**
 * An {@link SummaryGenerator} that calls the VW LLMaaS chat-completions endpoint.
 *
 * <p>Active under the {@code ai} profile and selected when
 * {@code ea.ai.provider=llmaas} (default).</p>
 */
@Slf4j
@Component
@Primary
@ConditionalOnProperty(name = "ea.ai.provider", havingValue = "llmaas", matchIfMissing = true)
@Profile("ai")
public class LlmAasSummaryGenerator implements SummaryGenerator {

    private final LlmAasProperties properties;
    private final WebClient webClient;
    private final LlmAasTokenService tokenService;
    private final SessionModelStore sessionModelStore;
    private final SummaryGenerator fallback;

    @Autowired
    public LlmAasSummaryGenerator(LlmAasProperties properties, LlmAasTokenService tokenService,
                                  SessionModelStore sessionModelStore) {
        this(properties, WebClient.builder().build(), tokenService, sessionModelStore);
    }

    // Backwards-compatible constructor used by some tests which predate SessionModelStore
    public LlmAasSummaryGenerator(LlmAasProperties properties, LlmAasTokenService tokenService) {
        this(properties, WebClient.builder().build(), tokenService, null);
    }

    // Visible for testing
    LlmAasSummaryGenerator(LlmAasProperties properties, WebClient webClient, LlmAasTokenService tokenService,
                           SessionModelStore sessionModelStore) {
        this.properties = properties;
        this.webClient = webClient;
        this.tokenService = tokenService;
        this.sessionModelStore = sessionModelStore;
        this.fallback = new TemplateSummaryGenerator(sessionModelStore);
    }

    @Override
    public String summarize(List<Finding> findings, GraphStats stats) {
        try {
            log.info("Calling LLMaaS chat-completions provider (model={}) to generate summary", properties.getModel());

            String accessToken = tokenService.getAccessToken();

            String base = properties.getBaseUrl() == null ? "" : properties.getBaseUrl().replaceAll("/+$", "");
            String url = base + "/chat/completions";

            JsonNode response = webClient.post()
                    .uri(url)
                    .header("Authorization", "Bearer " + accessToken)
                    .header("X-LLM-API-CLIENT-ID", "Bearer " + (properties.getApiKey() == null ? "" : properties.getApiKey()))
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(buildRequestBody(findings, stats))
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .timeout(properties.getTimeout())
                    .block();

            String content = extractContent(response);
            if (content == null || content.isBlank()) {
                throw new IllegalStateException("LLMaaS returned an empty completion");
            }
            String trimmed = content.trim();
            log.info("LLMaaS produced summary ({} chars); returning LLM result", trimmed.length());
            return trimmed;
        } catch (Exception e) {
            log.warn("LLMaaS summary failed ({}); falling back to template summary", e.toString());
            log.debug("LLMaaS failure details", e);
            return fallback.summarize(findings, stats);
        }
    }

    private Map<String, Object> buildRequestBody(List<Finding> findings, GraphStats stats) {
        return Map.of(
                "model", properties.getModel(),
                "messages", List.of(
                        Map.of("role", "system", "content", properties.getSystemPrompt()),
                        Map.of("role", "user", "content", buildUserPrompt(findings, stats))),
                "temperature", properties.getTemperature(),
                "max_tokens", properties.getMaxTokens());
    }

    // Reuse same prompt building as Azure implementation
    private String buildUserPrompt(List<Finding> findings, GraphStats stats) {
        StringBuilder sb = new StringBuilder();
        CanonicalModel model = null;
        try { model = sessionModelStore.getModel(); } catch (Exception ignored) {}

        if (stats != null) {
            sb.append("Landscape statistics:\n")
                    .append("- applications: ").append(stats.applicationCount()).append('\n')
                    .append("- relationships: ").append(stats.relationshipCount()).append('\n')
                    .append("- interfaces: ").append(stats.interfaceCount()).append('\n')
                    .append("- domains: ").append(stats.domainCount()).append('\n')
                    .append("- business processes: ").append(stats.businessProcessCount()).append('\n')
                    .append("- information flows: ").append(stats.informationObjectCount()).append('\n')
                    .append("- hub applications: ").append(stats.hubCount()).append('\n')
                    .append("- circular dependency chains: ").append(stats.cycleCount()).append('\n');
            if (stats.mostConnectedApplicationId() != null) {
                sb.append("- most connected application: ")
                        .append(EntityDisplayNameResolver.format(model, stats.mostConnectedApplicationId()))
                        .append(" (in-degree ").append(stats.maxDegree()).append(")\n");
            }
        }
        sb.append("\nFindings (type | severity | related entities | message):\n");
        if (findings == null || findings.isEmpty()) {
            sb.append("- none\n");
        } else {
            for (Finding f : findings) {
                String[] formatted = EntityDisplayNameResolver.formatAll(model, f.relatedEntityIds());
                sb.append("- ").append(f.type()).append(" | ").append(f.severity())
                        .append(" | ").append(java.util.Arrays.toString(formatted)).append(" | ").append(f.message()).append('\n');
            }
        }
        sb.append("\nWrite the executive summary now.");
        return sb.toString();
    }

    private String extractContent(JsonNode response) {
        if (response == null) {
            return null;
        }
        JsonNode choices = response.path("choices");
        if (!choices.isArray() || choices.isEmpty()) {
            return null;
        }
        return choices.get(0).path("message").path("content").asText(null);
    }
}

