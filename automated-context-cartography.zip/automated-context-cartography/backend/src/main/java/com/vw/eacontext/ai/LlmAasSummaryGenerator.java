package com.vw.eacontext.ai;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.vw.eacontext.config.LlmAasProperties;
import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.api.SessionModelStore;

import lombok.extern.slf4j.Slf4j;

/**
 * An {@link SummaryGenerator} that calls the VW LLMaaS chat-completions endpoint.
 *
 * <p>Active under the {@code ai} profile and selected when
 * {@code ea.ai.provider=llmaas} (default).</p>
 */
@Slf4j
@Component
@Primary
@ConditionalOnProperty(name = "ea.ai.provider", havingValue = "llmaas", matchIfMissing = true)
@Profile("ai")
public class LlmAasSummaryGenerator implements SummaryGenerator {

    private final LlmAasProperties properties;
    private final WebClient webClient;
    private final LlmAasTokenService tokenService;
    private final SessionModelStore sessionModelStore;
    private final SummaryGenerator fallback;

    @Autowired
    public LlmAasSummaryGenerator(LlmAasProperties properties, LlmAasTokenService tokenService,
                                  SessionModelStore sessionModelStore) {
        this(properties, WebClient.builder().build(), tokenService, sessionModelStore);
    }

    // Backwards-compatible constructor used by some tests which predate SessionModelStore
    public LlmAasSummaryGenerator(LlmAasProperties properties, LlmAasTokenService tokenService) {
        this(properties, WebClient.builder().build(), tokenService, null);
    }

    // Visible for testing
    LlmAasSummaryGenerator(LlmAasProperties properties, WebClient webClient, LlmAasTokenService tokenService,
                           SessionModelStore sessionModelStore) {
        this.properties = properties;
        this.webClient = webClient;
        this.tokenService = tokenService;
        this.sessionModelStore = sessionModelStore;
        this.fallback = new TemplateSummaryGenerator(sessionModelStore);
    }

    @Override
    public String summarize(List<Finding> findings, GraphStats stats) {
        try {
            log.info("Calling LLMaaS chat-completions provider (model={}) to generate summary", properties.getModel());

            String accessToken = tokenService.getAccessToken();

            String base = properties.getBaseUrl() == null ? "" : properties.getBaseUrl().replaceAll("/+$", "");
            String url = base + "/chat/completions";

            JsonNode response = webClient.post()
                    .uri(url)
                    .header("Authorization", "Bearer " + accessToken)
                    .header("X-LLM-API-CLIENT-ID", "Bearer " + (properties.getApiKey() == null ? "" : properties.getApiKey()))
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(buildRequestBody(findings, stats))
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .timeout(properties.getTimeout())
                    .block();

            String content = extractContent(response);
            if (content == null || content.isBlank()) {
                throw new IllegalStateException("LLMaaS returned an empty completion");
            }
            String trimmed = content.trim();
            log.info("LLMaaS produced summary ({} chars); returning LLM result", trimmed.length());
            return trimmed;
        } catch (Exception e) {
            log.warn("LLMaaS summary failed ({}); falling back to template summary", e.toString());
            log.debug("LLMaaS failure details", e);
            return fallback.summarize(findings, stats);
        }
    }

    private Map<String, Object> buildRequestBody(List<Finding> findings, GraphStats stats) {
        return Map.of(
                "model", properties.getModel(),
                "messages", List.of(
                        Map.of("role", "system", "content", properties.getSystemPrompt()),
                        Map.of("role", "user", "content", buildUserPrompt(findings, stats))),
                "temperature", properties.getTemperature(),
                "max_tokens", properties.getMaxTokens());
    }

    private String buildUserPrompt(List<Finding> findings, GraphStats stats) {
        return SummaryPromptBuilder.buildUserPrompt(findings, stats, sessionModelStore);
    }

    private String extractContent(JsonNode response) {
        if (response == null) {
            return null;
        }
        JsonNode choices = response.path("choices");
        if (!choices.isArray() || choices.isEmpty()) {
            return null;
        }
        return choices.get(0).path("message").path("content").asText(null);
    }
}

