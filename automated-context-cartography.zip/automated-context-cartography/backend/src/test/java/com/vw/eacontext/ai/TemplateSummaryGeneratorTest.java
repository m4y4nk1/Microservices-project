package com.vw.eacontext.ai;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.vw.eacontext.api.SessionModelStore;
import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.FindingType;
import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.DependencyCriticality;
import com.vw.eacontext.model.Relationship;
import com.vw.eacontext.model.RelationshipType;
import com.vw.eacontext.validation.Severity;

class TemplateSummaryGeneratorTest {

    // No SessionModelStore: EntityDisplayNameResolver has no model to resolve
    // against, so every id falls back to "Unknown entity (ID)". That's the
    // correct, working behaviour for this constructor (used wherever no model
    // is available, e.g. the Azure/LLMaaS providers' fallback before any
    // dataset has been uploaded) — this class's own tests exercise that path
    // deliberately, alongside a second, model-backed instance below for the
    // name-resolution and ghost-listing behaviour.
    private final SummaryGenerator generator = new TemplateSummaryGenerator();

    private static final GraphStats STATS = GraphStats.builder()
            .applicationCount(12)
            .relationshipCount(12)
            .interfaceCount(6)
            .domainCount(5)
            .businessProcessCount(3)
            .informationObjectCount(5)
            .mostConnectedApplicationId("APP-OMS")
            .maxDegree(7)
            .hubCount(1)
            .cycleCount(1)
            .orphanCount(1)
            .build();

    private static final List<Finding> FINDINGS = List.of(
            new Finding(FindingType.HUB, Severity.ERROR, List.of("APP-OMS"), "x"),
            new Finding(FindingType.OWNERSHIP_RECORD_MISSING, Severity.WARNING, List.of("APP-ERP"), "x"),
            new Finding(FindingType.OWNERSHIP_RECORD_MISSING, Severity.WARNING, List.of("APP-DUPLICATE-B"), "x"),
            new Finding(FindingType.LIFECYCLE_INCONSISTENCY, Severity.WARNING, List.of("APP-INCONSISTENT"), "x"),
            new Finding(FindingType.ORPHAN_APPLICATION, Severity.WARNING, List.of("APP-ORPHAN"), "x"),
            new Finding(FindingType.CIRCULAR_DEPENDENCY, Severity.ERROR,
                    List.of("APP-OMS", "APP-ERP", "APP-INCONSISTENT"), "x"));

    @Test
    void producesDeterministicOutput() {
        String first = generator.summarize(FINDINGS, STATS);
        String second = generator.summarize(FINDINGS, STATS);
        assertThat(first).isEqualTo(second);
    }

    @Test
    void includesOverviewTotalsAndSections() {
        String summary = generator.summarize(FINDINGS, STATS);

        assertThat(summary)
                .contains("Analyzed 12 application(s) across 5 domain(s) and 3 business process(es)")
                .contains("connected by 12 relationship(s) and 6 interface(s); 5 information flow(s) tracked.")
                .contains("Detected 6 issue(s): 2 error(s), 4 warning(s), 0 informational.")
                .contains("Hubs (single points of failure): 1 finding(s) touching application(s) (Unknown entity (APP-OMS)).")
                .contains("Ownership gaps: 2 finding(s) touching record(s) (Unknown entity (APP-DUPLICATE-B), Unknown entity (APP-ERP)).")
                .contains("Lifecycle risks: 1 finding(s) touching record(s) (Unknown entity (APP-INCONSISTENT)).")
                .contains("Orphan applications: 1 finding(s) touching application(s) (Unknown entity (APP-ORPHAN)).")
                .contains("Most connected application: Unknown entity (APP-OMS) (in-degree 7).")
                .contains("1 hub application(s) exceed the dependency threshold.")
                .contains("1 circular dependency chain(s) detected.")
                .contains("1 application(s) are orphaned");
    }

    /**
     * The frontend renders this text with `white-space: pre-line` (so newlines
     * become visible line breaks) rather than parsing any markup — readability
     * depends entirely on this method's own structure: distinct all-caps
     * section headings, each section's lines grouped together, and a blank
     * line between sections (a bare "\n\n", the one separator pre-line
     * actually renders as visible space between paragraphs).
     */
    @Test
    void groupsOutputIntoHeadedSectionsSeparatedByBlankLines() {
        String summary = generator.summarize(FINDINGS, STATS);

        List<String> headings = List.of("OVERVIEW", "FINDINGS BY CATEGORY", "KEY METRICS");
        int previousIndex = -1;
        for (String heading : headings) {
            int index = summary.indexOf(heading);
            assertThat(index).as("missing heading: %s", heading).isGreaterThan(previousIndex);
            previousIndex = index;
        }
        assertThat(summary).contains("\n\n");
        // Every category finding lives under one heading, not scattered loose.
        assertThat(summary.indexOf("Hubs (single points of failure)"))
                .isGreaterThan(summary.indexOf("FINDINGS BY CATEGORY"));
        assertThat(summary.indexOf("Most connected application"))
                .isGreaterThan(summary.indexOf("KEY METRICS"));
    }

    @Test
    void ownershipIdsAreSortedForDeterminism() {
        List<Finding> unordered = List.of(
                new Finding(FindingType.OWNERSHIP_RECORD_MISSING, Severity.WARNING, List.of("APP-DUPLICATE-B"), "x"),
                new Finding(FindingType.OWNERSHIP_RECORD_MISSING, Severity.WARNING, List.of("APP-ERP"), "x"));
        String summary = generator.summarize(unordered, STATS);
        assertThat(summary).contains("(Unknown entity (APP-DUPLICATE-B), Unknown entity (APP-ERP))");
    }

    @Test
    void handlesNoFindings() {
        String summary = generator.summarize(List.of(), STATS);
        assertThat(summary).contains("No issues were detected.");
    }

    /**
     * Circular dependencies must state the cycle count and the distinct
     * application count separately — one application can sit in more than one
     * cycle, so the two numbers are not interchangeable (see
     * TemplateSummaryGenerator.appendCircularDependencies).
     */
    @Test
    void circularDependencySectionDistinguishesCycleCountFromApplicationCount() {
        // Two disjoint 3-app cycles: 2 cycles, but 6 distinct applications total.
        List<Finding> twoCycles = List.of(
                new Finding(FindingType.CIRCULAR_DEPENDENCY, Severity.ERROR,
                        List.of("APP-A", "APP-B", "APP-C"), "x"),
                new Finding(FindingType.CIRCULAR_DEPENDENCY, Severity.ERROR,
                        List.of("APP-D", "APP-E", "APP-F"), "x"));
        String summary = generator.summarize(twoCycles, STATS);
        assertThat(summary).contains("Circular dependencies: 2 cycle(s) detected, involving 6 application(s) in total:");

        // Two overlapping cycles sharing one application: still 2 cycles, but
        // only 5 distinct applications - the number a reader could otherwise
        // mistake for "2".
        List<Finding> overlapping = List.of(
                new Finding(FindingType.CIRCULAR_DEPENDENCY, Severity.ERROR,
                        List.of("APP-A", "APP-B", "APP-C"), "x"),
                new Finding(FindingType.CIRCULAR_DEPENDENCY, Severity.ERROR,
                        List.of("APP-C", "APP-D", "APP-E"), "x"));
        String overlappingSummary = generator.summarize(overlapping, STATS);
        assertThat(overlappingSummary).contains("Circular dependencies: 2 cycle(s) detected, involving 5 application(s) in total:");
    }

    @Test
    void listsMissingApplicationsWhenAModelIsAvailable() {
        CanonicalModel model = CanonicalModel.builder()
                .applications(List.of(
                        Application.builder().id("APP-A").name("Order Management System").build()))
                .relationships(List.of(Relationship.builder()
                        .id("REL-1").sourceApplicationId("APP-A").targetApplicationId("APP-GHOST")
                        .relationshipType(RelationshipType.DEPENDS_ON)
                        .dependencyCriticality(DependencyCriticality.HIGH).build()))
                .build();
        SummaryGenerator modelBackedGenerator = new TemplateSummaryGenerator(fixedModelStore(model));

        String summary = modelBackedGenerator.summarize(List.of(), STATS);

        assertThat(summary)
                .contains("MISSING APPLICATIONS")
                .contains("APP-GHOST is referenced by relationship REL-1 from Order Management System (APP-A)");
    }

    @Test
    void omitsMissingApplicationsSectionWhenThereAreNoGhosts() {
        CanonicalModel model = CanonicalModel.builder()
                .applications(List.of(Application.builder().id("APP-A").name("Order Management System").build()))
                .build();
        SummaryGenerator modelBackedGenerator = new TemplateSummaryGenerator(fixedModelStore(model));

        String summary = modelBackedGenerator.summarize(List.of(), STATS);

        assertThat(summary).doesNotContain("MISSING APPLICATIONS");
    }

    /**
     * A {@link SessionModelStore} that always returns {@code model} from
     * {@link SessionModelStore#getModel()} without touching any of its other
     * state — the three constructor dependencies are never invoked by that one
     * overridden method, so passing {@code null} for them is safe here.
     */
    private static SessionModelStore fixedModelStore(CanonicalModel model) {
        return new SessionModelStore(null, null, null) {
            @Override
            public CanonicalModel getModel() {
                return model;
            }
        };
    }
}
