package com.vw.eacontext.graph;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.jgrapht.Graph;
import org.junit.jupiter.api.Test;

import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.DependencyCriticality;
import com.vw.eacontext.model.Relationship;
import com.vw.eacontext.model.RelationshipType;

class CycleDetectionServiceTest {

    private final CycleDetectionService cycleDetectionService = new CycleDetectionService();
    private final GraphBuilderService graphBuilderService = new GraphBuilderService();

    @Test
    void findsASimpleThreeApplicationCycle() {
        CanonicalModel model = CanonicalModel.builder()
                .applications(List.of(app("A"), app("B"), app("C")))
                .relationships(List.of(
                        dependency("REL-1", "A", "B"),
                        dependency("REL-2", "B", "C"),
                        dependency("REL-3", "C", "A")))
                .build();

        List<List<String>> cycles = cycleDetectionService.findCycles(graphBuilderService.build(model));

        assertThat(cycles).hasSize(1);
        assertThat(cycles.get(0)).containsExactlyInAnyOrder("A", "B", "C");
    }

    /**
     * GraphBuilderService deliberately builds a pseudograph so several
     * relationship rows between the same ordered pair are supported (parallel
     * edges) — but JohnsonSimpleCycles refuses to run on a graph with parallel
     * edges at all, throwing IllegalArgumentException. A dataset with both a
     * cycle and a duplicated relationship pair anywhere (a realistic case the
     * README of a hackathon-style EA dataset explicitly anticipates judges
     * adding) must not make the entire upload fail.
     */
    @Test
    void toleratesParallelEdgesAlongsideACycle() {
        CanonicalModel model = CanonicalModel.builder()
                .applications(List.of(app("A"), app("B"), app("C")))
                .relationships(List.of(
                        dependency("REL-1", "A", "B"),
                        dependency("REL-1B", "A", "B"), // parallel edge: same ordered pair as REL-1
                        dependency("REL-2", "B", "C"),
                        dependency("REL-3", "C", "A")))
                .build();

        Graph<Application, RelationshipEdge> graph = graphBuilderService.build(model);
        assertThat(graph.edgeSet()).hasSize(4); // the pseudograph itself still keeps both parallel edges

        List<List<String>> cycles = cycleDetectionService.findCycles(graph);

        assertThat(cycles).hasSize(1);
        assertThat(cycles.get(0)).containsExactlyInAnyOrder("A", "B", "C");
    }

    @Test
    void returnsEmptyForAnAcyclicGraph() {
        CanonicalModel model = CanonicalModel.builder()
                .applications(List.of(app("A"), app("B")))
                .relationships(List.of(dependency("REL-1", "A", "B")))
                .build();

        assertThat(cycleDetectionService.findCycles(graphBuilderService.build(model))).isEmpty();
    }

    private static Application app(String id) {
        return Application.builder().id(id).name("App " + id).build();
    }

    private static Relationship dependency(String id, String source, String target) {
        return Relationship.builder()
                .id(id)
                .sourceApplicationId(source)
                .targetApplicationId(target)
                .relationshipType(RelationshipType.DEPENDS_ON)
                .dependencyCriticality(DependencyCriticality.HIGH)
                .build();
    }
}
