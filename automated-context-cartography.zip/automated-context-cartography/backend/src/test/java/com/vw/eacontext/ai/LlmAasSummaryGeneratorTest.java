package com.vw.eacontext.ai;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.util.List;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;

import com.vw.eacontext.config.LlmAasProperties;
import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.FindingType;
import com.vw.eacontext.validation.Severity;

class LlmAasSummaryGeneratorTest {

    private static final GraphStats STATS = GraphStats.builder()
            .applicationCount(12).relationshipCount(12).interfaceCount(6).domainCount(5)
            .businessProcessCount(3).informationObjectCount(5)
            .mostConnectedApplicationId("APP-OMS").maxDegree(7)
            .hubCount(1).cycleCount(1).orphanCount(1)
            .build();

    private static final List<Finding> FINDINGS = List.of(
            new Finding(FindingType.OWNERSHIP_RECORD_MISSING, Severity.WARNING, List.of("APP-ERP"), "no ownership record"),
            new Finding(FindingType.HUB, Severity.ERROR, List.of("APP-OMS"), "hub"));

    @Test
    void runsAgainstConfiguredServiceWhenCredentialsPresent() {
        // Skip test when environment credentials are not present
        Assumptions.assumeTrue(System.getenv("EA_AI_LLMAAS_TOKEN_URL") != null &&
                System.getenv("EA_AI_LLMAAS_CLIENT_ID") != null &&
                System.getenv("EA_AI_LLMAAS_CLIENT_SECRET") != null &&
                System.getenv("EA_AI_LLMAAS_API_KEY") != null &&
                System.getenv("EA_AI_LLMAAS_BASE_URL") != null &&
                System.getenv("EA_AI_LLMAAS_MODEL") != null,
                "LLMaaS credentials not present - skipping live test");

        LlmAasProperties props = new LlmAasProperties();
        props.setTokenUrl(System.getenv("EA_AI_LLMAAS_TOKEN_URL"));
        props.setClientId(System.getenv("EA_AI_LLMAAS_CLIENT_ID"));
        props.setClientSecret(System.getenv("EA_AI_LLMAAS_CLIENT_SECRET"));
        props.setApiKey(System.getenv("EA_AI_LLMAAS_API_KEY"));
        props.setBaseUrl(System.getenv("EA_AI_LLMAAS_BASE_URL"));
        props.setModel(System.getenv("EA_AI_LLMAAS_MODEL"));
        props.setTimeout(Duration.ofSeconds(30));

        LlmAasTokenService tokenService = new LlmAasTokenService(props);
        LlmAasSummaryGenerator gen = new LlmAasSummaryGenerator(props, tokenService);

        String result = gen.summarize(FINDINGS, STATS);
        assertThat(result).isNotNull();
        assertThat(result).isNotBlank();
    }
}

