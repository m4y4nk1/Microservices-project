/**
 * Bakes the graph legend (see legendContent.js / GraphLegend.jsx) into
 * exported diagrams. cy.png()/cy.svg() only rasterize the Cytoscape canvas
 * itself — the on-screen legend is a separate DOM overlay, so without this
 * an exported PNG/SVG/PDF never shows it, and it's always shown fully
 * expanded here regardless of whether the on-screen legend was left
 * collapsed (the point of "baked in", not "whatever happened to be open").
 */
import { RING_ITEMS, EDGE_ITEMS, NODE_ITEMS, EDGE_NOTE, RING_NOTE } from './legendContent'

const WIDTH = 280
const PADDING = 14
const ROW_HEIGHT = 20
const HEADING_HEIGHT = 20
const NOTE_HEIGHT = 18
const SWATCH_SIZE = 14
const MARGIN = 16
const FONT_FAMILY = 'Aptos, "Segoe UI", sans-serif'
const TEXT_COLOR = '#1a3330'
const MUTED_COLOR = '#5f7075'
const BORDER_COLOR = '#d8e3e0'

const DASH = { solid: [], dashed: [7, 4], dotted: [1.5, 3], double: [] }

function buildRows(frame) {
  const rows = []
  if (frame === 'application') {
    rows.push({ type: 'heading', text: 'Edges' })
    for (const item of EDGE_ITEMS) rows.push({ type: 'line', ...item })
    rows.push({ type: 'note', text: EDGE_NOTE })
  }
  rows.push({ type: 'heading', text: 'Nodes' })
  for (const item of NODE_ITEMS) rows.push({ type: 'swatch', ...item })
  rows.push({ type: 'heading', text: 'Issue rings' })
  for (const item of RING_ITEMS) rows.push({ type: 'ring', color: item.color, style: item.style, text: item.label })
  rows.push({ type: 'note', text: RING_NOTE })
  return rows
}

function rowHeight(row) {
  if (row.type === 'heading') return HEADING_HEIGHT
  if (row.type === 'note') return NOTE_HEIGHT
  return ROW_HEIGHT
}

/** Computes the legend box's position (bottom-right corner) and row layout for a given canvas size. */
function legendLayout(frame, canvasWidth, canvasHeight) {
  const rows = buildRows(frame)
  const height = rows.reduce((sum, row) => sum + rowHeight(row), PADDING * 2)
  const width = WIDTH
  const boxX = Math.max(MARGIN, canvasWidth - width - MARGIN)
  const boxY = Math.max(MARGIN, canvasHeight - height - MARGIN)
  return { width, height, rows, boxX, boxY }
}

function roundedRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

/**
 * Draws the legend into the bottom-right corner of a 2D canvas context.
 * `scale` matches whatever pixel-density scale the diagram itself was
 * rendered at (cy.png()'s `scale` option) — applied as a canvas transform
 * so the legend's own fixed logical dimensions come out proportionally
 * sized relative to the (possibly higher-resolution) exported image,
 * instead of looking tiny next to a 2x-scaled diagram.
 */
export function drawLegendOnCanvas(ctx, frame, canvasWidth, canvasHeight, scale = 1) {
  const { width, height, rows, boxX, boxY } = legendLayout(frame, canvasWidth / scale, canvasHeight / scale)

  ctx.save()
  ctx.scale(scale, scale)
  ctx.fillStyle = '#ffffff'
  ctx.strokeStyle = BORDER_COLOR
  ctx.lineWidth = 1
  roundedRectPath(ctx, boxX, boxY, width, height, 10)
  ctx.fill()
  ctx.stroke()

  let y = boxY + PADDING
  for (const row of rows) {
    const h = rowHeight(row)
    ctx.setLineDash([])
    if (row.type === 'heading') {
      ctx.font = `750 10px ${FONT_FAMILY}`
      ctx.fillStyle = MUTED_COLOR
      ctx.textBaseline = 'top'
      ctx.fillText(row.text.toUpperCase(), boxX + PADDING, y + 4)
    } else if (row.type === 'note') {
      ctx.font = `italic 10px ${FONT_FAMILY}`
      ctx.fillStyle = MUTED_COLOR
      ctx.textBaseline = 'top'
      ctx.fillText(row.text, boxX + PADDING, y + 2)
    } else {
      const cy = y + h / 2
      if (row.type === 'line') {
        ctx.strokeStyle = row.color
        ctx.lineWidth = 2
        ctx.setLineDash(DASH[row.lineStyle] ?? [])
        ctx.beginPath()
        ctx.moveTo(boxX + PADDING, cy)
        ctx.lineTo(boxX + PADDING + 24, cy)
        ctx.stroke()
      } else if (row.type === 'swatch') {
        ctx.fillStyle = row.fill
        ctx.strokeStyle = row.border
        ctx.lineWidth = 2.5
        ctx.setLineDash(DASH[row.borderStyle] ?? [])
        roundedRectPath(ctx, boxX + PADDING, cy - SWATCH_SIZE / 2, SWATCH_SIZE, SWATCH_SIZE, 3)
        ctx.fill()
        ctx.stroke()
      } else if (row.type === 'ring') {
        ctx.fillStyle = '#ffffff'
        ctx.strokeStyle = row.color
        ctx.lineWidth = row.style === 'double' ? 4 : 3
        ctx.setLineDash(DASH[row.style] ?? [])
        roundedRectPath(ctx, boxX + PADDING, cy - SWATCH_SIZE / 2, SWATCH_SIZE, SWATCH_SIZE, 4)
        ctx.fill()
        ctx.stroke()
      }
      ctx.setLineDash([])
      ctx.font = `12px ${FONT_FAMILY}`
      ctx.fillStyle = TEXT_COLOR
      ctx.textBaseline = 'middle'
      ctx.fillText(row.text, boxX + PADDING + 34, cy)
    }
    y += h
  }
  ctx.restore()
}

/**
 * Composites a legend onto a PNG data URI, returning a new data URI with the
 * legend baked into the bottom-right corner. Used for both PNG export and PDF
 * export (which already just embeds a PNG snapshot).
 */
export function bakeLegendIntoPng(pngDataUri, frame, scale = 1) {
  return new Promise((resolve, reject) => {
    const image = new Image()
    image.onload = () => {
      const canvas = document.createElement('canvas')
      canvas.width = image.naturalWidth
      canvas.height = image.naturalHeight
      const ctx = canvas.getContext('2d')
      ctx.drawImage(image, 0, 0)
      drawLegendOnCanvas(ctx, frame, canvas.width, canvas.height, scale)
      resolve(canvas.toDataURL('image/png'))
    }
    image.onerror = reject
    image.src = pngDataUri
  })
}

function escapeXml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function svgDashArray(style) {
  const dash = DASH[style]
  return dash && dash.length ? ` stroke-dasharray="${dash.join(',')}"` : ''
}

/** Builds the legend as an SVG `<g>` markup string, positioned for the given canvas size. */
function legendSvgMarkup(frame, canvasWidth, canvasHeight, scale = 1) {
  const { width, height, rows, boxX, boxY } = legendLayout(frame, canvasWidth / scale, canvasHeight / scale)
  const parts = [
    `<rect x="${boxX}" y="${boxY}" width="${width}" height="${height}" rx="10" ry="10" fill="#ffffff" stroke="${BORDER_COLOR}" />`,
  ]

  let y = boxY + PADDING
  for (const row of rows) {
    const h = rowHeight(row)
    if (row.type === 'heading') {
      parts.push(`<text x="${boxX + PADDING}" y="${y + 12}" font-family="${FONT_FAMILY}" font-size="10" font-weight="750" fill="${MUTED_COLOR}">${escapeXml(row.text.toUpperCase())}</text>`)
    } else if (row.type === 'note') {
      parts.push(`<text x="${boxX + PADDING}" y="${y + 10}" font-family="${FONT_FAMILY}" font-size="10" font-style="italic" fill="${MUTED_COLOR}">${escapeXml(row.text)}</text>`)
    } else {
      const cy = y + h / 2
      if (row.type === 'line') {
        parts.push(`<line x1="${boxX + PADDING}" y1="${cy}" x2="${boxX + PADDING + 24}" y2="${cy}" stroke="${row.color}" stroke-width="2"${svgDashArray(row.lineStyle)} />`)
      } else if (row.type === 'swatch') {
        parts.push(`<rect x="${boxX + PADDING}" y="${cy - SWATCH_SIZE / 2}" width="${SWATCH_SIZE}" height="${SWATCH_SIZE}" rx="3" fill="${row.fill}" stroke="${row.border}" stroke-width="2.5"${svgDashArray(row.borderStyle)} />`)
      } else if (row.type === 'ring') {
        const strokeWidth = row.style === 'double' ? 4 : 3
        parts.push(`<rect x="${boxX + PADDING}" y="${cy - SWATCH_SIZE / 2}" width="${SWATCH_SIZE}" height="${SWATCH_SIZE}" rx="4" fill="#ffffff" stroke="${row.color}" stroke-width="${strokeWidth}"${svgDashArray(row.style)} />`)
      }
      parts.push(`<text x="${boxX + PADDING + 34}" y="${cy + 4}" font-family="${FONT_FAMILY}" font-size="12" fill="${TEXT_COLOR}">${escapeXml(row.text)}</text>`)
    }
    y += h
  }
  return `<g transform="scale(${scale})">${parts.join('')}</g>`
}

/**
 * Injects the legend into a cy.svg() markup string, just before `</svg>` so
 * it paints on top of the diagram. Reads the SVG's own width/height
 * attributes (always set numerically by cytoscape-svg) to position the
 * legend in its bottom-right corner. `scale` should match whatever scale
 * cy.svg() itself was called with, for the same proportional-sizing reason
 * as bakeLegendIntoPng.
 */
export function bakeLegendIntoSvg(svgMarkup, frame, scale = 1) {
  const doc = new DOMParser().parseFromString(svgMarkup, 'image/svg+xml')
  const root = doc.documentElement
  const width = Number.parseFloat(root.getAttribute('width')) || 0
  const height = Number.parseFloat(root.getAttribute('height')) || 0
  const legendMarkup = legendSvgMarkup(frame, width, height, scale)
  return svgMarkup.replace('</svg>', `${legendMarkup}</svg>`)
}
