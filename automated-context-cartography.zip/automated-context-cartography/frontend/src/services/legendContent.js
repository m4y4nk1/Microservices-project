/**
 * Single source of truth for the graph legend's content — shared between the
 * on-screen GraphLegend component and the export-time renderer (legendExport.js).
 * Keeping these in one place means an exported PNG/SVG/PDF can never drift
 * out of sync with what's shown on screen.
 */

/** Ring color/style per issue class. Labels mirror NodeDetail's BADGES map. */
export const RING_ITEMS = [
  { cls: 'gap', color: '#df6249', style: 'solid', label: 'Ownership gap' },
  { cls: 'eol', color: '#c2415d', style: 'dashed', label: 'Lifecycle risk (EoL provider)' },
  { cls: 'duplicate', color: '#ea580c', style: 'dashed', label: 'Duplicate application' },
  { cls: 'orphan', color: '#64748b', style: 'double', label: 'Orphan application' },
  { cls: 'lifecycle-risk', color: '#f59e0b', style: 'solid', label: 'Lifecycle risk' },
  { cls: 'broken-ref', color: '#dc2626', style: 'solid', label: 'Broken reference' },
  { cls: 'unmapped', color: '#94a3b8', style: 'dotted', label: 'Unmapped process application' },
  { cls: 'circular', color: '#7c3aed', style: 'double', label: 'Circular dependency' },
  { cls: 'orphan-interface', color: '#68767e', style: 'dotted', label: 'Dangling interface consumer' },
  { cls: 'deprecated-interface', color: '#8b5cf6', style: 'dotted', label: 'Deprecated interface in use' },
  { cls: 'spof', color: '#2563a6', style: 'dashed', label: 'Hub / single point of failure' },
  { cls: 'sensitive-flow', color: '#be123c', style: 'double', label: 'Sensitive data risk' },
]

/** Edge-type key — only meaningful in the application frame, where these edge kinds are drawn. */
export const EDGE_ITEMS = [
  { lineStyle: 'solid', color: '#9aa7a5', label: 'Hard dependency' },
  { lineStyle: 'dashed', color: '#9aa7a5', label: 'Soft dependency' },
  { lineStyle: 'solid', color: '#3f8fa8', label: 'Interface' },
  { lineStyle: 'dashed', color: '#8a63c7', label: 'Information flow' },
]

export const EDGE_NOTE = 'Arrowheads point to the dependent or consuming application.'

/** Node key — applies in every frame. */
export const NODE_ITEMS = [
  { fill: '#a3adab', border: '#68767e', borderStyle: 'dashed', label: 'Unresolved reference' },
]

export const RING_NOTE = 'A thicker ring indicates multiple issues.'
