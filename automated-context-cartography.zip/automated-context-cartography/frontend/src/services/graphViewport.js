/**
 * Cytoscape camera/viewport helpers shared between GraphCanvas (initial fit
 * after layout) and App.jsx (the "Reset view" control, which needs to re-fit
 * a manually panned/zoomed camera — clearing filters alone doesn't do that).
 * Kept in its own file rather than GraphCanvas.jsx so that file can stay
 * component-only (Vite Fast Refresh requirement).
 */

const MIN_READABLE_ZOOM = 0.72
const MAX_FILTERED_ZOOM = 0.9

/**
 * The set to fit the camera to: whatever's currently visible, or — when a
 * filter/anchor combination matches nothing at all — every element
 * regardless of display style. display:'none' only affects rendering, not an
 * element's stored position, so this still produces a sane, centered view of
 * "where the (empty) result would have been" instead of silently leaving the
 * camera wherever a previous frame/anchor last left it.
 */
function fittableElements(cy) {
  const visible = cy.elements(':visible')
  return visible.length > 0 ? visible : cy.elements()
}

/** Fits the graph, then moves close enough for node names to remain readable. */
export function fitReadable(cy, padding = 56) {
  if (!cy) return
  const visibleElements = fittableElements(cy)
  if (visibleElements.length === 0) return

  cy.fit(visibleElements, padding)
  cy.zoom({
    level: Math.min(Math.max(cy.zoom() * 2.25, MIN_READABLE_ZOOM), cy.maxZoom()),
    renderedPosition: {
      x: cy.width() / 2,
      y: cy.height() / 2,
    },
  })
}

/** Fits every visible filtered element with generous context and no close zoom. */
export function fitOverview(cy, padding = 96) {
  if (!cy) return
  const visibleElements = fittableElements(cy)
  if (visibleElements.length === 0) return

  cy.fit(visibleElements, padding)
  if (cy.zoom() > MAX_FILTERED_ZOOM) {
    cy.zoom({
      level: MAX_FILTERED_ZOOM,
      renderedPosition: {
        x: cy.width() / 2,
        y: cy.height() / 2,
      },
    })
  }
}
