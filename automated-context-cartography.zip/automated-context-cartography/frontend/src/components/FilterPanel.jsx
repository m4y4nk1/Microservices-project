import { ChevronDown } from "lucide-react";
import { MATRIX_FRAMES } from "../services/filterState";
import "./FilterPanel.css";

/** Lifecycle options for the existing single-select dropdown. */
const LIFECYCLE_OPTIONS = [
  { value: "ACTIVE", label: "Active" },
  { value: "PLAN", label: "Plan" },
  { value: "PHASE_IN", label: "Phase In" },
  { value: "PHASE_OUT", label: "Phase Out" },
  { value: "END_OF_LIFE", label: "End of Life" },
];

/** Viewpoints supported by the application matrix. */
const VIEWPOINT_OPTIONS = [
  { value: "Current", label: "Current" },
  { value: "Target", label: "Target" },
  { value: "Reference", label: "Reference" },
];

/** Process hierarchy levels. */
const PROCESS_LEVEL_OPTIONS = [
  { value: "L1", label: "L1" },
  { value: "L2", label: "L2" },
  { value: "L3", label: "L3" },
];

function MultiSelectDropdown({ label, options, selected, onToggle }) {
  const selectedLabels = options
    .filter((option) => selected.includes(option.value))
    .map((option) => option.label);
  const summary = selectedLabels.length === 0
    ? `All ${label.toLowerCase()}`
    : selectedLabels.length === 1
      ? selectedLabels[0]
      : `${selectedLabels.length} selected`;

  return (
    <div className="filter-multiselect-field">
      <h3 className="filter-label">{label}</h3>
      <details className="filter-multiselect">
        <summary>
          <span className={selectedLabels.length === 0 ? "is-placeholder" : ""}>{summary}</span>
          <ChevronDown className="filter-multiselect-chevron" size={16} aria-hidden="true" />
        </summary>
        <div className="filter-multiselect-menu" role="group" aria-label={label}>
          {options.map((option) => (
            <label className="filter-check" key={option.value}>
              <input
                type="checkbox"
                checked={selected.includes(option.value)}
                onChange={() => onToggle(option.value)}
              />
              <span>{option.label}</span>
            </label>
          ))}
        </div>
      </details>
    </div>
  );
}

/**
 * Frame-aware graph controls. The primary dropdown follows the active frame;
 * lifecycle and issue filters remain specific to applications, the Auriga
 * checkbox-group dimensions appear on the application/information-flow
 * frames as noted per-group, and the (now-dormant) application-matrix
 * dimensions still render only for matrix frames, which no current backend
 * `Frame` ever is.
 *
 * @param {object} props
 * @param {typeof EMPTY_FILTERS} props.filters - Current filter values.
 * @param {(filters: typeof EMPTY_FILTERS) => void} props.onChange - Emits the next filter state.
 * @param {() => void} props.onReset - Clears all filters.
 * @param {string} props.frame - Active graph frame.
 * @param {Array<{value: string, label: string}>} [props.options] - Primary filter options.
 * @param {object} [props.serverOptions] - Server-derived option lists keyed by
 *   dimension (business criticality, lifecycle status, hosting, classification,
 *   plus the legacy matrix dimensions).
 */
function FilterPanel({
  filters,
  onChange,
  onReset,
  frame = "application",
  options = [],
  serverOptions = {},
}) {
  const update = (key, value) => onChange({ ...filters, [key]: value });
  const toggleArrayValue = (key, value) => {
    const current = filters[key] ?? [];
    const next = current.includes(value)
      ? current.filter((v) => v !== value)
      : [...current, value];
    update(key, next);
  };

  const isApplication = frame === "application";
  const isInfoFlow = frame === "infoflow";
  const isProcess = frame === "process";
  const isMatrixFrame = MATRIX_FRAMES.includes(frame);
  const filterLabel =
    frame === "process"
      ? "Filter by Process"
      : frame === "infoflow"
        ? "Filter by Information"
        : "Filter by Domain";
  const allLabel =
    frame === "process"
      ? "All processes"
      : frame === "infoflow"
        ? "All information objects"
        : "All domains";
  const searchPlaceholder =
    frame === "process"
      ? "Search a process…"
      : frame === "infoflow"
        ? "Search information…"
        : frame === "domain"
          ? "Search a domain…"
          : "Search an application…";

  /** Renders one optional matrix dropdown, or a free-text box when no options exist. */
  const renderMatrixSelect = (key, label, placeholder, presetOptions) => {
    const opts = presetOptions ?? serverOptions[key] ?? [];
    return (
      <div key={key}>
        <h3 className="filter-label">{label}</h3>
        {opts.length > 0 ? (
          <select
            className="filter-input"
            value={filters[key] ?? ""}
            onChange={(e) => update(key, e.target.value)}
          >
            <option value="">{placeholder}</option>
            {opts.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        ) : (
          <input
            type="text"
            className="filter-input"
            placeholder={placeholder}
            value={filters[key] ?? ""}
            onChange={(e) => update(key, e.target.value)}
          />
        )}
      </div>
    );
  };

  const businessCriticalityOptions = serverOptions.businessCriticality ?? [];
  const lifecycleStatusOptions = serverOptions.lifecycleStatus ?? [];
  const hostingOptions = serverOptions.hosting ?? [];
  const classificationOptions = serverOptions.classification ?? [];

  return (
    <div className="filter-panel">
      {!isMatrixFrame && !isInfoFlow && !isProcess && (
        <>
          <h3 className="filter-label">{filterLabel}</h3>
          <select
            className="filter-input"
            value={filters.domain}
            onChange={(e) => update("domain", e.target.value)}
          >
            <option value="">{allLabel}</option>
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </>
      )}

      {isApplication && (
        <>
          {businessCriticalityOptions.length > 0 && (
            <MultiSelectDropdown
              label="Business Criticality"
              options={businessCriticalityOptions}
              selected={filters.businessCriticality ?? []}
              onToggle={(value) => toggleArrayValue("businessCriticality", value)}
            />
          )}

          {lifecycleStatusOptions.length > 0 && (
            <MultiSelectDropdown
              label="Lifecycle Status"
              options={lifecycleStatusOptions}
              selected={filters.lifecycleStatuses ?? []}
              onToggle={(value) => toggleArrayValue("lifecycleStatuses", value)}
            />
          )}

          {hostingOptions.length > 0 && (
            <MultiSelectDropdown
              label="Hosting"
              options={hostingOptions}
              selected={filters.hosting ?? []}
              onToggle={(value) => toggleArrayValue("hosting", value)}
            />
          )}
        </>
      )}

      {isInfoFlow && classificationOptions.length > 0 && (
        <MultiSelectDropdown
          label="Classification"
          options={classificationOptions}
          selected={filters.classification ?? []}
          onToggle={(value) => toggleArrayValue("classification", value)}
        />
      )}

      {isProcess && options.length > 0 && (
        <MultiSelectDropdown
          label="Process Domain"
          options={options}
          selected={filters.processDomains ?? []}
          onToggle={(value) => toggleArrayValue("processDomains", value)}
        />
      )}

      {isMatrixFrame && (
        <div className="filter-matrix">
          <p className="filter-section">Scope</p>
          {renderMatrixSelect("landscape", "Landscape", "All landscapes")}
          {renderMatrixSelect("site", "Site", "All sites")}
          {renderMatrixSelect("brand", "Brand", "All brands")}

          <p className="filter-section">Business</p>
          {renderMatrixSelect(
            "businessArea",
            "Business Area",
            "All business areas",
          )}
          {renderMatrixSelect(
            "processLevel",
            "Process Level",
            "All levels",
            PROCESS_LEVEL_OPTIONS,
          )}
          {renderMatrixSelect("activity", "Activity", "All activities")}
          {renderMatrixSelect("capability", "Capability", "All capabilities")}

          <p className="filter-section">Application</p>
          {renderMatrixSelect("application", "Application", "All applications")}
          {renderMatrixSelect(
            "lifecycle",
            "Lifecycle",
            "All statuses",
            LIFECYCLE_OPTIONS,
          )}

          {frame === "dependency" && (
            <>
              <p className="filter-section">Dependency</p>
              {renderMatrixSelect(
                "dependencyType",
                "Dependency Type",
                "All types",
              )}
              {renderMatrixSelect(
                "criticality",
                "Criticality",
                "All criticalities",
              )}
            </>
          )}

          {renderMatrixSelect(
            "viewpoint",
            "Viewpoint",
            "All viewpoints",
            VIEWPOINT_OPTIONS,
          )}
        </div>
      )}


     
    </div>
  );
}

export default FilterPanel;
