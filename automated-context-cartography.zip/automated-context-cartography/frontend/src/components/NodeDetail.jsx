import { Activity, CircleUserRound, Info, Network, ShieldAlert } from 'lucide-react'
import { useState } from 'react'
import { getSimulatedRemoval } from '../services/api'
import { findingsForEntity } from '../services/insightAdapter'
import './NodeDetail.css'

/**
 * Human-readable labels for the issue classes carried on a node.
 * @see services/insightAdapter.js
 */
const BADGES = {
  gap: { label: 'Ownership gap', className: 'badge--gap' },
  eol: { label: 'Lifecycle risk', className: 'badge--eol' },
  spof: { label: 'Single point of failure', className: 'badge--spof' },
  circular: { label: 'Circular dependency', className: 'badge--circular' },
  'orphan-interface': { label: 'Dangling interface consumer', className: 'badge--orphan-interface' },
  unmapped: { label: 'Unmapped process application', className: 'badge--unmapped' },
  'broken-ref': { label: 'Broken reference', className: 'badge--broken-ref' },
  duplicate: { label: 'Duplicate application record', className: 'badge--duplicate' },
  orphan: { label: 'Orphan application', className: 'badge--orphan' },
  'lifecycle-risk': { label: 'Lifecycle risk', className: 'badge--lifecycle-risk' },
  'deprecated-interface': { label: 'Deprecated interface in use', className: 'badge--deprecated-interface' },
  'sensitive-flow': { label: 'Sensitive data risk', className: 'badge--sensitive-flow' },
}

/** Acronyms kept upper-cased rather than title-cased by {@link humanizeEnum}. */
const ACRONYMS = new Set(['PII', 'PCI', 'SAAS', 'COTS'])

/** {@code MISSION_CRITICAL -> "Mission Critical"}, {@code CONFIDENTIAL_PII -> "Confidential PII"}. */
function humanizeEnum(value) {
  if (!value) return value
  return value
    .split('_')
    .map((word) => (ACRONYMS.has(word) ? word : word.charAt(0) + word.slice(1).toLowerCase()))
    .join(' ')
}

/**
 * A connection's kind, from the backend-provided `edgeTypes` category
 * (`DEPENDENCY` | `INTERFACE` | `FLOW`) rather than the raw `type` field,
 * which for a dependency edge is the specific `RelationshipType` name (e.g.
 * `DEPENDS_ON`) and varies per row.
 */
function connectionKindLabel(conn) {
  const kind = conn.edgeTypes?.[0]
  if (kind === 'INTERFACE') return 'Interface'
  if (kind === 'FLOW') return 'Information flow'
  if (kind === 'DEPENDENCY') return humanizeEnum(conn.type) || 'Dependency'
  return conn.type ?? 'Connection'
}

/** One line of the connection's most relevant business metadata, by kind. */
function connectionSummary(conn) {
  const kind = conn.edgeTypes?.[0]
  if (kind === 'DEPENDENCY') {
    return conn.dependencyCriticality ? `${humanizeEnum(conn.dependencyCriticality)} criticality` : null
  }
  if (kind === 'INTERFACE') {
    return conn.protocols?.[0] ?? null
  }
  if (kind === 'FLOW') {
    return conn.classifications?.[0] ? humanizeEnum(conn.classifications[0]) : null
  }
  return null
}

/**
 * A single label/value row. Renders nothing when the value is blank, unless a
 * `fallback` is supplied (used in the Ownership section, where a blank field
 * is itself informative rather than something to hide).
 */
function DetailRow({ label, value, fallback }) {
  const isBlank = value === null || value === undefined || value === ''
  if (isBlank && fallback === undefined) return null
  return (
    <div className="detail-row">
      <span className="detail-key">{label}</span>
      <span className="detail-val">{isBlank ? fallback : value}</span>
    </div>
  )
}

/**
 * Shows the selected node's details and issue badges, populated from the node
 * data emitted by GraphCanvas' onNodeSelect. Renders a placeholder when nothing
 * is selected.
 *
 * @param {object} props
 * @param {object | null} [props.node] - Selected node data (id, label, type,
 *   businessDomain, businessCriticality, lifecycleStatus, lifecycleStartDate,
 *   lifecycleEndDate, hosting, vendorType, costCenter, description,
 *   hasOwnershipRecord, applicationOwner, ownerEmployeeId (the Application
 *   record's own claim), ownershipEmployeeId (the ApplicationOwnership
 *   record's own claim), systemCustodian, businessOwner, supportGroup,
 *   department, declaredGaps ({gapType, description, severity}[], from
 *   KnownDataQualityGaps), classification, sensitive, connections,
 *   connectionsDetail ({id, label, type, edgeTypes, direction, otherId,
 *   otherLabel, ...}[], application nodes only), ...).
 * @param {string} [props.issueClasses] - Space-separated issue classes for the
 *   selected node (e.g. "gap eol"), used to render badges.
 * @param {Array<object>} [props.findings] - The full findings list (from
 *   useInsights), used to show each badge's underlying source-record detail
 *   (finding.message) — traceability from an on-graph indicator back to the
 *   specific record that produced it, not just a category label.
 * @param {boolean} [props.hideTitle] - Skips the built-in title row, used when
 *   an outer container (e.g. NodePopupDialog) already renders the node name.
 */
function NodeDetail({ node, issueClasses = '', findings = [], hideTitle = false, tabbed = false }) {
  // Hooks must run unconditionally (before the `!node` early return below).
  // Callers key this component on `node.id` (see NodePopupDialog.jsx) so this
  // local state naturally resets via remount when a different node is picked
  // — no effect needed to clear it by hand.
  const [simulation, setSimulation] = useState(null)
  const [simulationLoading, setSimulationLoading] = useState(false)
  const [simulationError, setSimulationError] = useState(null)
  const [activeTab, setActiveTab] = useState('overview')

  if (!node) {
    return (
      <div className="node-detail node-detail--empty">
        Click a node to inspect its details and blast radius.
      </div>
    )
  }

  const badges = issueClasses
    .split(' ')
    .filter((cls) => BADGES[cls])
  const nodeFindings = findingsForEntity(findings, node.id)

  const runSimulation = async () => {
    setSimulationLoading(true)
    setSimulationError(null)
    try {
      setSimulation(await getSimulatedRemoval(node.id))
    } catch {
      setSimulationError("Couldn't run the simulation. Please try again.")
    } finally {
      setSimulationLoading(false)
    }
  }

  const overview = (
    <div className="node-detail-grid">
      <DetailRow label="Domain" value={node.businessDomain} />
      <DetailRow label="Criticality" value={humanizeEnum(node.businessCriticality)} />
      <DetailRow label="Lifecycle" value={humanizeEnum(node.lifecycleStatus)} />
      <DetailRow label="Since" value={node.lifecycleStartDate} />
      <DetailRow label="Until" value={node.lifecycleEndDate} />
      <DetailRow label="Hosting" value={humanizeEnum(node.hosting)} />
      <DetailRow label="Vendor Type" value={humanizeEnum(node.vendorType)} />
      <DetailRow label="Cost Center" value={node.costCenter} />
      <DetailRow label="Classification" value={humanizeEnum(node.classification)} />
      <DetailRow
        label="Connections"
        value={node.type !== 'application' && typeof node.connections === 'number'
          ? `${node.connections} (blast radius)`
          : undefined}
      />
      {node.description && (
        <div className="node-detail-description">
          <span className="detail-key">Description</span>
          <p>{node.description}</p>
        </div>
      )}
    </div>
  )

  const connections = !node.connectionsDetail || node.connectionsDetail.length === 0 ? (
    <div className="node-detail-empty-state">No connections found for this node.</div>
  ) : (
    <ul className="node-detail-connections">
      {node.connectionsDetail.map((conn) => (
        <li key={conn.id ?? `${conn.otherId}-${conn.direction}`} className="node-detail-connection">
          <span className="node-detail-connection-direction" aria-hidden="true">
            {conn.direction === 'outgoing' ? '→' : '←'}
          </span>
          <span className="node-detail-connection-content">
            <span className="node-detail-connection-main">{conn.otherLabel ?? conn.otherId}</span>
            <span className="node-detail-connection-meta">
              {connectionKindLabel(conn)}
              {connectionSummary(conn) ? ` · ${connectionSummary(conn)}` : ''}
            </span>
          </span>
        </li>
      ))}
    </ul>
  )

  const ownership = node.hasOwnershipRecord === false ? (
    <div className="node-detail-empty-state">No ownership record is available.</div>
  ) : (
    <div className="node-detail-grid">
      <DetailRow label="Owner" value={node.applicationOwner} fallback="Not assigned" />
      <DetailRow label="Employee ID" value={node.ownershipEmployeeId} fallback="Not assigned" />
      <DetailRow label="System Custodian" value={node.systemCustodian} fallback="Not assigned" />
      <DetailRow label="Business Owner" value={node.businessOwner} fallback="Not assigned" />
      <DetailRow label="Support Group" value={node.supportGroup} fallback="Not assigned" />
      <DetailRow label="Department" value={node.department} fallback="Not assigned" />
    </div>
  )

  const risks = (
    <>
      {(badges.length > 0 || node.sensitive) && (
        <div className="node-detail-badges">
          {badges.map((cls) => (
            <span key={cls} className={`badge ${BADGES[cls].className}`}>{BADGES[cls].label}</span>
          ))}
          {node.sensitive && <span className="badge badge--sensitive">Sensitive data</span>}
        </div>
      )}
      {node.declaredGaps?.map((gap, index) => (
        <div key={index} className="node-detail-risk-card">
          <strong>{gap.gapType ?? 'Data-quality gap'}</strong>
          {gap.severity && <span>{humanizeEnum(gap.severity)}</span>}
          {gap.description && <p>{gap.description}</p>}
        </div>
      ))}
      {nodeFindings.map((finding, index) => (
        <div key={`${finding.type}-${index}`} className="node-detail-risk-card">
          <strong>{humanizeEnum(finding.type)}</strong>
          <p>{finding.message}</p>
        </div>
      ))}
    </>
  )

  const impact = (
    <div className="node-detail-impact">
      <p>Test how retiring this application would affect connected systems and architecture findings.</p>
      {!simulation && (
        <button type="button" className="node-detail-simulate-btn" onClick={runSimulation} disabled={simulationLoading}>
          {simulationLoading ? 'Simulating…' : 'Simulate retiring this application'}
        </button>
      )}
      {simulationError && <div className="node-detail-empty-note">{simulationError}</div>}
      {simulation && (
        <>
          <div className="node-detail-impact-summary">
            <strong>{simulation.upstream.length}</strong><span>Upstream</span>
            <strong>{simulation.downstream.length}</strong><span>Downstream</span>
          </div>
          {simulation.newFindings.map((finding, index) => (
            <p key={`new-${index}`} className="node-detail-trace">{finding.message}</p>
          ))}
          {simulation.resolvedFindings.map((finding, index) => (
            <p key={`resolved-${index}`} className="node-detail-trace">{finding.message}</p>
          ))}
          {simulation.newFindings.length === 0 && simulation.resolvedFindings.length === 0 && (
            <div className="node-detail-empty-note">No architectural findings would change.</div>
          )}
          <button type="button" className="node-detail-simulate-btn node-detail-simulate-btn--secondary" onClick={runSimulation} disabled={simulationLoading}>
            {simulationLoading ? 'Simulating…' : 'Re-run simulation'}
          </button>
        </>
      )}
    </div>
  )

  const hasRisks = badges.length > 0 || node.sensitive || node.declaredGaps?.length > 0 || nodeFindings.length > 0
  const tabs = [
    { id: 'overview', label: 'Overview', icon: Info, content: overview },
    ...(node.type === 'application' ? [
      { id: 'connections', label: `Connections${typeof node.connections === 'number' ? ` (${node.connections})` : ''}`, icon: Network, content: connections },
      { id: 'ownership', label: 'Ownership', icon: CircleUserRound, content: ownership },
    ] : []),
    ...(hasRisks ? [{ id: 'risks', label: 'Risks', icon: ShieldAlert, content: risks }] : []),
    ...(node.type === 'application' ? [{ id: 'impact', label: 'Impact', icon: Activity, content: impact }] : []),
  ]
  const selectedTab = tabs.find((tab) => tab.id === activeTab) ?? tabs[0]

  if (!tabbed) {
    return (
      <div className="node-detail">
        {!hideTitle && <div className="node-detail-title">{node.label ?? node.id}</div>}
        {overview}
      </div>
    )
  }

  return (
    <div className="node-detail node-detail--tabbed">
      <div className="node-detail-tabs" role="tablist" aria-label="Node detail sections">
        {tabs.map((tab) => {
          const TabIcon = tab.icon
          return (
            <button
              key={tab.id}
              type="button"
              role="tab"
              className={`node-detail-tab${selectedTab.id === tab.id ? ' is-active' : ''}`}
              aria-selected={selectedTab.id === tab.id}
              aria-controls={`node-detail-panel-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <TabIcon size={15} aria-hidden="true" />
              <span>{tab.label}</span>
            </button>
          )
        })}
      </div>
      <div
        id={`node-detail-panel-${selectedTab.id}`}
        className="node-detail-tab-panel"
        role="tabpanel"
      >
        {selectedTab.content}
      </div>
    </div>
  )
}

export default NodeDetail
