import { useState } from 'react'
import { Info, ChevronDown } from 'lucide-react'
import { RING_ITEMS, EDGE_ITEMS, NODE_ITEMS, EDGE_NOTE, RING_NOTE } from '../services/legendContent'
import './GraphLegend.css'

/**
 * Small, collapsible on-canvas key explaining the graph's visual language —
 * edge line-styles and issue-ring colors — none of which were otherwise
 * explained anywhere in the UI. Purely additive: an overlay inside
 * GraphCanvas's existing wrapper, touches no other component.
 *
 * @param {object} props
 * @param {string} props.frame - The active frame; the edge-type key only
 *   applies where these edges are actually rendered (the application frame).
 *   The node and issue-ring keys apply everywhere.
 */
function GraphLegend({ frame }) {
  const [open, setOpen] = useState(false)

  return (
    <div className={`graph-legend${open ? ' is-open' : ''}`}>
      <button
        type="button"
        className="graph-legend-toggle"
        onClick={() => setOpen((current) => !current)}
        aria-expanded={open}
        title={open ? 'Hide legend' : 'Show legend'}
      >
        <Info size={14} aria-hidden="true" />
        <span>Legend</span>
        <ChevronDown className={`graph-legend-chevron${open ? ' is-open' : ''}`} size={13} aria-hidden="true" />
      </button>

      {open && (
        <div className="graph-legend-body">
          {frame === 'application' && (
            <section className="graph-legend-section graph-legend-section--edges">
              <div className="graph-legend-heading">Edges</div>
              <div className="graph-legend-grid graph-legend-grid--edges">
                {EDGE_ITEMS.map((item) => (
                  <div className="graph-legend-row" key={item.label}>
                    <span
                      className={`graph-legend-line graph-legend-line--${item.lineStyle}`}
                      style={{ borderTopColor: item.color }}
                      aria-hidden="true"
                    />
                    <span>{item.label}</span>
                  </div>
                ))}
              </div>
              <p className="graph-legend-note">{EDGE_NOTE}</p>
            </section>
          )}

          <section className="graph-legend-section graph-legend-section--nodes">
            <div className="graph-legend-heading">Nodes</div>
            {NODE_ITEMS.map((item) => (
              <div className="graph-legend-row" key={item.label}>
                <span
                  className="graph-legend-swatch"
                  style={{ background: item.fill, borderColor: item.border, borderStyle: item.borderStyle }}
                  aria-hidden="true"
                />
                <span>{item.label}</span>
              </div>
            ))}
          </section>

          <section className="graph-legend-section graph-legend-section--issues">
            <div className="graph-legend-heading">Issue rings</div>
            <div className="graph-legend-grid graph-legend-grid--issues">
              {RING_ITEMS.map((item) => (
                <div className="graph-legend-row" key={item.cls}>
                  <span
                    className="graph-legend-swatch"
                    style={{ borderColor: item.color, borderStyle: item.style }}
                    aria-hidden="true"
                  />
                  <span>{item.label}</span>
                </div>
              ))}
            </div>
            <p className="graph-legend-note">{RING_NOTE}</p>
          </section>
        </div>
      )}
    </div>
  )
}

export default GraphLegend
