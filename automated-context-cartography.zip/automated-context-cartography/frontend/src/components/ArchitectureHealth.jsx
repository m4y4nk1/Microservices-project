import { useMemo, useState } from 'react'
import {
  Cable,
  ChevronDown,
  CircleOff,
  ClockAlert,
  Copy,
  Gauge,
  GitBranch,
  Link2Off,
  MapPinOff,
  Network,
  RefreshCcwDot,
  ShieldAlert,
  ShieldOff,
  Tag,
  Unlink,
  Unplug,
  UserRoundX,
  Users,
} from 'lucide-react'
import HorizontalScroller from './HorizontalScroller'
import './ArchitectureHealth.css'

const FRAME_LABELS = {
  application: 'Application',
  domain: 'Domain',
  process: 'Process',
  infoflow: 'Information Flow',
  landscape: 'Landscape',
  site: 'Site',
  brand: 'Brand',
  activity: 'Activity',
  capability: 'Capability',
  matrix: 'Matrix',
  dependency: 'Dependency',
}

const ISSUE_META = {
  HUB: { label: 'Hubs', icon: Network, tone: 'blue' },
  CIRCULAR_DEPENDENCY: { label: 'Circular dependencies', icon: GitBranch, tone: 'blue' },
  BROKEN_RELATIONSHIP_REFERENCE: { label: 'Broken relationships', icon: Unlink, tone: 'coral' },
  DANGLING_INTERFACE_CONSUMER: { label: 'Dangling interface consumers', icon: Unplug, tone: 'coral' },
  BROKEN_INFORMATION_FLOW_REFERENCE: { label: 'Broken information flows', icon: Link2Off, tone: 'coral' },
  UNMAPPED_PROCESS_APPLICATION: { label: 'Unmapped process applications', icon: CircleOff, tone: 'slate' },
  DUPLICATE_APPLICATION: { label: 'Duplicate applications', icon: Copy, tone: 'rose' },
  ORPHAN_APPLICATION: { label: 'Orphan applications', icon: MapPinOff, tone: 'slate' },
  OWNERSHIP_RECORD_MISSING: { label: 'Ownership record missing', icon: UserRoundX, tone: 'coral' },
  OWNERSHIP_PARTIAL_GAP: { label: 'Ownership partial gaps', icon: Users, tone: 'slate' },
  MISSING_OWNER_FIELD: { label: 'Missing owner field', icon: UserRoundX, tone: 'coral' },
  LIFECYCLE_RISK_CRITICAL_PROCESS: { label: 'EoL on critical process', icon: ClockAlert, tone: 'coral' },
  LIFECYCLE_RISK_EOL_PROVIDER: { label: 'EoL interface providers', icon: ClockAlert, tone: 'rose' },
  LIFECYCLE_INCONSISTENCY: { label: 'Lifecycle inconsistencies', icon: RefreshCcwDot, tone: 'rose' },
  DEPRECATED_INTERFACE_IN_USE: { label: 'Deprecated interfaces in use', icon: ShieldAlert, tone: 'coral' },
  INTERFACE_WITHOUT_RELATIONSHIP: { label: 'Interfaces without a relationship', icon: Cable, tone: 'rose' },
  SENSITIVE_DATA_INSECURE_FLOW: { label: 'Sensitive data at risk', icon: ShieldOff, tone: 'coral' },
  PHASE_OUT_CRITICAL_PATH: { label: 'Phase-out in critical path', icon: Tag, tone: 'rose' },
}

function scoreState(score) {
  if (score >= 85) return { label: 'Healthy', tone: 'healthy' }
  if (score >= 65) return { label: 'Needs attention', tone: 'watch' }
  return { label: 'At risk', tone: 'risk' }
}

function ArchitectureHealth({
  frame,
  elements = [],
  findings = [],
  loading = false,
  error = null,
  activeType = null,
  onSelect,
}) {
  const [expanded, setExpanded] = useState(false)

  const health = useMemo(() => {
    const entityIds = new Set(
      elements
        .filter((element) => !element.data?.source && !element.data?.target)
        .map((element) => element.data?.id)
        .filter(Boolean),
    )
    const scopedFindings = findings.filter((finding) =>
      (finding?.relatedEntityIds ?? []).some((id) => entityIds.has(id)),
    )
    const affectedIds = new Set(
      scopedFindings.flatMap((finding) => finding.relatedEntityIds.filter((id) => entityIds.has(id))),
    )
    const counts = scopedFindings.reduce((result, finding) => {
      if (finding?.type) result[finding.type] = (result[finding.type] ?? 0) + 1
      return result
    }, {})
    const risks = Object.entries(counts)
      .map(([type, count]) => ({
        type,
        count,
        ...(ISSUE_META[type] ?? { label: type, icon: ShieldAlert, tone: 'slate' }),
      }))
      .sort((first, second) => second.count - first.count)
    // Score = the percentage of this frame's entities with NO finding touching them,
    // i.e. 100 * (1 - affected/total), rounded and floored at 0. affectedIds is a
    // deduplicated union (an entity hit by two different finding types still only
    // counts once), so fixing one entity's only finding always raises the score by
    // ~100/entityCount points — monotonic by construction, not by branching logic.
    const score = entityIds.size === 0
      ? 100
      : Math.max(0, Math.round(100 * (1 - affectedIds.size / entityIds.size)))

    return { score, entityCount: entityIds.size, affectedCount: affectedIds.size, risks }
  }, [elements, findings])

  const state = scoreState(health.score)
  const frameLabel = FRAME_LABELS[frame] ?? frame

  return (
    <section className={`architecture-health architecture-health--${state.tone}`} aria-label={`${frameLabel} architecture health`}>
      <button
        type="button"
        className="architecture-health-toggle"
        onClick={() => setExpanded((current) => !current)}
        aria-expanded={expanded}
      >
        <span className="architecture-health-icon" aria-hidden="true"><Gauge size={17} /></span>
        <span className="architecture-health-title">
          <strong>Architecture Health</strong>
          <small>{frameLabel} overview</small>
        </span>
        {!loading && !error && (
          <span className="architecture-health-totals">
            <span><strong>{health.affectedCount}</strong> affected</span>
            <span><strong>{health.entityCount}</strong> entities</span>
          </span>
        )}
        <span className="architecture-health-state">{state.label}</span>
        <span
          className="architecture-health-score"
          style={{ '--health-score': `${health.score * 3.6}deg` }}
          aria-label={`${health.score} out of 100`}
        >
          {loading ? '...' : health.score}
        </span>
        <ChevronDown className={`architecture-health-chevron${expanded ? ' is-open' : ''}`} size={16} aria-hidden="true" />
      </button>

      {expanded && (
        <div className="architecture-health-body">
          {error ? (
            <p className="architecture-health-message">Health data is unavailable.</p>
          ) : loading ? (
            <p className="architecture-health-message">Assessing this frame...</p>
          ) : (
            <div className="architecture-health-signals">
             
              {health.risks.length > 0 ? (
                <HorizontalScroller
                  className="architecture-health-scroller"
                  contentClassName="architecture-health-risks"
                  ariaLabel="Priority health signals"
                >
                  {health.risks.map((risk) => {
                    const Icon = risk.icon
                    return (
                      <button
                        key={risk.type}
                        type="button"
                        className={`architecture-health-risk architecture-health-risk--${risk.tone}${activeType === risk.type ? ' is-active' : ''}`}
                        onClick={() => onSelect?.(activeType === risk.type ? null : risk.type)}
                        aria-pressed={activeType === risk.type}
                        title={`Highlight ${risk.label.toLowerCase()} in the graph`}
                      >
                        <span className="architecture-health-risk-icon" aria-hidden="true">
                          <Icon size={15} strokeWidth={2.2} />
                        </span>
                        <span className="architecture-health-risk-label">{risk.label}</span>
                        <strong className="architecture-health-risk-count">{risk.count}</strong>
                        <span className="architecture-health-risk-meter" aria-hidden="true" />
                      </button>
                    )
                  })}
                </HorizontalScroller>
              ) : (
                <p className="architecture-health-message architecture-health-message--clear">No findings in this frame.</p>
              )}
            </div>
          )}
        </div>
      )}
    </section>
  )
}

export default ArchitectureHealth