import { useEffect, useState } from 'react'
import { getSummary } from '../services/api'

/**
 * Fetches the natural-language landscape summary from getSummary().
 * Re-fetches when `refreshKey` changes (e.g. after a new dataset upload).
 *
 * @param {unknown} [refreshKey] - Change this to trigger a re-fetch.
 * @returns {{ summary: string, loading: boolean, error: unknown }}
 */
export function useSummary(refreshKey) {
  const [summary, setSummary] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    let cancelled = false
    // Defer state updates to avoid "setState in effect" lint warnings.
    const loadingTimer = setTimeout(() => {
      setLoading(true)
      setError(null)
    }, 0)

    // inFlight is stored on the global so multiple hook instances share it
    // and simultaneous mounts (React StrictMode in dev) only issue one call.
    if (!globalThis.__ea_summary_inflight) globalThis.__ea_summary_inflight = null

    const inFlight = globalThis.__ea_summary_inflight ??
      (globalThis.__ea_summary_inflight = getSummary().finally(() => {
        globalThis.__ea_summary_inflight = null
      }))

    inFlight
      .then((data) => {
        if (cancelled) return
        setSummary(data?.summary ?? '')
      })
      .catch((err) => {
        if (cancelled) return
        setError(err)
        setSummary('')
      })
      .finally(() => {
        clearTimeout(loadingTimer)
        if (!cancelled) setLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [refreshKey])

  return { summary, loading, error }
}
