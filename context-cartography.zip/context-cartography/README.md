# Context Cartography — AI-Powered Enterprise Architecture Context Diagram Generator

Spring Boot 3 (Java 21) service that ingests an Enterprise Architecture (EA) dataset,
builds a dependency graph, detects data-quality and architectural issues, and exposes
everything as JSON for a frontend (e.g. the bundled Cytoscape.js prototype).

## Features

- **Ingestion** — pluggable parsers for **JSON**, **Excel (.xlsx)** and **CSV (zip of files)**,
  driven by an externalized, config-based column mapping (`application.yml`).
- **Canonical model** — technology-agnostic domain: Applications, Interfaces,
  Business Processes, Domains, Information Objects.
- **Validation** — required fields, unique IDs, referential integrity (never throws;
  returns a `ValidationReport`).
- **Graph engine** — JGraphT `DirectedPseudograph` (apps as nodes, interfaces as edges).
- **Observation frames** — four node/edge projections: application, business process,
  domain (aggregated), information flow.
- **Impact analysis** — upstream + downstream blast radius for any application.
- **Insights** — ownership gaps, orphan interfaces, missing process mappings,
  lifecycle risks (EOL/Deprecated), dependency hotspots (single points of failure).
- **AI summary** — deterministic template generator by default; optional Azure OpenAI
  (Spring `WebClient`) behind the `ai` profile with graceful fallback.
- **Export** — PNG, PDF (PDFBox) and PPTX (POI) summaries.
- **Session store** — the uploaded model and its derived graph/findings/stats are cached
  in memory (no database). On startup the **bundled sample dataset is auto-loaded**, so
  the API works immediately without an upload.
- **RBAC** — JWT authentication with `User → Role → Permission → Feature` authorization.
  Six seeded roles, 24 feature-level permissions, and a **Contexa Admin** console for
  user/role management, AI governance and the audit trail.
- **AI governance** — per-feature toggles and a per-user daily token budget, with every
  AI call, upload, export and role change written to an audit log.

## Security & RBAC

Authorization is bound to **permissions**, never to roles — roles are just bundles of
permissions, so any capability (in particular the cost-bearing AI features) can be
granted individually from the admin console without a code change.

### Seeded roles

| Role | Purpose |
| ---- | ------- |
| `SUPER_ADMIN` | Platform owner. Everything, including `AI_CONFIG`. |
| `ADMIN` | Manages users, roles and audit. No AI configuration. |
| `ARCHITECT` | Full data, diagram, analysis, AI and export rights. |
| `ANALYST` | Read + analyse + AI; cannot change data. |
| `VIEWER` | Read-only diagrams. No AI, no export. |
| `GUEST` | Application frame only. |

### Permission catalogue

```
DATA_UPLOAD  DATA_EDIT  DATA_DELETE
DIAGRAM_VIEW  DIAGRAM_VIEW_APPLICATION  DIAGRAM_VIEW_PROCESS
DIAGRAM_VIEW_DOMAIN  DIAGRAM_VIEW_INFOFLOW
ANALYSIS_DEPENDENCY  ANALYSIS_IMPACT  ANALYSIS_RISK  ANALYSIS_GOVERNANCE
AI_SUMMARY  AI_QUERY  AI_ENRICHMENT  AI_RECOMMENDATION  AI_AGENT
EXPORT_PNG  EXPORT_PDF  EXPORT_PPTX
USER_MANAGE  ROLE_MANAGE  AI_CONFIG  AUDIT_VIEW
```

### First login

A bootstrap administrator is seeded on first startup:

```
email:    admin@contexa.local
password: ChangeMe#123      # flagged mustChangePassword
```

```bash
# 1. Sign in
curl -X POST http://localhost:8080/api/auth/login \
     -H "Content-Type: application/json" \
     -d '{"email":"admin@contexa.local","password":"ChangeMe#123"}'

# 2. Use the returned token on every other call
curl http://localhost:8080/api/graph/application -H "Authorization: Bearer <token>"

# 3. Change the seeded password immediately
curl -X POST http://localhost:8080/api/auth/change-password \
     -H "Authorization: Bearer <token>" -H "Content-Type: application/json" \
     -d '{"currentPassword":"ChangeMe#123","newPassword":"<a-strong-password>"}'
```

Override the bootstrap account with `CONTEXA_SUPERADMIN_EMAIL` /
`CONTEXA_SUPERADMIN_PASSWORD`, and **always** set `CONTEXA_JWT_SECRET` (min 32 chars)
outside local development.

## Requirements

- Java 21
- Maven (or the bundled `mvnw` / `mvnw.cmd` wrapper)

## Run

```bash
# from the project root
./mvnw spring-boot:run
# Windows PowerShell
.\mvnw.cmd spring-boot:run
```

The app starts on <http://localhost:8080> with the sample dataset already loaded.

To disable auto-loading the sample:

```bash
./mvnw spring-boot:run -Dspring-boot.run.arguments=--ea.sample.autoload=false
```

### Run tests

```bash
./mvnw test
```

### Enable the Azure OpenAI summary (optional)

```powershell
$env:AZURE_OPENAI_ENDPOINT="https://<resource>.openai.azure.com"
$env:AZURE_OPENAI_API_KEY="<key>"
$env:AZURE_OPENAI_DEPLOYMENT="<deployment>"
.\mvnw.cmd spring-boot:run "-Dspring-boot.run.profiles=ai"
```

If the endpoint is unreachable or errors/times out, the service falls back to the
deterministic template summary.

## API Endpoints

Base path: `/api`

All endpoints except `POST /api/auth/login` require an
`Authorization: Bearer <token>` header. The **Permission** column is the authority
enforced by `@PreAuthorize` on each method.

| Method | Path | Permission | Description | Success | Errors |
| ------ | ---- | ---------- | ----------- | ------- | ------ |
| `POST` | `/api/auth/login` | *(public)* | Exchange credentials for a token. | `200` | `401` bad credentials |
| `GET` | `/api/auth/me` | *(any user)* | Caller's identity and permissions. | `200` | `401` |
| `POST` | `/api/auth/change-password` | *(any user)* | Self-service password change. | `204` | `401` wrong current password |
| `POST` | `/api/upload` | `DATA_UPLOAD` | Multipart `file` (`.json`, `.xlsx`, or `.zip` of CSVs). Parses, validates, and caches the model. Returns a `ValidationReport`. | `200` | `400` bad/empty/unsupported file, `403` |
| `GET` | `/api/graph/{frame}` | `DIAGRAM_VIEW` + `DIAGRAM_VIEW_<FRAME>` | Node/edge projection. `frame` = `application` \| `process` \| `domain` \| `infoflow`. Returns a `GraphDto`. | `200` | `400` invalid frame, `403` frame not granted, `409` no model |
| `GET` | `/api/node/{id}/impact` | `ANALYSIS_IMPACT` | Blast radius (upstream + downstream) for an application. | `200` | `403`, `404` unknown app, `409` no model |
| `GET` | `/api/insights` | `ANALYSIS_RISK` | All insight findings. Returns `List<Finding>`. | `200` | `403`, `409` no model |
| `GET` | `/api/summary` | `AI_SUMMARY` | Natural-language landscape summary. | `200` | `403`, `409` no model, `429` token budget spent, `503` AI disabled |
| `GET` | `/api/export?type=png\|pdf\|pptx` | `EXPORT_PNG` / `EXPORT_PDF` / `EXPORT_PPTX` | Downloadable export of the current landscape. | `200` | `400` invalid type, `403`, `409` no model |

### Admin API

| Method | Path | Permission | Description |
| ------ | ---- | ---------- | ----------- |
| `GET` | `/api/admin/users` | `USER_MANAGE` | List users. |
| `POST` | `/api/admin/users` | `USER_MANAGE` | Create or invite a user (omit `password` to invite). |
| `PUT` | `/api/admin/users/{id}` | `USER_MANAGE` | Update name, role and activation. |
| `PUT` | `/api/admin/users/{id}/role` | `USER_MANAGE` | Re-assign a role. |
| `PUT` | `/api/admin/users/{id}/active` | `USER_MANAGE` | Activate / deactivate. |
| `POST` | `/api/admin/users/{id}/reset-password` | `USER_MANAGE` | Issue a one-time temporary password. |
| `DELETE` | `/api/admin/users/{id}` | `USER_MANAGE` | Delete a user. |
| `GET` | `/api/admin/roles` | `ROLE_MANAGE` / `USER_MANAGE` | List roles with permissions and user counts. |
| `GET` | `/api/admin/permissions` | `ROLE_MANAGE` / `USER_MANAGE` | The permission catalogue. |
| `PUT` | `/api/admin/roles/{name}/permissions` | `ROLE_MANAGE` | Replace a role's permission set. |
| `POST` \| `DELETE` | `/api/admin/roles` | `ROLE_MANAGE` | Create / delete a custom role. |
| `GET` | `/api/admin/ai-settings` | `AI_CONFIG` / `USER_MANAGE` | Read AI governance policy. |
| `PUT` | `/api/admin/ai-settings` | `AI_CONFIG` | Model, per-user daily token budget, feature toggles. |
| `GET` | `/api/admin/audit` | `AUDIT_VIEW` | Audit trail (filter by `actor` / `action`). |
| `GET` | `/api/admin/audit/ai` | `AUDIT_VIEW` | AI activity and token spend only. |

The last two roles are protected by invariants: the last active `SUPER_ADMIN` cannot be
demoted, deactivated or deleted, and `SUPER_ADMIN` must always retain `USER_MANAGE` and
`ROLE_MANAGE`.

All errors are returned as a structured JSON body:

```json
{ "timestamp": "...", "status": 400, "error": "Bad Request", "message": "...", "details": [ ] }
```

### CORS

The React dev server origin `http://localhost:5173` is allowed by default
(configurable via `ea.cors.allowed-origins`).

### Quick examples

```bash
# Application graph (auto-loaded sample)
curl http://localhost:8080/api/graph/application

# Insights
curl http://localhost:8080/api/insights

# Impact of an application
curl http://localhost:8080/api/node/APP-ERP/impact

# Upload your own dataset
curl -F "file=@src/main/resources/sample_ea_dataset.json" http://localhost:8080/api/upload

# Export a PPTX
curl -OJ "http://localhost:8080/api/export?type=pptx"
```

## Configuration

Key properties (see `src/main/resources/application.yml`):

| Property | Default | Description |
| -------- | ------- | ----------- |
| `ea.ingestion.fields.*` | see yml | Column mapping per entity (shared by all parsers) |
| `ea.ingestion.json.roots.*` | see yml | Top-level JSON array names |
| `ea.ingestion.excel.sheets.*` | see yml | Worksheet name per entity |
| `ea.ingestion.csv.files.*` | see yml | CSV file name per entity (inside the zip) |
| `ea.insight.hotspot-degree-threshold` | `5` | Degree above which an app is a hotspot |
| `ea.sample.autoload` | `true` | Auto-load the bundled sample on startup |
| `ea.cors.allowed-origins` | `http://localhost:5173` | Allowed CORS origins |
| `ea.ai.azure.*` (profile `ai`) | env vars | Azure OpenAI endpoint/key/deployment/etc. |
| `contexa.security.enabled` | `true` | Master switch for the JWT chain + method security |
| `contexa.jwt.secret` | dev value | HMAC signing key — **must** be overridden (min 32 chars) |
| `contexa.jwt.expiry-ms` | `86400000` | Access-token lifetime |
| `contexa.seed.enabled` | `true` | Seed permissions, roles and the bootstrap admin |
| `contexa.seed.super-admin-*` | see yml | Bootstrap administrator email/name/password |
| `spring.datasource.*` | H2 in-memory | Identity/audit store (swap for PostgreSQL in prod) |

> Seeding is additive and idempotent: new permission codes appear automatically on
> upgrade, but roles you have customised in the admin console are never overwritten.

### Production database

Point the app at PostgreSQL with environment variables — no code change needed:

```bash
export CONTEXA_DB_URL=jdbc:postgresql://localhost:5432/contexa
export CONTEXA_DB_USER=contexa
export CONTEXA_DB_PASSWORD=<secret>
export CONTEXA_DB_DRIVER=org.postgresql.Driver
export CONTEXA_DB_DDL=validate     # manage schema with migrations
```

## Project structure

```
com.vw.eacontext
├── model        canonical domain (records)
├── ingestion    JSON/CSV/Excel parsers
├── graph        JGraphT builder, projections, impact analysis
├── insight      detectors -> findings
├── ai           summary generators (template default, Azure optional)
├── validation   data-quality validation
├── api          REST controllers + in-memory session store + export
├── dto          request/response DTOs
├── config       @ConfigurationProperties, CORS, AI wiring
├── exception    custom exceptions + global handler
├── security     RBAC: entities, repositories, JWT, filter chain, seeding
│   ├── model        AppUser / Role / Permission + PermissionCode, RoleName
│   ├── repository   Spring Data JPA repositories
│   ├── service      JwtService, AuthService, CurrentUserService, FramePermissionEvaluator
│   ├── config       SecurityConfig, JwtAuthFilter, error handlers, properties
│   ├── controller   AuthController
│   └── seed         DataInitializer (permissions, role matrix, bootstrap admin)
└── admin        Contexa Admin console backend
    ├── model        AiSettings, AiUsage, AuditEntry, AiFeature, AuditAction
    ├── repository   JPA repositories
    ├── service      AdminUserService, AdminRoleService, AiGovernanceService, AuditService
    ├── dto          admin request/response records
    └── controller   users, roles, ai-settings, audit
```

