# Context Cartography - Quick Reference Guide

## 🎯 One-Sentence Summary
An AI-powered Spring Boot service that ingests EA datasets, builds dependency graphs, detects architectural issues, and provides interactive visualization via React + Cytoscape.

---

## 📦 Project Structure at a Glance

### Backend (`/backend`) - Spring Boot 3 + Java 21

| Module | Purpose | Key Files |
|--------|---------|-----------|
| **model/** | Domain records (immutable data carriers) | `CanonicalModel`, `Application`, `Interface`, etc. |
| **ingestion/** | Multi-format parsers | `JsonEaDataParser`, `ExcelEaDataParser`, `CsvEaDataParser` |
| **validation/** | Data quality checks (non-throwing) | `ValidationService`, `ValidationReport` |
| **graph/** | JGraphT dependency analysis | `GraphBuilderService`, `GraphProjectionService`, `ImpactAnalysisService` |
| **insight/** | Issue detectors (hotspots, gaps, risks) | `InsightService`, `Finding` |
| **api/** | REST endpoints + orchestration | `EaController`, `EaContextService`, `SessionModelStore` |
| **ai/** | Summary generators | `TemplateSummaryGenerator`, `AzureOpenAiSummaryGenerator` |
| **config/** | Spring beans + properties mapping | `AiConfig`, `CorsConfig`, `EaIngestionProperties` |
| **dto/** | Request/response objects | `GraphDto`, `ValidationReport`, `ImpactAnalysisResult` |
| **exception/** | Global error handling | `GlobalExceptionHandler`, custom exceptions |

### Frontend (`/frontend`) - React 19 + Vite

| Folder | Purpose | Key Files |
|--------|---------|-----------|
| **components/** | Reusable UI parts | `GraphCanvas`, `FrameTabs`, `FilterPanel`, `InsightsPanel`, `UploadButton`, `ExportButton` |
| **hooks/** | Custom React hooks | `useGraphData`, `useInsights`, `useSummary` |
| **services/** | API & data transformation | `api.js` (Axios), `graphAdapter.js`, `insightAdapter.js` |
| **src/** | Root component & entry | `App.jsx`, `main.jsx` |

---

## 🔄 Data Processing Pipeline

```
Upload File (UI)
    ↓
Choose Parser (by extension)
    ↓
Parse → CanonicalModel
    ↓
Load into SessionModelStore
    ├─ Build Graph
    ├─ Run Insights
    ├─ Compute Stats
    └─ Cache all
    ↓
Validate → Report (no exceptions)
    ↓
Return to UI → Refresh views
```

---

## 🌐 REST API Endpoints

| Method | Endpoint | Input | Output | Purpose |
|--------|----------|-------|--------|---------|
| `POST` | `/api/upload` | Multipart file | `ValidationReport` | Upload dataset |
| `GET` | `/api/graph/{frame}` | Frame slug | `GraphDto` | Get graph projection |
| `GET` | `/api/node/{id}/impact` | App ID | `ImpactAnalysisResult` | Blast radius analysis |
| `GET` | `/api/insights` | — | `List<Finding>` | All detected issues |
| `GET` | `/api/summary` | — | `{ summary: string }` | AI-powered summary |
| `GET` | `/api/export` | Type param | File blob | Download PNG/PDF/PPTX |

---

## 📊 Key Entities

### CanonicalModel (Record)
```java
record CanonicalModel(
    List<Domain> domains,
    List<BusinessProcess> businessProcesses,
    List<Application> applications,
    List<Interface> interfaces,
    List<InformationObject> informationObjects
)
```

### Graph
- Type: `DirectedPseudograph<Application, InterfaceEdge>`
- Nodes: Applications
- Edges: Interfaces (provider → consumer)
- Metadata: `InterfaceEdge` carries interface details

### Observation Frames (4 Views)
1. **APPLICATION**: Apps ↔ Interfaces (default)
2. **PROCESS**: Business Processes ↔ App assignments
3. **DOMAIN**: Domains ↔ Aggregated apps
4. **INFO_FLOW**: Data Objects ↔ Interface flows

### Findings (5 Types)
- `OWNERSHIP_GAP`: App has no owner
- `ORPHAN_INTERFACE`: Interface has no consumer
- `MISSING_PROCESS_MAPPING`: App not mapped to process
- `LIFECYCLE_RISK`: App is EOL/Deprecated
- `DEPENDENCY_HOTSPOT`: App exceeds degree threshold

---

## ⚙️ Configuration Highlights

### Column Mapping (application.yml)
```yaml
ea.ingestion.fields.application:
  id: id                           # source column → canonical field
  name: name
  owner: owner
  domain: domain
  lifecycleStatus: lifecycleStatus
  techStack: techStack
  processId: process
```
**Why?** Decouple source schema from code; support multiple data sources.

### Insight Threshold
```yaml
ea.insight.hotspot-degree-threshold: 5
```
Apps with degree > 5 are flagged as single points of failure.

### Auto-Load Sample
```yaml
ea.sample.autoload: true
```
Loads bundled dataset on startup; enables testing without upload.

### CORS
```yaml
ea.cors.allowed-origins: http://localhost:5173
```
Allows React dev server at `localhost:5173`.

---

## 🎨 Frontend Data Flow

```
App.jsx (root state: frame, filters, refreshKey)
    ├─ useGraphData(frame) → { elements, loading, error }
    ├─ useInsights(refreshKey) → { findings, loading, error }
    └─ useSummary(refreshKey) → { summary, loading, error }
           ↓
      Axios API calls (api.js)
           ↓
      Data transformation (graphAdapter.js, insightAdapter.js)
           ↓
      Components render
      ├─ GraphCanvas (Cytoscape visualization)
      ├─ FrameTabs (frame switcher)
      ├─ FilterPanel (domain/lifecycle filters)
      ├─ InsightsPanel (findings + summary)
      ├─ UploadButton (file input)
      ├─ ExportButton (PNG/PDF/PPTX download)
      └─ Toast (notifications)
```

---

## 💾 In-Memory Storage

**SessionModelStore** caches per-session:
- `CanonicalModel` - Raw ingested data
- `Graph<Application, InterfaceEdge>` - Dependency graph
- `List<Finding>` - Detected issues
- `GraphStats` - Aggregate statistics

**Why in-memory?**
- Instant access (no DB queries)
- Deterministic (no concurrent updates)
- Suitable for prototype/demo (not enterprise-scale)

---

## 🏗️ Architecture Patterns

| Pattern | Usage | Example |
|---------|-------|---------|
| **Strategy** | Multiple parsers | JSON/Excel/CSV all implement `EaDataParser` |
| **Builder** | Immutable construction | `CanonicalModel.builder().applications(...).build()` |
| **Adapter** | Data transformation | `graphAdapter.toCytoscapeElements()` |
| **Facade** | Complex orchestration | `EaContextService.upload()` hides parser selection |
| **Plugin** | Swappable AI implementations | `SummaryGenerator` with template/Azure variants |
| **Configuration-Driven** | Behavioral externalization | Column mapping, sheet names in YAML |
| **Immutability** | Thread-safety | All domain objects are records |
| **Graceful Degradation** | Non-throwing validation | Issues collected in report, never thrown |

---

## 🚀 Getting Started

### Prerequisites
```bash
# Backend
Java 21
Maven (or bundled mvnw)

# Frontend
Node.js 18+
npm
```

### Run Locally

**Terminal 1 (Backend)**
```bash
cd backend
./mvnw spring-boot:run
# Listens on http://localhost:8080
# Auto-loads sample dataset
```

**Terminal 2 (Frontend)**
```bash
cd frontend
npm install
npm run dev
# Listens on http://localhost:5173
```

Open browser: `http://localhost:5173`

### Run Tests
```bash
cd backend
./mvnw test
```

### Build for Production
```bash
# Backend
cd backend
./mvnw clean package
# Produces: target/context-cartography-0.0.1-SNAPSHOT.jar

# Frontend
cd frontend
npm run build
# Produces: dist/ (serve via backend static resources)
```

---

## 🔐 Optional: Enable Azure OpenAI

```powershell
$env:AZURE_OPENAI_ENDPOINT="https://<resource>.openai.azure.com"
$env:AZURE_OPENAI_API_KEY="<key>"
$env:AZURE_OPENAI_DEPLOYMENT="<deployment>"

cd backend
./mvnw spring-boot:run -Dspring-boot.run.profiles=ai
```

- Uses `AzureOpenAiSummaryGenerator` instead of template
- Falls back to template on error
- Requires valid Azure OpenAI setup

---

## 📋 Supported File Formats

| Format | Structure | Parser |
|--------|-----------|--------|
| **.json** | Top-level arrays (`domains`, `applications`, etc.) | `JsonEaDataParser` |
| **.xlsx** | Worksheets per entity (`Domains`, `Applications`, etc.) | `ExcelEaDataParser` |
| **.zip** | CSV files per entity (`domains.csv`, `applications.csv`, etc.) | `CsvEaDataParser` |

All use same **column mapping** (`application.yml`) → pluggable format support.

---

## 🎯 Key Design Decisions

| Decision | Why |
|----------|-----|
| **Records (immutable)** | Thread-safe, compiler-generated methods, clarity |
| **No exceptions on validate** | Frontend gets full report; partial data loads |
| **In-memory storage** | Instant, deterministic, no DB complexity (prototyping) |
| **Configuration-driven mapping** | Support multiple schemas without code changes |
| **Session-per-user** | Simple; no multi-tenancy complexity |
| **Multiple graph projections** | Different stakeholders see different perspectives |
| **Separated concerns** (ingestion, validation, graph, insight, export) | Testable, maintainable, replaceable modules |
| **Spring WebClient + fallback** | Async LLM calls without blocking; graceful degradation |

---

## 🌟 Strengths

✅ Modular, testable architecture  
✅ Multiple data format support  
✅ Non-throwing validation (captures all issues)  
✅ Rich graph analysis (impact analysis, hotspots)  
✅ Configurable thresholds & mappings  
✅ AI-pluggable (template or Azure)  
✅ Export to multiple formats  
✅ Interactive Cytoscape visualization  
✅ Multi-frame observation (4 different views)  

---

## ⚠️ Limitations & Trade-offs

⚠️ In-memory only (scales to ~1000 apps per instance)  
⚠️ Single session per instance (not multi-tenant)  
⚠️ No database persistence  
⚠️ No authentication/authorization built-in  
⚠️ Export is text/summary only (not visual diagram)  
⚠️ No historical versioning  

---

## 🔧 Technology Stack

### Backend
- **Framework**: Spring Boot 3.3
- **Language**: Java 21
- **Graph Library**: JGraphT 1.5.2
- **Excel**: Apache POI 5.3
- **PDF**: PDFBox 3.0.3
- **CSV**: Commons CSV 1.12
- **JSON**: Jackson 2.x (included in Spring)
- **Build**: Maven

### Frontend
- **Framework**: React 19.2
- **Build Tool**: Vite 8.2
- **Graph Visualization**: Cytoscape.js 3.34
- **HTTP Client**: Axios 1.20
- **Linting**: ESLint

### Deployment
- **Backend Runtime**: JVM (Java 21)
- **Frontend Runtime**: Browser (modern browsers)
- **Server**: Tomcat (embedded in Spring Boot)

---

## 📖 Files to Read First

1. **README.md** - Overview, quick start, API examples
2. **ARCHITECTURE.md** - This detailed breakdown
3. **backend/pom.xml** - Dependencies
4. **backend/src/main/resources/application.yml** - Configuration
5. **backend/src/main/java/.../EaContextApplication.java** - Entry point
6. **backend/src/main/java/.../model/CanonicalModel.java** - Core data model
7. **frontend/src/App.jsx** - React root component
8. **frontend/src/services/api.js** - API contract

---

## 🤝 Extending the Project

### Add a New Insight Detector
1. Add finding type to `FindingType` enum
2. Implement detection logic in `InsightService.analyze()`
3. Add findings to list
4. Frontend will auto-display in `InsightsPanel`

### Add a New Export Format
1. Implement export logic in `ExportService`
2. Add case to switch statement
3. Return `ExportFile` with content type & filename
4. Update frontend button to include new format option

### Change Column Mapping
1. Edit `application.yml` under `ea.ingestion.fields.*`
2. Restart backend
3. No code changes needed; parsers use config-driven mapping

### Support a New File Format
1. Create class implementing `EaDataParser` interface
2. Implement `parse(InputStream in) → CanonicalModel`
3. Register as Spring `@Component`
4. Add file extension check in `EaContextService.parserFor()`

### Add Authentication
1. Add Spring Security dependency
2. Implement `SecurityFilterChain` bean
3. Add `@EnableWebSecurity`
4. Protect controller endpoints with `@PreAuthorize`

---

## 📞 Common Questions

**Q: Why no database?**  
A: Prototyping focus; keeps it simple. Add a database by replacing `SessionModelStore` with JPA/JDBC.

**Q: How to scale to 10,000+ apps?**  
A: Add caching layer (Redis), database (PostgreSQL), pagination for large result sets, and elastic search for insights.

**Q: Can multiple users upload simultaneously?**  
A: Currently, they overwrite each other's session. For multi-tenancy, add session-per-user (e.g., by JWT user ID) or use a database.

**Q: How to persist data between restarts?**  
A: Implement `CanonicalModelRepository` (JPA/JDBC), load on startup, save on upload.

**Q: Can I use different column names?**  
A: Yes! Customize `application.yml` field mappings without code changes.

**Q: How does the graph handle circular dependencies?**  
A: JGraphT's `DirectedPseudograph` supports cycles; no special handling needed. Cycle detection can be added via algorithm.

---

## 🎓 Learning Outcomes

After studying this codebase, you'll understand:
- ✅ Spring Boot architecture (controllers, services, config)
- ✅ REST API design (error handling, validation)
- ✅ Graph data structures & algorithms (JGraphT)
- ✅ Data validation patterns (non-throwing reports)
- ✅ Configuration-driven behavior (property files)
- ✅ React hooks & state management
- ✅ Component composition & reusability
- ✅ Multi-format data ingestion (strategy pattern)
- ✅ In-memory caching strategies
- ✅ Immutable domain models (records)
- ✅ Plugin architecture (interface-based extensibility)
- ✅ Error resilience & graceful degradation

Perfect for learning how to build domain-specific tools!

---

## 📚 Additional Resources

- **JGraphT Docs**: https://jgrapht.org/
- **Cytoscape.js Docs**: https://js.cytoscape.org/
- **Spring Boot Guide**: https://spring.io/projects/spring-boot
- **React Hooks Docs**: https://react.dev/reference/react/hooks
- **Vite Guide**: https://vite.dev/guide/
- **Apache POI**: https://poi.apache.org/
- **PDFBox**: https://pdfbox.apache.org/

---

**Last Updated**: September 2026  
**Version**: 0.0.1-SNAPSHOT

