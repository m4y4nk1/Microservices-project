# Contexa – Enterprise Upgrade Blueprint

> Drop-in design + code to make **Context Cartography** enterprise-ready.
> Two pillars: **(A) Role-Based Access Control + Contexa Admin page** and
> **(B) LLM-assisted Smart Ingestion layer**.
> Aligned to the existing package `com.vw.eacontext`, Spring Boot 3 / Java 21, React 19 + Vite.

---

## 0. Where these features plug into the current architecture

Your current layers stay **untouched**. We add two new vertical slices and one cross-cutting concern.

```text
┌────────────────────────────────────────────────────────────────────┐
│                        Frontend (React + Vite)                      │
│  Existing:  GraphCanvas · FrameTabs · FilterPanel · InsightsPanel   │
│  NEW:       LoginPage · <AuthProvider> · <RequirePermission>        │
│  NEW:       ContexaAdmin page (Users · Roles · AI Settings · Audit) │
│  NEW:       MappingReviewPanel (smart-ingestion confirmation UI)    │
├────────────────────────────────────────────────────────────────────┤
│                     REST API Layer (Spring MVC)                     │
│  Existing:  EaController (/api/upload, /graph, /insights, ...)      │
│  NEW:       AuthController      (/api/auth/login, /me)              │
│  NEW:       AdminController     (/api/admin/users, /roles, /ai...)  │
│  NEW:       SmartIngestController (/api/ingest/analyze, /confirm)   │
├────────────────────────────────────────────────────────────────────┤
│              Cross-cutting: Spring Security (JWT filter)            │
│              @PreAuthorize("hasAuthority('AI_SUMMARY')")            │
├────────────────────────────────────────────────────────────────────┤
│                      Business Logic (existing 6)                    │
│  Ingestion │ Validation │ Graph │ Insight │ AI │ Export            │
│  NEW sub-package: ingestion.smart  (LLM schema mapping + cleaning)  │
├────────────────────────────────────────────────────────────────────┤
│  Data Store                                                        │
│  Existing:  SessionModelStore (in-memory EA model)                 │
│  NEW:       Relational DB (users, roles, permissions, audit)       │
└────────────────────────────────────────────────────────────────────┘
```

**Key principle preserved from your design:** *Graph = truth, AI = language/mapping.*
Smart Ingestion uses the LLM **only to map + suggest**; your existing deterministic
parsers still build the `CanonicalModel`.

---

# PART A — Role-Based Access Control + Contexa Admin

## A.1 Concept: Users → Roles → Permissions → Features

Do **not** hard-code features against roles. Bind features to **permissions**; roles are
just bundles of permissions. This is what makes AI features individually grantable.

```text
❌  if (role == ADMIN) { showAiSummary(); }
✅  if (user.hasAuthority("AI_SUMMARY")) { showAiSummary(); }
```

### Roles (seeded defaults)

| Role         | Who                                  |
|--------------|--------------------------------------|
| `SUPER_ADMIN`| Platform owner (you). Everything, incl. AI config. |
| `ADMIN`      | Manages users, roles, audit.         |
| `ARCHITECT`  | Full data + diagrams + AI + export.  |
| `ANALYST`    | Diagrams + analysis + AI summary/query; no data edit. |
| `VIEWER`     | Read-only diagrams; **no AI**, no export. |
| `GUEST`      | Single frame only; demo access.      |

### Permissions (feature-level) — map 1:1 to your existing endpoints

```text
DATA_UPLOAD        POST /api/upload  + /api/ingest/*
DATA_EDIT          edit canonical model
DIAGRAM_VIEW       GET  /api/graph/{frame}
ANALYSIS_IMPACT    GET  /api/node/{id}/impact
ANALYSIS_RISK      GET  /api/insights
AI_SUMMARY         GET  /api/summary
AI_QUERY           (future) natural-language query
AI_ENRICHMENT      smart-ingestion AI mapping/cleaning
EXPORT_PNG/PDF/PPTX GET /api/export
USER_MANAGE        admin: create/edit/deactivate users
ROLE_MANAGE        admin: assign roles + permissions
AI_CONFIG          admin: model, token budget, feature toggles
AUDIT_VIEW         admin: view audit log
```

### Role → Permission matrix (seed)

```text
                    SUPER  ADMIN  ARCH  ANALYST  VIEWER  GUEST
DATA_UPLOAD          ✓     ✓     ✓     ✗       ✗      ✗
DIAGRAM_VIEW         ✓     ✓     ✓     ✓       ✓      ✓ (1 frame)
ANALYSIS_IMPACT      ✓     ✓     ✓     ✓       ✗      ✗
ANALYSIS_RISK        ✓     ✓     ✓     ✓       ✗      ✗
AI_SUMMARY           ✓     ✓     ✓     ✓       ✗      ✗
AI_ENRICHMENT        ✓     ✓     ✓     ✗       ✗      ✗
EXPORT_*             ✓     ✓     ✓     ✓       ✗      ✗
USER_MANAGE          ✓     ✓     ✗     ✗       ✗      ✗
ROLE_MANAGE          ✓     ✓     ✗     ✗       ✗      ✗
AI_CONFIG            ✓     ✗     ✗     ✗       ✗      ✗
AUDIT_VIEW           ✓     ✓     ✗     ✗       ✗      ✗
```

---

## A.2 Dependencies to add (`backend/pom.xml`)

```xml
<!-- Security -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>

<!-- Persistence for users/roles/audit -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>

<!-- Dev DB (swap for PostgreSQL in prod) -->
<dependency>
    <groupId>com.h2database</groupId>
    <artifactId>h2</artifactId>
    <scope>runtime</scope>
</dependency>
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <scope>runtime</scope>
</dependency>

<!-- JWT -->
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-api</artifactId>
    <version>0.12.6</version>
</dependency>
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-impl</artifactId>
    <version>0.12.6</version>
    <scope>runtime</scope>
</dependency>
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-jackson</artifactId>
    <version>0.12.6</version>
    <scope>runtime</scope>
</dependency>
```

> Keep `SessionModelStore` in memory as-is. The DB is **only** for identity + audit,
> not for the EA model. That preserves your fast, deterministic graph pipeline.

---

## A.3 New package: `com.vw.eacontext.security`

### Entities

```java
// security/Permission.java
package com.vw.eacontext.security;

import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name = "permissions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Permission {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String code;   // e.g. "AI_SUMMARY"
}
```

```java
// security/Role.java
package com.vw.eacontext.security;

import jakarta.persistence.*;
import lombok.*;
import java.util.HashSet;
import java.util.Set;

@Entity @Table(name = "roles")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Role {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String name;   // e.g. "ARCHITECT"

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "role_permissions",
        joinColumns = @JoinColumn(name = "role_id"),
        inverseJoinColumns = @JoinColumn(name = "permission_id"))
    @Builder.Default
    private Set<Permission> permissions = new HashSet<>();
}
```

```java
// security/AppUser.java
package com.vw.eacontext.security;

import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name = "users")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AppUser {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String email;

    private String name;

    @Column(nullable = false)
    private String passwordHash;   // BCrypt

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id")
    private Role role;

    @Builder.Default
    private boolean active = true;
}
```

### Repositories

```java
// security/UserRepository.java
package com.vw.eacontext.security;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<AppUser, Long> {
    Optional<AppUser> findByEmail(String email);
}
```

```java
// security/RoleRepository.java
package com.vw.eacontext.security;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByName(String name);
}
```

```java
// security/PermissionRepository.java
package com.vw.eacontext.security;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PermissionRepository extends JpaRepository<Permission, Long> {
    Optional<Permission> findByCode(String code);
}
```

### UserDetails adapter — turns permissions into Spring authorities

```java
// security/AppUserDetailsService.java
package com.vw.eacontext.security;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AppUserDetailsService implements UserDetailsService {

    private final UserRepository users;

    @Override
    public UserDetails loadUserByUsername(String email) {
        AppUser u = users.findByEmail(email)
            .orElseThrow(() -> new UsernameNotFoundException(email));

        var authorities = u.getRole().getPermissions().stream()
            .map(p -> new SimpleGrantedAuthority(p.getCode()))  // authority == permission code
            .collect(Collectors.toSet());

        return User.builder()
            .username(u.getEmail())
            .password(u.getPasswordHash())
            .disabled(!u.isActive())
            .authorities(authorities)
            .build();
    }
}
```

### JWT service

```java
// security/JwtService.java
package com.vw.eacontext.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;

@Service
public class JwtService {

    private final SecretKey key;
    private final long expiryMs;

    public JwtService(@Value("${contexa.jwt.secret}") String secret,
                      @Value("${contexa.jwt.expiry-ms:86400000}") long expiryMs) {
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.expiryMs = expiryMs;
    }

    public String issue(String email, String role, List<String> permissions) {
        return Jwts.builder()
            .subject(email)
            .claim("role", role)
            .claim("perms", permissions)
            .issuedAt(new Date())
            .expiration(new Date(System.currentTimeMillis() + expiryMs))
            .signWith(key)
            .compact();
    }

    public Jws<Claims> parse(String token) {
        return Jwts.parser().verifyWith(key).build().parseSignedClaims(token);
    }
}
```

### JWT filter

```java
// security/JwtAuthFilter.java
package com.vw.eacontext.security;

import io.jsonwebtoken.Claims;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtService jwt;

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res,
                                    FilterChain chain) throws ServletException, IOException {
        String header = req.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            try {
                Claims c = jwt.parse(header.substring(7)).getPayload();
                @SuppressWarnings("unchecked")
                List<String> perms = c.get("perms", List.class);
                var authorities = perms.stream().map(SimpleGrantedAuthority::new).toList();
                var auth = new UsernamePasswordAuthenticationToken(c.getSubject(), null, authorities);
                SecurityContextHolder.getContext().setAuthentication(auth);
            } catch (Exception ignored) {
                SecurityContextHolder.clearContext();
            }
        }
        chain.doFilter(req, res);
    }
}
```

### Security configuration

```java
// security/SecurityConfig.java
package com.vw.eacontext.security;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableMethodSecurity          // enables @PreAuthorize
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
          .csrf(csrf -> csrf.disable())
          .cors(cors -> {})       // keep your existing CorsConfig
          .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
          .authorizeHttpRequests(auth -> auth
              .requestMatchers("/api/auth/**").permitAll()
              .requestMatchers("/api/admin/**").hasAnyAuthority("USER_MANAGE","ROLE_MANAGE","AI_CONFIG","AUDIT_VIEW")
              .anyRequest().authenticated())
          .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    @Bean PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(); }

    @Bean AuthenticationManager authManager(AuthenticationConfiguration c) throws Exception {
        return c.getAuthenticationManager();
    }
}
```

### Auth controller (login + who-am-I)

```java
// security/AuthController.java
package com.vw.eacontext.security;

import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager authManager;
    private final UserRepository users;
    private final JwtService jwt;

    public record LoginRequest(String email, String password) {}

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody LoginRequest req) {
        authManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.email(), req.password()));

        AppUser u = users.findByEmail(req.email()).orElseThrow();
        List<String> perms = u.getRole().getPermissions().stream()
            .map(Permission::getCode).toList();

        String token = jwt.issue(u.getEmail(), u.getRole().getName(), perms);
        return Map.of(
            "token", token,
            "name", u.getName(),
            "role", u.getRole().getName(),
            "permissions", perms);
    }

    @GetMapping("/me")
    public Map<String, Object> me(Authentication auth) {
        return Map.of(
            "email", auth.getName(),
            "permissions", auth.getAuthorities().stream().map(Object::toString).toList());
    }
}
```

---

## A.4 Protect the **existing** endpoints (surgical, one line each)

In your existing `EaController`, add `@PreAuthorize` per method — no other changes:

```java
@PreAuthorize("hasAuthority('DATA_UPLOAD')")
@PostMapping("/upload")               public ValidationReport upload(...) { ... }

@PreAuthorize("hasAuthority('DIAGRAM_VIEW')")
@GetMapping("/graph/{frame}")         public GraphDto graph(...) { ... }

@PreAuthorize("hasAuthority('ANALYSIS_IMPACT')")
@GetMapping("/node/{id}/impact")      public ImpactAnalysisResult impact(...) { ... }

@PreAuthorize("hasAuthority('ANALYSIS_RISK')")
@GetMapping("/insights")              public List<Finding> insights() { ... }

@PreAuthorize("hasAuthority('AI_SUMMARY')")     // <-- gates AI cost
@GetMapping("/summary")               public SummaryResponse summary() { ... }

@PreAuthorize("hasAuthority('EXPORT_PNG') or hasAuthority('EXPORT_PDF') or hasAuthority('EXPORT_PPTX')")
@GetMapping("/export")                public ExportFile export(...) { ... }
```

---

## A.5 Admin API (`com.vw.eacontext.admin`)

```java
// admin/AdminController.java
package com.vw.eacontext.admin;

import com.vw.eacontext.security.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository users;
    private final RoleRepository roles;
    private final PermissionRepository permissions;
    private final PasswordEncoder encoder;
    private final AiSettingsService aiSettings;
    private final AuditService audit;

    // ---------- USERS ----------
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @GetMapping("/users")
    public List<AppUser> listUsers() { return users.findAll(); }

    public record CreateUser(String name, String email, String password, String roleName) {}

    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @PostMapping("/users")
    public AppUser createUser(@RequestBody CreateUser req) {
        Role role = roles.findByName(req.roleName()).orElseThrow();
        AppUser u = AppUser.builder()
            .name(req.name()).email(req.email())
            .passwordHash(encoder.encode(req.password()))
            .role(role).active(true).build();
        audit.log("USER_CREATED", req.email());
        return users.save(u);
    }

    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @PutMapping("/users/{id}/role")
    public AppUser changeRole(@PathVariable Long id, @RequestParam String roleName) {
        AppUser u = users.findById(id).orElseThrow();
        u.setRole(roles.findByName(roleName).orElseThrow());
        audit.log("USER_ROLE_CHANGED", u.getEmail() + " -> " + roleName);
        return users.save(u);
    }

    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @PutMapping("/users/{id}/active")
    public AppUser toggleActive(@PathVariable Long id, @RequestParam boolean active) {
        AppUser u = users.findById(id).orElseThrow();
        u.setActive(active);
        return users.save(u);
    }

    // ---------- ROLES ----------
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @GetMapping("/roles")
    public List<Role> listRoles() { return roles.findAll(); }

    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @PutMapping("/roles/{name}/permissions")
    public Role setPermissions(@PathVariable String name, @RequestBody List<String> codes) {
        Role role = roles.findByName(name).orElseThrow();
        Set<Permission> perms = new HashSet<>();
        for (String code : codes) perms.add(permissions.findByCode(code).orElseThrow());
        role.setPermissions(perms);
        audit.log("ROLE_PERMISSIONS_UPDATED", name + " = " + codes);
        return roles.save(role);
    }

    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @GetMapping("/permissions")
    public List<Permission> allPermissions() { return permissions.findAll(); }

    // ---------- AI SETTINGS ----------
    @PreAuthorize("hasAuthority('AI_CONFIG')")
    @GetMapping("/ai-settings")
    public AiSettings getAi() { return aiSettings.get(); }

    @PreAuthorize("hasAuthority('AI_CONFIG')")
    @PutMapping("/ai-settings")
    public AiSettings updateAi(@RequestBody AiSettings s) { return aiSettings.update(s); }

    // ---------- AUDIT ----------
    @PreAuthorize("hasAuthority('AUDIT_VIEW')")
    @GetMapping("/audit")
    public List<AuditEntry> auditLog() { return audit.recent(200); }
}
```

### AI settings (admin-controlled, DB-backed)

```java
// admin/AiSettings.java
package com.vw.eacontext.admin;

import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name = "ai_settings")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AiSettings {
    @Id private Long id;                    // single row, id = 1
    private boolean aiEnabled;              // master switch
    private String model;                   // "gpt-4o-mini" / "gpt-4o"
    private int dailyTokenBudgetPerUser;    // cost guardrail
    private boolean enrichmentEnabled;      // AI gap-filling
    private boolean agentEnabled;           // future autonomous agent
}
```

```java
// admin/AiSettingsService.java
package com.vw.eacontext.admin;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AiSettingsService {
    private final AiSettingsRepository repo;

    public AiSettings get() {
        return repo.findById(1L).orElseGet(() -> repo.save(AiSettings.builder()
            .id(1L).aiEnabled(true).model("gpt-4o-mini")
            .dailyTokenBudgetPerUser(5000).enrichmentEnabled(true).agentEnabled(false).build()));
    }
    public AiSettings update(AiSettings s) { s.setId(1L); return repo.save(s); }
}
```

*(`AiSettingsRepository`, `AuditEntry`, `AuditService` are trivial JPA repos/entities —
`AuditService.log(action, detail)` just persists a timestamped row.)*

---

## A.6 Seed default admin + permissions on startup

```java
// security/DataSeeder.java
package com.vw.eacontext.security;

import com.vw.eacontext.admin.AiSettingsService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final PermissionRepository permissions;
    private final RoleRepository roles;
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final AiSettingsService aiSettings;

    private static final List<String> ALL_PERMS = List.of(
        "DATA_UPLOAD","DATA_EDIT","DIAGRAM_VIEW","ANALYSIS_IMPACT","ANALYSIS_RISK",
        "AI_SUMMARY","AI_QUERY","AI_ENRICHMENT",
        "EXPORT_PNG","EXPORT_PDF","EXPORT_PPTX",
        "USER_MANAGE","ROLE_MANAGE","AI_CONFIG","AUDIT_VIEW");

    @Override
    public void run(String... args) {
        // 1. permissions
        for (String code : ALL_PERMS)
            permissions.findByCode(code).orElseGet(() ->
                permissions.save(Permission.builder().code(code).build()));

        // 2. SUPER_ADMIN with everything
        Role superAdmin = roles.findByName("SUPER_ADMIN").orElseGet(() ->
            roles.save(Role.builder().name("SUPER_ADMIN")
                .permissions(new HashSet<>(permissions.findAll())).build()));

        // 3. VIEWER (read-only, no AI)
        roles.findByName("VIEWER").orElseGet(() -> {
            Set<Permission> p = new HashSet<>();
            permissions.findByCode("DIAGRAM_VIEW").ifPresent(p::add);
            return roles.save(Role.builder().name("VIEWER").permissions(p).build());
        });
        // (ADMIN, ARCHITECT, ANALYST, GUEST seeded similarly)

        // 4. default admin user (change password on first login!)
        users.findByEmail("admin@contexa.local").orElseGet(() ->
            users.save(AppUser.builder()
                .name("Contexa Admin").email("admin@contexa.local")
                .passwordHash(encoder.encode("ChangeMe#123"))
                .role(superAdmin).active(true).build()));

        aiSettings.get(); // ensure single settings row exists
    }
}
```

---

## A.7 Frontend — Auth + Contexa Admin page

### Auth context + token storage

```jsx
// frontend/src/auth/AuthContext.jsx
import { createContext, useContext, useState } from "react";
import { api } from "../services/api";

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem("contexa_user");
    return raw ? JSON.parse(raw) : null;
  });

  async function login(email, password) {
    const { data } = await api.post("/auth/login", { email, password });
    localStorage.setItem("contexa_token", data.token);
    localStorage.setItem("contexa_user", JSON.stringify(data));
    setUser(data);
  }
  function logout() {
    localStorage.clear();
    setUser(null);
  }
  const can = (perm) => user?.permissions?.includes(perm);

  return <AuthCtx.Provider value={{ user, login, logout, can }}>{children}</AuthCtx.Provider>;
}
```

Attach the token to every request (add to your existing `services/api.js`):

```js
api.interceptors.request.use((cfg) => {
  const t = localStorage.getItem("contexa_token");
  if (t) cfg.headers.Authorization = `Bearer ${t}`;
  return cfg;
});
```

### Permission-gated rendering (used across existing components)

```jsx
// frontend/src/auth/RequirePermission.jsx
import { useAuth } from "./AuthContext";
export default function RequirePermission({ perm, children }) {
  const { can } = useAuth();
  return can(perm) ? children : null;
}
```

Now wrap existing buttons — e.g. in `InsightsPanel` / `ExportButton`:

```jsx
<RequirePermission perm="AI_SUMMARY">
  <button onClick={generateSummary}>✨ AI Summary</button>
</RequirePermission>

<RequirePermission perm="EXPORT_PPTX">
  <button onClick={() => exportDiagram("pptx")}>Export PPTX</button>
</RequirePermission>
```

### The Contexa Admin page (shown only to admins)

```jsx
// frontend/src/pages/ContexaAdmin.jsx
import { useEffect, useState } from "react";
import { useAuth } from "../auth/AuthContext";
import { api } from "../services/api";

export default function ContexaAdmin() {
  const { can } = useAuth();
  const [tab, setTab] = useState("users");

  // Guard: only admins ever render this page
  if (!can("USER_MANAGE") && !can("ROLE_MANAGE") && !can("AI_CONFIG"))
    return <div className="admin-denied">Access denied.</div>;

  return (
    <div className="contexa-admin">
      <h1>🛡️ Contexa Admin Console</h1>
      <nav className="admin-tabs">
        {can("USER_MANAGE") && <button onClick={() => setTab("users")}>Users</button>}
        {can("ROLE_MANAGE") && <button onClick={() => setTab("roles")}>Roles</button>}
        {can("AI_CONFIG")   && <button onClick={() => setTab("ai")}>AI Settings</button>}
        {can("AUDIT_VIEW")  && <button onClick={() => setTab("audit")}>Audit</button>}
      </nav>
      {tab === "users" && <UsersTab />}
      {tab === "roles" && <RolesTab />}
      {tab === "ai"    && <AiTab />}
      {tab === "audit" && <AuditTab />}
    </div>
  );
}

function UsersTab() {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  useEffect(() => {
    api.get("/admin/users").then(r => setUsers(r.data));
    api.get("/admin/roles").then(r => setRoles(r.data));
  }, []);
  const changeRole = (id, roleName) =>
    api.put(`/admin/users/${id}/role?roleName=${roleName}`).then(() =>
      api.get("/admin/users").then(r => setUsers(r.data)));

  return (
    <table className="admin-table">
      <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th></tr></thead>
      <tbody>
        {users.map(u => (
          <tr key={u.id}>
            <td>{u.name}</td><td>{u.email}</td>
            <td>
              <select value={u.role?.name} onChange={e => changeRole(u.id, e.target.value)}>
                {roles.map(r => <option key={r.id}>{r.name}</option>)}
              </select>
            </td>
            <td>{u.active ? "Active" : "Disabled"}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function RolesTab() {
  const [roles, setRoles] = useState([]);
  const [allPerms, setAllPerms] = useState([]);
  const [sel, setSel] = useState(null);
  useEffect(() => {
    api.get("/admin/roles").then(r => setRoles(r.data));
    api.get("/admin/permissions").then(r => setAllPerms(r.data.map(p => p.code)));
  }, []);
  const toggle = (code) => {
    const has = sel.permissions.some(p => p.code === code);
    const next = has ? sel.permissions.filter(p => p.code !== code)
                     : [...sel.permissions, { code }];
    setSel({ ...sel, permissions: next });
  };
  const save = () =>
    api.put(`/admin/roles/${sel.name}/permissions`, sel.permissions.map(p => p.code));

  return (
    <div className="roles-tab">
      <select onChange={e => setSel(roles.find(r => r.name === e.target.value))}>
        <option>-- pick role --</option>
        {roles.map(r => <option key={r.id}>{r.name}</option>)}
      </select>
      {sel && (
        <div className="perm-grid">
          {allPerms.map(code => (
            <label key={code}>
              <input type="checkbox"
                     checked={sel.permissions.some(p => p.code === code)}
                     onChange={() => toggle(code)} />
              {code}
            </label>
          ))}
          <button onClick={save}>Save Role</button>
        </div>
      )}
    </div>
  );
}

function AiTab() {
  const [s, setS] = useState(null);
  useEffect(() => { api.get("/admin/ai-settings").then(r => setS(r.data)); }, []);
  if (!s) return null;
  const save = () => api.put("/admin/ai-settings", s);
  return (
    <div className="ai-tab">
      <label>Master AI switch
        <input type="checkbox" checked={s.aiEnabled}
               onChange={e => setS({ ...s, aiEnabled: e.target.checked })} /></label>
      <label>Model
        <select value={s.model} onChange={e => setS({ ...s, model: e.target.value })}>
          <option>gpt-4o-mini</option><option>gpt-4o</option>
        </select></label>
      <label>Daily token budget / user
        <input type="number" value={s.dailyTokenBudgetPerUser}
               onChange={e => setS({ ...s, dailyTokenBudgetPerUser: +e.target.value })} /></label>
      <label>AI enrichment (smart ingestion)
        <input type="checkbox" checked={s.enrichmentEnabled}
               onChange={e => setS({ ...s, enrichmentEnabled: e.target.checked })} /></label>
      <button onClick={save}>Save AI Settings</button>
    </div>
  );
}

function AuditTab() {
  const [log, setLog] = useState([]);
  useEffect(() => { api.get("/admin/audit").then(r => setLog(r.data)); }, []);
  return (
    <ul className="audit-list">
      {log.map((e, i) => <li key={i}>{e.timestamp} — {e.actor} — {e.action} — {e.detail}</li>)}
    </ul>
  );
}
```

### Show the Admin entry only to admins (in `App.jsx` header)

```jsx
import { useAuth } from "./auth/AuthContext";
// ...
const { user, can } = useAuth();
{ (can("USER_MANAGE") || can("AI_CONFIG")) &&
    <button onClick={() => navigate("/admin")}>🛡️ Contexa Admin</button> }
```

---

# PART B — Smart Ingestion Layer (LLM-assisted, human-confirmed)

## B.1 The idea, mapped to your pipeline

Your current flow forces the dataset to match column names in `application.yml`. Smart
Ingestion removes that constraint: the LLM proposes a **column → canonical-field mapping**,
flags data problems, auto-corrects safe issues, and **shows the user the mapping for
confirmation before anything is loaded**.

```text
Upload messy file
      │
      ▼
1. SchemaDetectionService   ── extract headers + 3 sample rows PER entity sheet/array
      │        (deterministic; cheap; no full-file to LLM)
      ▼
2. SchemaMappingService     ── 🤖 LLM maps unknown columns → canonical fields
      │        returns { field → sourceColumn, confidence, reason }
      ▼
3. DataCleaningService      ── normalize safe issues (trim, case, "N/A"→null, dup-id rename)
      │        deterministic + optional 🤖 for ambiguous values
      ▼
4. MappingProposal (DTO)    ── mapping + confidence + cleaning actions + warnings
      │
      ▼   ────────── returned to UI  ──────────►  MappingReviewPanel
      │             user reviews / edits / approves
      ▼
5. On confirm: apply mapping  →  existing EaDataParser  →  CanonicalModel
      │        (your deterministic parser still builds the model — no hallucinated graph)
      ▼
6. ValidationService (existing) → ValidationReport → SessionModelStore
```

**Golden rule (keeps your trust model intact):** the LLM decides *structure* (mapping) and
*suggestions*; **Java builds the data**. Facts still come from the graph, never the model.

---

## B.2 Where to keep the API key  ⭐ (your explicit question)

**Never** put the key in code, `application.yml`, or Git. Layered approach:

### Local dev — environment variables (already your pattern)
Your project already reads Azure creds via env + the `ai` profile. Reuse it:

```powershell
$env:AZURE_OPENAI_ENDPOINT   = "https://<resource>.openai.azure.com"
$env:AZURE_OPENAI_API_KEY    = "<key>"
$env:AZURE_OPENAI_DEPLOYMENT = "gpt-4o-mini"
```

`application-ai.yml` references them (no literal secrets):

```yaml
ea:
  ai:
    azure:
      endpoint:   ${AZURE_OPENAI_ENDPOINT}
      api-key:    ${AZURE_OPENAI_API_KEY}
      deployment: ${AZURE_OPENAI_DEPLOYMENT}
      api-version: "2024-06-01"
    ingestion:
      model: ${AZURE_OPENAI_DEPLOYMENT}   # gpt-4o-mini for cheap schema mapping
      max-sample-rows: 3
```

Add to `.gitignore`:

```text
*.env
.env
application-local.yml
```

### Production — a secrets manager (do NOT ship env vars)
- **Azure Key Vault** + Managed Identity (best fit — you're already on Azure OpenAI).
  App reads the key at runtime; no secret on disk. Spring:
  `spring-cloud-azure-starter-keyvault-secrets`.
- Alternatives: HashiCorp Vault, AWS Secrets Manager, Kubernetes Secrets.
- Rotate keys periodically; log key **usage**, never the key value.

### Typed properties (reuse your existing pattern)

```java
// config/AzureOpenAiProperties.java  (extend existing)
@ConfigurationProperties(prefix = "ea.ai.azure")
public record AzureOpenAiProperties(
    String endpoint, String apiKey, String deployment, String apiVersion) {}
```

The key is injected by Spring from env/Key Vault → never referenced literally anywhere.

---

## B.3 New sub-package: `com.vw.eacontext.ingestion.smart`

### DTOs — the mapping proposal returned to the UI

```java
// ingestion/smart/ColumnMapping.java
package com.vw.eacontext.ingestion.smart;

public record ColumnMapping(
    String canonicalField,   // e.g. "owner"
    String sourceColumn,     // e.g. "Responsible Team"
    double confidence,       // 0.0 - 1.0
    String reason            // short LLM justification
) {}
```

```java
// ingestion/smart/CleaningAction.java
package com.vw.eacontext.ingestion.smart;

public record CleaningAction(
    String column, String before, String after, String rule
) {}   // e.g. ("owner","N/A",null,"empty-normalization")
```

```java
// ingestion/smart/MappingProposal.java
package com.vw.eacontext.ingestion.smart;

import java.util.List;

public record MappingProposal(
    String entity,                    // "application", "interface", ...
    List<String> sourceColumns,       // what we found in the file
    List<ColumnMapping> mappings,     // proposed canonical mapping
    List<String> unmappedColumns,     // columns we couldn't place
    List<String> missingRequired,     // required canonical fields with no source
    List<CleaningAction> cleaning,    // auto-corrections applied
    List<String> warnings             // human-readable data problems
) {}
```

### 1) Schema detection (deterministic, cheap)

```java
// ingestion/smart/SchemaDetectionService.java
package com.vw.eacontext.ingestion.smart;

import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class SchemaDetectionService {

    /** Returns headers + up to N sample rows for one entity table. */
    public record TableSample(String entity, List<String> headers, List<Map<String,String>> rows) {}

    public TableSample detect(String entity, List<Map<String,String>> rawRows, int maxRows) {
        if (rawRows.isEmpty())
            return new TableSample(entity, List.of(), List.of());
        List<String> headers = new ArrayList<>(rawRows.get(0).keySet());
        List<Map<String,String>> sample = rawRows.stream().limit(maxRows).toList();
        return new TableSample(entity, headers, sample);
    }
}
```

### 2) LLM schema mapping (the smart bit) — sends only headers + 3 rows

```java
// ingestion/smart/SchemaMappingService.java
package com.vw.eacontext.ingestion.smart;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vw.eacontext.config.AzureOpenAiProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.*;

@Service
@RequiredArgsConstructor
public class SchemaMappingService {

    private final AzureOpenAiProperties props;
    private final ObjectMapper json;
    private final WebClient webClient = WebClient.builder().build();

    /** Canonical fields the model must map to, per entity. */
    private static final Map<String, List<String>> CANONICAL = Map.of(
        "application", List.of("id","name","owner","domain","lifecycleStatus","techStack","processId"),
        "interface",   List.of("id","name","provider","consumer","type","dataObject"),
        "businessProcess", List.of("id","name","domain"),
        "domain",      List.of("id","name"),
        "informationObject", List.of("id","name"));

    public List<ColumnMapping> map(String entity, List<String> headers,
                                   List<Map<String,String>> sampleRows) {
        List<String> targetFields = CANONICAL.getOrDefault(entity, List.of());
        String prompt = buildPrompt(entity, targetFields, headers, sampleRows);

        try {
            String content = callAzure(prompt);         // returns strict JSON
            return parse(content);
        } catch (Exception e) {
            // graceful fallback: exact/lowercase name match, confidence 1.0/0.5
            return fallbackMap(targetFields, headers);
        }
    }

    private String buildPrompt(String entity, List<String> fields,
                               List<String> headers, List<Map<String,String>> rows) {
        return """
            You are a schema-mapping engine for enterprise-architecture data.
            Map the SOURCE COLUMNS to our CANONICAL FIELDS for entity "%s".

            CANONICAL FIELDS: %s
            SOURCE COLUMNS:   %s
            SAMPLE ROWS (JSON): %s

            Rules:
            - Map each canonical field to the best-matching source column, or null if none.
            - Give a confidence 0.0-1.0 and a one-line reason.
            - Do NOT invent data. Only map columns that exist.
            Return ONLY valid JSON:
            {"mappings":[{"canonicalField":"...","sourceColumn":"...","confidence":0.0,"reason":"..."}]}
            """.formatted(entity, fields, headers, safeJson(rows));
    }

    private String callAzure(String userPrompt) {
        String url = props.endpoint() + "/openai/deployments/" + props.deployment()
                   + "/chat/completions?api-version=" + props.apiVersion();

        Map<String,Object> body = Map.of(
            "temperature", 0,
            "response_format", Map.of("type","json_object"),
            "messages", List.of(
                Map.of("role","system","content","You output only strict JSON."),
                Map.of("role","user","content", userPrompt)));

        Map<?,?> resp = webClient.post().uri(url)
            .header("api-key", props.apiKey())          // key injected from env/Key Vault
            .bodyValue(body)
            .retrieve().bodyToMono(Map.class)
            .timeout(Duration.ofSeconds(20))
            .block();

        var choices = (List<?>) resp.get("choices");
        var msg = (Map<?,?>) ((Map<?,?>) choices.get(0)).get("message");
        return (String) msg.get("content");
    }

    private List<ColumnMapping> parse(String content) throws Exception {
        var node = json.readTree(content).get("mappings");
        List<ColumnMapping> out = new ArrayList<>();
        node.forEach(m -> out.add(new ColumnMapping(
            m.get("canonicalField").asText(),
            m.hasNonNull("sourceColumn") ? m.get("sourceColumn").asText() : null,
            m.get("confidence").asDouble(),
            m.path("reason").asText(""))));
        return out;
    }

    private List<ColumnMapping> fallbackMap(List<String> fields, List<String> headers) {
        List<ColumnMapping> out = new ArrayList<>();
        for (String f : fields) {
            String exact = headers.stream()
                .filter(h -> h.equalsIgnoreCase(f)).findFirst().orElse(null);
            out.add(new ColumnMapping(f, exact, exact != null ? 1.0 : 0.0,
                exact != null ? "exact name match" : "no match found"));
        }
        return out;
    }

    private String safeJson(Object o) {
        try { return json.writeValueAsString(o); } catch (Exception e) { return "[]"; }
    }
}
```

### 3) Data cleaning (deterministic first, LLM only for ambiguity)

```java
// ingestion/smart/DataCleaningService.java
package com.vw.eacontext.ingestion.smart;

import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class DataCleaningService {

    /** Safe, explainable normalizations. Every change is recorded for the UI. */
    public List<CleaningAction> clean(List<Map<String,String>> rows) {
        List<CleaningAction> actions = new ArrayList<>();
        Set<String> seenIds = new HashSet<>();

        for (Map<String,String> row : rows) {
            for (var e : row.entrySet()) {
                String col = e.getKey(), val = e.getValue();
                if (val == null) continue;

                String trimmed = val.trim().replaceAll("\\s+", " ");
                if (!trimmed.equals(val)) {
                    actions.add(new CleaningAction(col, val, trimmed, "whitespace-normalization"));
                    row.put(col, trimmed); val = trimmed;
                }
                if (List.of("n/a","na","null","-","").contains(val.toLowerCase())) {
                    actions.add(new CleaningAction(col, val, null, "empty-normalization"));
                    row.put(col, null);
                }
            }
            // duplicate-id detection (does not silently drop; flags + suffixes)
            String id = row.get("id");
            if (id != null && !seenIds.add(id)) {
                String fixed = id + "_dup";
                actions.add(new CleaningAction("id", id, fixed, "duplicate-id-rename"));
                row.put("id", fixed);
            }
        }
        return actions;
    }
}
```

### 4) Orchestrator — builds the proposal, respects admin AI toggle + permission

```java
// ingestion/smart/SmartIngestionService.java
package com.vw.eacontext.ingestion.smart;

import com.vw.eacontext.admin.AiSettingsService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class SmartIngestionService {

    private final SchemaDetectionService detection;
    private final SchemaMappingService mapping;
    private final DataCleaningService cleaning;
    private final AiSettingsService aiSettings;

    private static final Map<String,List<String>> REQUIRED = Map.of(
        "application", List.of("id","name"),
        "interface",   List.of("id","provider","consumer"));

    public MappingProposal analyze(String entity, List<Map<String,String>> rawRows) {
        var sample = detection.detect(entity, rawRows, 3);

        // AI mapping only if admin enabled it; else deterministic fallback
        List<ColumnMapping> maps = aiSettings.get().isEnrichmentEnabled()
            ? mapping.map(entity, sample.headers(), sample.rows())
            : deterministic(entity, sample.headers());

        List<CleaningAction> actions = cleaning.clean(rawRows);

        Set<String> mappedCols = new HashSet<>();
        maps.forEach(m -> { if (m.sourceColumn() != null) mappedCols.add(m.sourceColumn()); });

        List<String> unmapped = sample.headers().stream()
            .filter(h -> !mappedCols.contains(h)).toList();

        List<String> missingRequired = REQUIRED.getOrDefault(entity, List.of()).stream()
            .filter(f -> maps.stream().noneMatch(
                m -> m.canonicalField().equals(f) && m.sourceColumn() != null))
            .toList();

        List<String> warnings = new ArrayList<>();
        maps.stream().filter(m -> m.sourceColumn() != null && m.confidence() < 0.6)
            .forEach(m -> warnings.add("Low-confidence mapping: '" + m.sourceColumn()
                + "' → " + m.canonicalField() + " (" + (int)(m.confidence()*100) + "%)"));
        if (!missingRequired.isEmpty())
            warnings.add("Missing required fields: " + missingRequired);

        return new MappingProposal(entity, sample.headers(), maps, unmapped,
            missingRequired, actions, warnings);
    }

    private List<ColumnMapping> deterministic(String entity, List<String> headers) {
        return mapping.map(entity, headers, List.of()); // uses fallback path internally
    }
}
```

### 5) Endpoints — analyze (propose) then confirm (apply)

```java
// ingestion/smart/SmartIngestController.java
package com.vw.eacontext.ingestion.smart;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

@RestController
@RequestMapping("/api/ingest")
@RequiredArgsConstructor
public class SmartIngestController {

    private final SmartIngestionService smart;
    private final SmartApplyService apply;   // applies confirmed mapping → EaDataParser

    /** Step 1: propose mapping — user reviews before anything is loaded. */
    @PreAuthorize("hasAuthority('DATA_UPLOAD')")
    @PostMapping("/analyze")
    public List<MappingProposal> analyze(@RequestParam("file") MultipartFile file) throws Exception {
        // RawTableExtractor turns json/xlsx/zip into Map<entity, List<row>>
        Map<String, List<Map<String,String>>> tables = apply.extractRaw(file);
        List<MappingProposal> proposals = new ArrayList<>();
        tables.forEach((entity, rows) -> proposals.add(smart.analyze(entity, rows)));
        return proposals;   // frontend renders MappingReviewPanel
    }

    /** Step 2: user-approved (possibly edited) mapping is applied. */
    public record ConfirmRequest(String uploadId, List<MappingProposal> approvedMappings) {}

    @PreAuthorize("hasAuthority('DATA_UPLOAD')")
    @PostMapping("/confirm")
    public Object confirm(@RequestBody ConfirmRequest req) {
        // applies mapping, runs existing EaDataParser → CanonicalModel → SessionModelStore
        return apply.applyAndLoad(req.uploadId(), req.approvedMappings());
    }
}
```

*(`SmartApplyService` reuses your existing parsers: it rewrites source columns to canonical
names per the approved mapping, then delegates to `JsonEaDataParser` / `ExcelEaDataParser` /
`CsvEaDataParser` so the `CanonicalModel` is still built deterministically, then runs your
existing `ValidationService` and `SessionModelStore.load()`.)*

---

## B.4 Frontend — Mapping Review Panel (transparency you asked for)

The user is **shown exactly how each column is mapped**, with confidence, warnings, and
cleaning actions — and can override before confirming.

```jsx
// frontend/src/components/MappingReviewPanel.jsx
import { useState } from "react";
import { api } from "../services/api";

export default function MappingReviewPanel({ proposals, uploadId, onLoaded }) {
  const [edited, setEdited] = useState(proposals);

  const setSource = (pi, mi, value) => {
    const copy = structuredClone(edited);
    copy[pi].mappings[mi].sourceColumn = value || null;
    setEdited(copy);
  };
  const confirm = () =>
    api.post("/ingest/confirm", { uploadId, approvedMappings: edited })
       .then(r => onLoaded(r.data));

  return (
    <div className="mapping-review">
      <h2>Review data mapping</h2>
      {edited.map((p, pi) => (
        <section key={p.entity} className="entity-block">
          <h3>{p.entity}</h3>

          {p.warnings.length > 0 && (
            <ul className="warnings">{p.warnings.map((w, i) => <li key={i}>⚠️ {w}</li>)}</ul>
          )}

          <table className="mapping-table">
            <thead><tr><th>Canonical field</th><th>Mapped from</th><th>Confidence</th><th>Why</th></tr></thead>
            <tbody>
              {p.mappings.map((m, mi) => (
                <tr key={m.canonicalField}
                    className={m.confidence < 0.6 ? "low-conf" : ""}>
                  <td><b>{m.canonicalField}</b></td>
                  <td>
                    <select value={m.sourceColumn ?? ""}
                            onChange={e => setSource(pi, mi, e.target.value)}>
                      <option value="">— none —</option>
                      {p.sourceColumns.map(c => <option key={c}>{c}</option>)}
                    </select>
                  </td>
                  <td>{m.sourceColumn ? `${Math.round(m.confidence * 100)}%` : "—"}</td>
                  <td className="reason">{m.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {p.unmappedColumns.length > 0 &&
            <p className="unmapped">Ignored columns: {p.unmappedColumns.join(", ")}</p>}

          {p.cleaning.length > 0 && (
            <details>
              <summary>{p.cleaning.length} auto-corrections applied</summary>
              <ul>{p.cleaning.map((c, i) =>
                <li key={i}><code>{c.column}</code>: “{c.before}” → “{c.after ?? "∅"}” ({c.rule})</li>)}
              </ul>
            </details>
          )}
        </section>
      ))}
      <button className="confirm-btn" onClick={confirm}>Confirm & Load</button>
    </div>
  );
}
```

New upload flow: `UploadButton` → `POST /api/ingest/analyze` → render
`MappingReviewPanel` → user confirms → `POST /api/ingest/confirm` → existing
graph/insights/summary refresh (your `refreshKey++` pattern).

---

## B.5 Which model to use (and why)

| Task                         | Model                     | Why |
|------------------------------|---------------------------|-----|
| Schema mapping (per upload)  | **gpt-4o-mini**           | tiny prompt (headers + 3 rows), cheap, supports strict JSON output |
| Ambiguous value cleaning     | gpt-4o-mini               | rare, small |
| Landscape summary (existing) | gpt-4o                    | better prose |
| Future RAG embeddings        | text-embedding-3-small    | doc search |

**Never send the whole file to the LLM** — only headers + a few sample rows. Java loops the
thousands of rows deterministically. This is cheap, fast, and hallucination-proof.

---

# PART C — Rollout plan & guardrails

```text
PHASE 1  RBAC core
  • add security package, JWT, SecurityConfig
  • seed SUPER_ADMIN + VIEWER
  • @PreAuthorize on existing EaController endpoints
  • frontend LoginPage + AuthProvider + token interceptor

PHASE 2  Contexa Admin page
  • AdminController (users, roles, ai-settings, audit)
  • ContexaAdmin.jsx (4 tabs) shown only to admins
  • RequirePermission wrappers on AI / export buttons

PHASE 3  Smart ingestion
  • ingestion.smart package + /api/ingest/analyze & /confirm
  • MappingReviewPanel; wire Azure key via env / Key Vault
  • gate AI mapping behind AiSettings.enrichmentEnabled + AI_ENRICHMENT perm

PHASE 4  Hardening
  • PostgreSQL instead of H2
  • Azure Key Vault + Managed Identity for the API key
  • token-budget enforcement per user (from AiSettings)
  • audit every AI call, upload, role change
```

### Security guardrails
- Frontend hiding is UX only — **every** rule is also enforced by `@PreAuthorize`.
- JWT is stateless; keep `contexa.jwt.secret` itself in env/Key Vault (min 32 bytes).
- Log AI **usage** and token counts, never the key or full dataset.
- Smart ingestion always requires **human confirmation** before load — AI proposes, user disposes.

---

## Summary

- **RBAC**: `User → Role → Permission → Feature`, JWT-secured, with a dedicated
  **Contexa Admin** page (Users / Roles / AI Settings / Audit) that renders only for admins
  and lets them grant AI features individually and cap token spend.
- **Smart Ingestion**: LLM maps any messy dataset to your canonical fields, auto-corrects
  safe issues, and **shows the user the full column→field mapping + warnings for
  confirmation** before your existing deterministic parsers build the `CanonicalModel`.
- **API key**: env vars (dev) → **Azure Key Vault + Managed Identity** (prod); never in code
  or Git; referenced only via `AzureOpenAiProperties`.
- Everything bolts onto your current `com.vw.eacontext` architecture without disturbing the
  graph-first, in-memory pipeline that makes Context Cartography fast and trustworthy.
