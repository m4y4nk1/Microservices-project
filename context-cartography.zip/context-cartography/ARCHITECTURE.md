# Context Cartography - Complete Architecture Analysis

## 📋 Project Overview

**Context Cartography** is an AI-powered Enterprise Architecture (EA) Context Diagram Generator built with a Spring Boot 3 backend (Java 21) and a React frontend. It ingests EA datasets in multiple formats (JSON, Excel, CSV), builds a dependency graph, detects architectural issues via insights, and provides an interactive visualization with AI-powered summaries.

### Core Purpose
Transform raw EA data into:
- Interactive dependency graphs with multiple observation frames
- Automated architectural issue detection
- Natural language landscape summaries
- Exportable reports (PNG, PDF, PPTX)

---

## 🏗️ High-Level Architecture

### Multi-Tier Architecture Pattern

```
┌──────────────────────────────────────────────────────────┐
│                    Frontend (React)                       │
│              Interactive UI with Cytoscape.js            │
├──────────────────────────────────────────────────────────┤
│                  REST API Layer (Spring)                  │
│              EaController + EaContextService              │
├──────────────────────────────────────────────────────────┤
│        Business Logic Layer (Multiple Concerns)           │
│  Ingestion │ Validation │ Graph │ Insight │ Export │ AI  │
├──────────────────────────────────────────────────────────┤
│                   Data Store Layer                        │
│        In-Memory Session Store (No Database)             │
└──────────────────────────────────────────────────────────┘
```

### Key Design Principles
- **No Database**: In-memory session store (model cached per session)
- **Pluggable Ingestion**: Multiple format parsers (JSON/Excel/CSV)
- **Config-Driven Mapping**: Externalized column mapping via `application.yml`
- **Immutable Domain Model**: Record-based canonical model
- **Graph-First Approach**: JGraphT for application dependency analysis
- **Multiple Observation Frames**: Different projections of the same data
- **Error Resilience**: Validation never throws; returns structured reports

---

## 📁 Directory Structure & File Organization

### Root Level
```
context-cartography/
├── backend/                    # Spring Boot application
│   ├── pom.xml                # Maven configuration
│   ├── mvnw / mvnw.cmd        # Maven wrapper (cross-platform)
│   ├── HELP.md                # Build documentation
│   └── src/
│       ├── main/java/com/vw/eacontext/
│       │   ├── model/         # Domain model (Records)
│       │   ├── ingestion/     # Data parsers
│       │   ├── validation/    # Data quality validation
│       │   ├── graph/         # Dependency graph building
│       │   ├── insight/       # Issue detection
│       │   ├── api/           # REST endpoints & services
│       │   ├── ai/            # Summary generation
│       │   ├── config/        # Spring configuration
│       │   ├── dto/           # Request/Response DTOs
│       │   ├── exception/     # Custom exceptions & handler
│       │   └── EaContextApplication.java  # Spring Boot entry
│       ├── main/resources/
│       │   ├── application.yml         # Configuration
│       │   ├── application-ai.yml      # AI profile config
│       │   ├── sample_ea_dataset.json  # Sample data
│       │   ├── sample_ea_dataset.xlsx  # Sample data
│       │   ├── EA_Context_Diagram_Prototype.html
│       │   ├── static/                 # Served static files
│       │   └── templates/              # Thymeleaf templates (if used)
│       └── test/java/                  # Unit & integration tests
├── frontend/                   # React + Vite application
│   ├── package.json           # npm dependencies
│   ├── vite.config.js         # Vite build configuration
│   ├── eslint.config.js       # Linting rules
│   ├── index.html             # Entry HTML
│   ├── src/
│   │   ├── main.jsx           # React app entry
│   │   ├── App.jsx            # Root component
│   │   ├── App.css            # Global styles
│   │   ├── index.css          # Base styles
│   │   ├── components/        # Reusable UI components
│   │   │   ├── GraphCanvas.jsx        # Cytoscape visualization
│   │   │   ├── FrameTabs.jsx          # Frame selector
│   │   │   ├── FilterPanel.jsx        # Domain/lifecycle filters
│   │   │   ├── InsightsPanel.jsx      # Issues + summary display
│   │   │   ├── NodeDetail.jsx         # Selected node details
│   │   │   ├── UploadButton.jsx       # Dataset uploader
│   │   │   ├── ExportButton.jsx       # Export dialog
│   │   │   ├── Toast.jsx              # Notifications
│   │   │   └── *.css                  # Component styles
│   │   ├── hooks/             # React custom hooks
│   │   │   ├── useGraphData.js        # Fetch & cache graph
│   │   │   ├── useInsights.js         # Fetch & cache findings
│   │   │   └── useSummary.js          # Fetch & cache summary
│   │   ├── services/          # API & data transformation
│   │   │   ├── api.js                 # Axios instance + endpoints
│   │   │   ├── graphAdapter.js        # GraphDto → Cytoscape conversion
│   │   │   └── insightAdapter.js      # Finding → UI classes
│   │   ├── styles/            # Shared stylesheets
│   │   └── assets/            # Images, icons
│   ├── public/                # Static assets
│   │   ├── favicon.svg
│   │   └── icons.svg
│   └── reference/             # Documentation & prototypes
└── README.md                  # Project overview
```

---

## 🔧 Backend Architecture (Spring Boot)

### 1. **Model Layer** (`model/`)
**Purpose**: Define the canonical domain model for all EA entities.

**Key Files**:
- **CanonicalModel.java** (Record)
  - Immutable root aggregate containing all ingested entities
  - Guaranteed non-null, empty lists (never null)
  - Single source of truth across all layers
  - Structure:
    ```java
    record CanonicalModel(
        List<Domain> domains,
        List<BusinessProcess> businessProcesses,
        List<Application> applications,
        List<Interface> interfaces,
        List<InformationObject> informationObjects
    )
    ```

- **Domain.java**, **BusinessProcess.java**, **Application.java**, etc. (Records)
  - Immutable data carriers for each EA entity
  - No business logic (pure data)
  - Property-mapped from source files via column configuration

- **Enums**: `LifecycleStatus`, `InterfaceType`
  - Standard EA classification values
  - Used for filtering and insight detection

**Why Records?**
- Compiler-generated `equals()`, `hashCode()`, `toString()`
- Immutability guarantees thread-safety
- Concise, readable code

---

### 2. **Ingestion Layer** (`ingestion/`)
**Purpose**: Parse EA data from multiple file formats into the canonical model.

**Key Files**:
- **EaDataParser.java** (Interface)
  - Single contract: `CanonicalModel parse(InputStream in)`
  - Format-agnostic abstraction

- **JsonEaDataParser.java**
  - Uses Jackson to deserialize JSON
  - Expects top-level arrays named in config: `domains`, `businessProcesses`, `applications`, etc.
  - Maps fields per `ea.ingestion.json.roots` in `application.yml`

- **ExcelEaDataParser.java**
  - Uses Apache POI to read `.xlsx` files
  - One worksheet per entity (configurable sheet names)
  - Maps fields per `ea.ingestion.excel.sheets` in `application.yml`

- **CsvEaDataParser.java**
  - Handles `.zip` archives containing individual CSV files
  - Each entity type has a separate CSV file (configurable names)
  - Uses Apache Commons CSV for parsing
  - Maps fields per `ea.ingestion.csv.files` in `application.yml`

- **IngestionSupport.java**
  - Shared utility methods for all parsers
  - Column mapping logic (source → canonical field)
  - Type conversion helpers

**Design Pattern**: **Strategy Pattern**
- Different parsers implement same interface
- Swappable without changing orchestration layer
- Easy to add new formats (e.g., Protobuf, Avro)

**Column Mapping** (Config-Driven)
Example from `application.yml`:
```yaml
ea.ingestion.fields.application:
  id: id
  name: name
  owner: owner
  domain: domain
  lifecycleStatus: lifecycleStatus
  techStack: techStack
  processId: process
```
- Left: canonical field name (immutable)
- Right: source column/property name (customizable)
- Enables supporting different data schemas without code changes

---

### 3. **Validation Layer** (`validation/`)
**Purpose**: Detect data-quality issues without throwing exceptions.

**Key Files**:
- **ValidationReport.java**
  - Container for all validation results
  - Fields: `issues: List<ValidationIssue>`, `summary: String`
  - Returned on upload; frontend displays severity counts

- **ValidationIssue.java**
  - Single issue record: `id`, `type`, `severity`, `message`, `affected: List<String>`
  - Severity: `ERROR`, `WARNING`, `INFO`
  - Never stops processing; all issues collected in one pass

- **ValidationService.java**
  - Orchestrates all validation checks:
    - Required fields present
    - Unique application/interface/etc. IDs
    - Referential integrity (interfaces reference valid apps)
    - Orphan entities (domains, processes not referenced)
  - Returns non-null `ValidationReport` for all inputs

**Philosophy**: Graceful Degradation
- Invalid data is logged, not thrown
- Enables partial loading of broken datasets
- Frontend shows user what's wrong

---

### 4. **Graph Layer** (`graph/`)
**Purpose**: Build and analyze application dependency graph.

**Key Files**:
- **GraphBuilderService.java**
  - Converts `CanonicalModel` into JGraphT `DirectedPseudograph<Application, InterfaceEdge>`
  - Algorithm:
    1. Add all applications as vertices
    2. Index applications by ID
    3. For each interface, resolve provider and consumer apps
    4. Create directed edge from provider → consumer
    5. Attach interface metadata to edge via `InterfaceEdge`
  - Handles self-loops (app integrating with itself) and parallel edges
  - Skips interfaces with unresolved apps (validation reports these)

- **InterfaceEdge.java**
  - Wrapper carrying interface metadata
  - Holds: interface ID, name, type, data object
  - Used by insights to analyze edge characteristics

- **GraphProjectionService.java**
  - Creates multiple node/edge projections from one graph:
    - **Application View**: Apps as nodes, interfaces as edges (default)
    - **Business Process View**: Processes as nodes, app→process mappings as edges
    - **Domain View**: Domains as nodes, apps aggregated within domains
    - **Information Flow View**: Data objects as nodes, interfaces as flows
  - Each frame provides different architectural perspective

- **ImpactAnalysisService.java**
  - Computes "blast radius" for any application
  - Returns:
    - **Upstream**: All applications that directly/indirectly provide to target
    - **Downstream**: All applications that directly/indirectly consume from target
  - Uses graph traversal (BFS/DFS)
  - Useful for change impact assessment

**Graph Choice: DirectedPseudograph**
- Supports multiple parallel edges between same pair of nodes
- Supports self-loops (important for some EA scenarios)
- JGraphT provides algorithms: traversal, shortest path, cycles, etc.

---

### 5. **Insight Layer** (`insight/`)
**Purpose**: Detect architecturally significant patterns and issues.

**Key Files**:
- **InsightService.java**
  - Runs 5 detectors over canonical model + graph
  - Returns flat `List<Finding>`

- **Finding.java**
  - Single issue record: `type: FindingType`, `severity: Severity`, `entityId: String`, `message: String`
  - Types:
    - `OWNERSHIP_GAP`: Application has no owner
    - `ORPHAN_INTERFACE`: Interface has no consumer
    - `MISSING_PROCESS_MAPPING`: App not mapped to business process
    - `LIFECYCLE_RISK`: App is EOL or DEPRECATED
    - `DEPENDENCY_HOTSPOT`: App exceeds degree threshold (single point of failure)

- **FindingType.java** (Enum)
  - Classification of issue types
  - Used for grouping and filtering in UI

**Detectors**:
1. **detectOwnershipGaps**: Scan apps for null/blank owner
2. **detectOrphanInterfaces**: Scan interfaces for null consumer
3. **detectMissingProcessMappings**: Scan apps for null processId
4. **detectLifecycleRisks**: Flag EOL/DEPRECATED apps
5. **detectDependencyHotspots**: Scan graph; flag apps with degree > threshold

**Design**: Separation of Concerns
- Each detector is independent
- Easy to add/remove detectors
- Findings are immutable, collected in order
- No exception throwing; all issues captured

---

### 6. **AI Layer** (`ai/`)
**Purpose**: Generate natural-language summaries of landscapes.

**Key Files**:
- **SummaryGenerator.java** (Interface)
  - Single method: `String summarize(List<Finding> findings, GraphStats stats)`
  - Two implementations (pluggable via Spring):

- **TemplateSummaryGenerator.java**
  - Default, deterministic implementation
  - No external calls; instant
  - Builds template-based summary:
    - Overview (app count, domain count, interface count, etc.)
    - Issue totals by severity
    - Sections per finding type with affected IDs (sorted for stability)
    - Hotspot highlight
  - Guarantees same input → same output

- **AzureOpenAiSummaryGenerator.java** (Optional, with `ai` profile)
  - Calls Azure OpenAI API via Spring WebClient
  - Uses prompt engineering to generate richer insights
  - Falls back to `TemplateSummaryGenerator` on error/timeout
  - Enabled via:
    ```bash
    -Dspring-boot.run.profiles=ai \
    -DAZURE_OPENAI_ENDPOINT=... \
    -DAZURE_OPENAI_API_KEY=... \
    -DAZURE_OPENAI_DEPLOYMENT=...
    ```

**Wiring** (AiConfig.java):
```java
@Bean
@ConditionalOnMissingBean(SummaryGenerator.class)
public SummaryGenerator templateSummaryGenerator() {
    return new TemplateSummaryGenerator();
}
```
- Template is default fallback
- If Azure implementation is present, it takes precedence
- No code changes needed to swap implementations

---

### 7. **API Layer** (`api/`)
**Purpose**: REST endpoints and orchestration.

**Key Files**:
- **EaController.java**
  - REST Controller at `/api`
  - Endpoints:
    - `POST /upload`: Upload dataset file
    - `GET /graph/{frame}`: Fetch projection
    - `GET /node/{id}/impact`: Blast radius analysis
    - `GET /insights`: All findings
    - `GET /summary`: Natural-language summary
    - `GET /export`: Download PNG/PDF/PPTX report

- **EaContextService.java**
  - Application service layer
  - Orchestrates workflow:
    1. Receive file → choose parser
    2. Parse → load into store
    3. Validate → return report
    4. On GET requests, reuse cached artifacts
  - No business logic; choreography only

- **SessionModelStore.java**
  - In-memory session storage (no database)
  - Thread-safe (synchronized `load()`)
  - Caches:
    - `CanonicalModel`: Raw ingested data
    - `Graph<Application, InterfaceEdge>`: Built dependency graph
    - `List<Finding>`: Detected issues
    - `GraphStats`: Aggregate statistics
  - Single `Session` record per request lifecycle
  - Throws `ModelNotLoadedException` if no model loaded

- **ExportService.java**
  - Renders PNG/PDF/PPTX exports
  - Formats: text + findings → image/PDF/slides
  - Uses Java 2D (images), PDFBox (PDF), POI (PPTX)
  - Lightweight text-based (not visual diagram render)

- **SampleDataInitializer.java**
  - Spring `@Component` with `@PostConstruct`
  - Auto-loads bundled sample dataset on startup
  - Can be disabled via `ea.sample.autoload=false`
  - Enables API testing without upload

---

### 8. **DTO Layer** (`dto/`)
**Purpose**: Request/response data transfer objects.

**Key Files**:
- **GraphDto.java**
  - Container for node/edge projection
  - Fields: `nodes: List<GraphNode>`, `edges: List<GraphEdge>`
  - Returned by `/api/graph/{frame}`

- **GraphNode.java**
  - Node representation
  - Fields: `id`, `label`, `type`, `data` (domain, owner, etc.)
  - Frontend assigns colors based on domain

- **GraphEdge.java**
  - Edge representation
  - Fields: `source`, `target`, `label`, `type`
  - Flows → Cytoscape rendering

- **GraphStats.java**
  - Aggregate statistics
  - Fields: application count, interface count, domain count, most connected app, etc.
  - Used by summary generator

- **ImpactAnalysisResult.java**
  - Blast radius result
  - Fields: `application`, `upstream`, `downstream`
  - Lists of affected app IDs

- **ValidationReport.java**, **ValidationIssue.java**
  - Validation results (see Validation Layer)

- **SummaryResponse.java**, **ExportFile.java**, **Frame.java**, **ApiError.java**
  - Other API payloads

---

### 9. **Exception Handling** (`exception/`)
**Key Files**:
- **GlobalExceptionHandler.java** (Spring `@ControllerAdvice`)
  - Centralizes error response formatting
  - Catches custom exceptions:
    - `EaIngestionException`: Parse/ingestion errors
    - `EaNotFoundException`: Resource not found
    - `ModelNotLoadedException`: No dataset loaded
  - Returns structured JSON: `{ timestamp, status, error, message, details }`

- Custom exception classes
  - All extend `RuntimeException`
  - Carry contextual information
  - Never trigger automatic rollback (no @Transactional)

---

### 10. **Configuration Layer** (`config/`)
**Key Files**:
- **application.yml**
  - Spring settings: app name, web type (servlet, not reactive)
  - Ingestion configuration (field mappings, sheet/file names)
  - Insight settings (hotspot degree threshold)
  - Sample auto-load toggle

- **application-ai.yml**
  - Profile-specific Azure OpenAI settings
  - Loaded only when `-Dspring-boot.run.profiles=ai`

- **AiConfig.java**
  - Wires `SummaryGenerator` bean with fallback logic

- **CorsConfig.java**
  - Configures CORS for React frontend
  - Default allows `http://localhost:5173` (Vite dev server)

- **EaIngestionProperties.java** (ConfigurationProperties)
  - Typed mapping of YAML config → Java objects
  - Prefixed with `ea.ingestion`

- **AzureOpenAiProperties.java**
  - Typed mapping of Azure settings
  - Prefixed with `ea.ai.azure`

- **InsightProperties.java**
  - Typed mapping of insight config
  - Prefixed with `ea.insight`

---

### Dependencies (pom.xml)

| Dependency | Purpose |
|-----------|---------|
| `spring-boot-starter-web` | REST API, MVC |
| `spring-boot-starter-validation` | Jakarta Bean Validation |
| `spring-boot-starter-webflux` | WebClient for async HTTP (Azure OpenAI) |
| `jgrapht-core` | Dependency graph algorithms |
| `poi-ooxml` | Excel `.xlsx` parsing |
| `pdfbox` | PDF generation |
| `commons-csv` | CSV parsing |
| `commons-io` | IO utilities |
| `jackson-databind` | JSON serialization |
| `lombok` | Annotations → boilerplate reduction |
| `spring-boot-starter-test` | JUnit, Mockito, etc. |

---

## 🎨 Frontend Architecture (React + Vite)

### Technology Stack
- **React 19.2**: Component-based UI
- **Vite 8.2**: Lightning-fast build tool + dev server
- **Cytoscape.js 3.34**: Interactive graph visualization
- **Axios 1.20**: HTTP client (REST API calls)
- **ESLint**: Code quality

### Component Hierarchy

```
App (Root)
├── Header
│   ├── Title
│   └── ExportButton
├── Body
│   ├── Aside: ControlPanel
│   │   ├── UploadButton
│   │   └── FilterPanel
│   ├── Main: GraphCanvas
│   │   ├── FrameTabs (application/process/domain/infoflow)
│   │   └── GraphCanvas (Cytoscape)
│   └── Aside: InsightsPanel
│       ├── Summary (TextContent)
│       ├── Findings (List)
│       └── NodeDetail (Selection Info)
└── Toast (Notifications)
```

### Key Components

1. **App.jsx** (Root Component)
   - State management for frame, filters, selected node, refresh key
   - Custom hooks: `useGraphData`, `useInsights`, `useSummary`
   - Manages data flow: upload → refresh → UI update
   - Coordinates panels and canvas

2. **GraphCanvas.jsx**
   - Renders Cytoscape instance
   - Manages node selection, styling, layout (dagre)
   - Issue rings (gap, EOL, SPOF) via CSS classes
   - Fetches impact analysis on node click
   - Responsive to filter changes

3. **FrameTabs.jsx**
   - Switches between 4 observation frames:
     - `application`: Apps → interfaces
     - `process`: Processes → app assignments
     - `domain`: Domains → aggregated apps
     - `infoflow`: Data objects → flows

4. **FilterPanel.jsx**
   - Domain dropdown filter (application frame only)
   - Lifecycle status toggle (Active/Deprecated/EOL)
   - Disabled on non-application frames
   - Updates nodeClasses for visual filtering

5. **InsightsPanel.jsx**
   - Displays summary text
   - Lists findings grouped by type
   - Severity-based color coding

6. **NodeDetail.jsx**
   - Shows selected node properties
   - Displays issue rings (if any)
   - Clears when deselected

7. **UploadButton.jsx**
   - File input (`accept=".json,.csv,.xlsx"`)
   - Posts to `POST /api/upload`
   - Calls parent `onUploaded(report)` with validation result

8. **ExportButton.jsx**
   - Dialog to select format (PNG/PDF/PPTX)
   - Calls `exportDiagram(type)` API
   - Downloads file with proper MIME type

9. **Toast.jsx**
   - Temporary notification (success/warning/error)
   - Auto-dismisses after delay
   - Shows validation issue summaries

### Custom Hooks

**useGraphData.js**
```javascript
useGraphData(frame, refreshKey) → { elements, loading, error }
```
- Fetches `/api/graph/{frame}` when frame or refreshKey changes
- Converts backend GraphDto → Cytoscape elements
- Cancels in-flight requests if frame changes
- Returns state for loading spinner, error display

**useInsights.js**
```javascript
useInsights(refreshKey) → { findings, loading, error }
```
- Fetches `/api/insights`
- Caches findings for InsightsPanel rendering
- Resets on refreshKey change (after upload)

**useSummary.js**
```javascript
useSummary(refreshKey) → { summary, loading, error }
```
- Fetches `/api/summary`
- Caches summary text
- Resets on upload

### Services

**api.js**
- Axios instance pointed at `http://localhost:8080/api`
- Functions:
  - `uploadDataset(file)` → `ValidationReport`
  - `getGraph(frame)` → `GraphDto`
  - `getNodeImpact(id)` → `ImpactAnalysisResult`
  - `getInsights()` → `List<Finding>`
  - `getSummary()` → `{ summary: string }`
  - `exportDiagram(type)` → `Blob`

**graphAdapter.js**
- Converts backend `GraphDto` → Cytoscape elements
- Assigns colors:
  - By domain (predefined colors: Sales blue, Finance teal, etc.)
  - Fallback: hash-based stable color for unknown domains
  - Special: dark teal for processes, gray for info objects
- Adds node/edge data for styling

**insightAdapter.js**
- Maps findings → CSS classes for Cytoscape
- Classes: `.gap`, `.eol`, `.spof` (single point of failure)
- Highlights nodes with multiple issue types
- Used by GraphCanvas for styling

### Styling

- **App.css**: Layout (3-column flex: sidebar, canvas, sidebar)
- **GraphCanvas.css**: Cytoscape styling (node colors, edge arrows, issue rings)
- **Component.css**: Individual component styles
- **index.css**: Base styles, fonts, resets

### Data Flow

```
┌─────────────────────────────────────────────────────┐
│         User Interaction (Upload / Filter)          │
└────────────────┬────────────────────────────────────┘
                 │
                 ▼
        ┌─────────────────┐
        │  App.jsx State  │  (frame, filters, refreshKey)
        └─────────────────┘
                 │
       ┌─────────┼─────────┬─────────┐
       │         │         │         │
       ▼         ▼         ▼         ▼
   useGraphData useInsights useSummary (custom hooks)
       │         │         │         │
       ▼         ▼         ▼         ▼
     API calls (Axios)
       │         │         │         │
       ▼         ▼         ▼         ▼
   Elements   Findings  Summary   (state)
       │         │         │         │
       ▼         ▼         ▼         ▼
   GraphCanvas InsightsPanel  (components render)
```

---

## 🔄 Data Flow & Processing Pipeline

### Upload & Processing Workflow

```
1. User uploads file (UI)
   ↓
2. UploadButton.jsx → api.uploadDataset(file)
   ↓
3. POST /api/upload (multipart file)
   ↓
4. EaController.upload() → EaContextService.upload()
   ↓
5. Choose parser (EaDataParser) by file extension
   ├─ .json → JsonEaDataParser
   ├─ .xlsx → ExcelEaDataParser
   └─ .zip → CsvEaDataParser
   ↓
6. Parser → parse(InputStream) → CanonicalModel
   ├─ Map source columns → canonical fields (via application.yml)
   ├─ Create immutable records
   └─ Return CanonicalModel (empty lists if no data)
   ↓
7. EaContextService.store.load(model)
   ├─ GraphBuilderService.build(model) → Graph<Application, InterfaceEdge>
   ├─ InsightService.analyze(model, graph) → List<Finding>
   ├─ Compute GraphStats
   └─ Cache all in Session (immutable)
   ↓
8. ValidationService.validate(model)
   ├─ Check required fields
   ├─ Check unique IDs
   ├─ Check referential integrity
   ├─ Collect issues in ValidationReport
   └─ Return report (never throws)
   ↓
9. Return 200 + ValidationReport
   ↓
10. Frontend displays validation result (toast)
   ↓
11. User sees errors/warnings; calls refreshKey++
   ↓
12. useGraphData, useInsights, useSummary re-fetch
   ↓
13. UI updates with graph, findings, summary
```

### GET Request Processing (Reuse Pattern)

```
GET /api/graph/application
   ↓
EaController.graph(frame) → EaContextService.graph(frame)
   ↓
Switch on frame:
   ├─ APPLICATION → projectionService.applicationView(store.getGraph())
   ├─ PROCESS → projectionService.businessProcessView(store.getModel())
   ├─ DOMAIN → projectionService.domainView(store.getModel(), graph)
   └─ INFOFLOW → projectionService.informationFlowView(store.getModel())
   ↓
Return GraphDto (nodes + edges)
   ↓
Frontend: graphAdapter.toCytoscapeElements(graphDto)
   ↓
Cytoscape renders (no re-parsing/re-analyzing)
```

**Key Insight**: Graph is built once at upload; subsequent GET requests reuse cached graph.

---

## 🎯 Key Design Patterns & Principles

### 1. **Strategy Pattern** (Ingestion)
- Multiple parser implementations (JSON/Excel/CSV)
- Single `EaDataParser` interface
- Caller doesn't know which parser; chosen by filename

### 2. **Builder Pattern** (CanonicalModel, GraphStats)
- Fluent construction of immutable objects
- `CanonicalModel.builder().applications(...).domains(...).build()`

### 3. **Adapter Pattern** (Frontend)
- `graphAdapter.js`: Backend GraphDto → Cytoscape elements
- `insightAdapter.js`: Findings → CSS classes

### 4. **Observer Pattern** (React Hooks)
- `useGraphData`, `useInsights`, `useSummary` subscribe to API changes
- Trigger re-renders on data arrival

### 5. **Template Method** (Ingestion Base)
- `IngestionSupport` defines common mapping logic
- Parsers implement format-specific reading
- Template handles field resolution

### 6. **Facade Pattern** (EaContextService)
- Single entry point for complex multi-step operations
- Hides orchestration (parse → validate → cache)

### 7. **Immutability & Records**
- All domain objects are records (immutable)
- Thread-safety without locks (for read-heavy workloads)
- Guarantees referential transparency

### 8. **Configuration-Driven Behavior**
- Column mapping is YAML, not hardcoded
- Insight thresholds are properties
- Sheet/file names are parameterized
- Add new data sources without code changes

### 9. **Graceful Degradation**
- Validation collects issues; never throws
- Broken data loads partially
- Insights detect what's wrong
- Summary includes issue count

### 10. **Plugin Architecture** (AI)
- `SummaryGenerator` interface with multiple implementations
- Swap between template/Azure without code changes
- Spring `@ConditionalOnMissingBean` handles fallback

---

## 📊 Configuration Reference

### Key Properties (application.yml)

| Property | Default | Purpose |
|----------|---------|---------|
| `ea.ingestion.fields.*.*` | see yml | Column name mapping per entity |
| `ea.ingestion.json.roots.*` | `domains`, `businessProcesses`, etc. | Top-level JSON array names |
| `ea.ingestion.excel.sheets.*` | `Domains`, `BusinessProcesses`, etc. | Excel worksheet names |
| `ea.ingestion.csv.files.*` | `domains.csv`, etc. | CSV file names in ZIP |
| `ea.insight.hotspot-degree-threshold` | 5 | Degree threshold for dependency hotspots |
| `ea.sample.autoload` | true | Auto-load sample on startup |
| `ea.cors.allowed-origins` | `http://localhost:5173` | CORS allowed origins |

### Profiles

- **Default** (no profile)
  - Uses `TemplateSummaryGenerator`
  - No external AI calls

- **`ai`** (enable with `-Dspring-boot.run.profiles=ai`)
  - Uses `AzureOpenAiSummaryGenerator`
  - Requires environment variables:
    - `AZURE_OPENAI_ENDPOINT`
    - `AZURE_OPENAI_API_KEY`
    - `AZURE_OPENAI_DEPLOYMENT`
  - Fallback to template on error

---

## 🚀 Deployment & Running

### Prerequisites
- Java 21+
- Maven (or bundled `mvnw`)
- Node.js 18+ (frontend)

### Run Backend
```bash
cd backend
./mvnw spring-boot:run
# or with AI profile
./mvnw spring-boot:run -Dspring-boot.run.profiles=ai
```
- Starts on `http://localhost:8080`
- Auto-loads sample dataset
- Swagger/OpenAPI docs (if springdoc-openapi added)

### Run Frontend
```bash
cd frontend
npm install
npm run dev
# Starts on http://localhost:5173
```

### Run Tests
```bash
cd backend
./mvnw test
```

### Build for Production
```bash
# Backend
cd backend
./mvnw clean package
# Frontend
cd frontend
npm run build
# Output: dist/ (serve via backend static resources)
```

---

## 📈 Scalability & Limitations

### Scalability Considerations
- **In-Memory Only**: No database; model size limited by JVM heap
- **Single Session**: Only one dataset in memory per instance
- **Suitable for**:
  - Departmental EA (100-1000 applications)
  - Prototype/demo environments
  - Learning/educational use

- **Not suitable for**:
  - Enterprise-wide EA (10,000+ apps)
  - Multi-user concurrent uploads
  - Historical data retention

### Enhancement Paths
1. **Add Database**: Replace `SessionModelStore` with persistent storage
2. **Multi-Tenancy**: Per-tenant sessions (e.g., by header/JWT)
3. **Export Improvements**: Full visual diagram render (headless browser)
4. **Advanced Insights**: ML-based pattern detection
5. **Version Control**: Track dataset changes over time
6. **API Documentation**: OpenAPI/Swagger endpoint

---

## 🔐 Security Considerations

### Current State
- No authentication/authorization
- CORS allows only localhost:5173
- File upload size limits (check Spring defaults)
- No rate limiting

### Recommendations for Production
1. Add Spring Security with OAuth2/JWT
2. Validate file uploads (size, type, content)
3. Sanitize error messages (no internal paths exposed)
4. Add rate limiting (Spring Cloud Gateway)
5. Use HTTPS/TLS
6. Implement audit logging
7. Add role-based access (viewer/editor/admin)

---

## 📝 Sample Data

Included sample file: `backend/src/main/resources/sample_ea_dataset.json`

Structure:
```json
{
  "domains": [
    { "id": "DOM-SALES", "name": "Sales" },
    ...
  ],
  "businessProcesses": [
    { "id": "PROC-ORDER", "name": "Order Processing", "domain": "DOM-SALES" },
    ...
  ],
  "applications": [
    {
      "id": "APP-ERP",
      "name": "ERP System",
      "owner": "John Doe",
      "domain": "DOM-SALES",
      "lifecycleStatus": "ACTIVE",
      "techStack": "SAP",
      "process": "PROC-ORDER"
    },
    ...
  ],
  "interfaces": [
    {
      "id": "INT-001",
      "name": "Order Sync",
      "provider": "APP-ERP",
      "consumer": "APP-DW",
      "type": "API",
      "dataObject": "Order"
    },
    ...
  ],
  "informationObjects": [
    { "id": "IO-ORDER", "name": "Order" },
    ...
  ]
}
```

Auto-loads on startup; enables immediate API testing.

---

## 🎓 Conceptual Layers Summary

```
┌────────────────────────────────────────────────────────┐
│ Presentation (React)                                   │
│ - Components: Canvas, Panels, Forms                    │
│ - State: frame, filters, refreshKey                    │
│ - Hooks: useGraphData, useInsights, useSummary         │
└────────────────────────────────────────────────────────┘
              ↑                          ↓
         ┌────────────────────────────────────┐
         │ API Layer (REST)                   │
         │ - EaController                     │
         │ - JSON/HTTP boundary               │
         └────────────────────────────────────┘
              ↑                          ↓
┌────────────────────────────────────────────────────────┐
│ Application Service (EaContextService)                 │
│ - Orchestration, file routing, caching                 │
└────────────────────────────────────────────────────────┘
              ↑                          ↓
┌────────────────────────────────────────────────────────┐
│ Business Logic (6 Concerns)                            │
├─────────────────────────────────────────────────────────
│ 1. Ingestion (Parsers) - JSON/Excel/CSV → CanonicalModel
│ 2. Validation - Data quality checks
│ 3. Graph - Applications + dependency analysis
│ 4. Insight - Issue detection
│ 5. AI - Summary generation (template or Azure)
│ 6. Export - PNG/PDF/PPTX rendering
└────────────────────────────────────────────────────────┘
              ↑                          ↓
┌────────────────────────────────────────────────────────┐
│ Data Store (In-Memory Session)                         │
│ - CanonicalModel (immutable)                           │
│ - Graph<Application, InterfaceEdge>                    │
│ - List<Finding>                                        │
│ - GraphStats                                           │
└────────────────────────────────────────────────────────┘
```

---

## 🏁 Summary

**Context Cartography** is a well-architected, modular EA visualization & analysis platform that:

✅ **Accepts** multiple data formats via pluggable parsers  
✅ **Validates** data quality without throwing errors  
✅ **Analyzes** dependency graphs and detects issues  
✅ **Visualizes** via interactive Cytoscape UI with multiple frames  
✅ **Summarizes** landscapes naturally (template or AI-powered)  
✅ **Exports** reports in multiple formats  
✅ **Stores** data in-memory per session (no database)  
✅ **Configures** via externalized YAML (no hardcoding)  

**Perfect for**: EA teams, architects, consultants, and learning environments exploring how to build domain-specific visualization tools.

