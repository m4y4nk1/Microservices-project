package com.vw.eacontext.ingestion;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.InputStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Interface;
import com.vw.eacontext.model.InterfaceType;
import com.vw.eacontext.model.LifecycleStatus;

@SpringBootTest
class JsonEaDataParserTest {

    @Autowired
    private JsonEaDataParser parser;

    @Test
    void parsesSampleDatasetUsingExternalizedMapping() throws Exception {
        CanonicalModel model;
        try (InputStream in = new ClassPathResource("sample_ea_dataset.json").getInputStream()) {
            model = parser.parse(in);
        }

        // Counts match the sample dataset metadata.
        assertThat(model.domains()).hasSize(6);
        assertThat(model.businessProcesses()).hasSize(6);
        assertThat(model.applications()).hasSize(18);
        assertThat(model.interfaces()).hasSize(22);
        assertThat(model.informationObjects()).hasSize(17);

        // Field-name remapping: JSON "process" -> model processId, enum mapping.
        Application crm = model.applications().stream()
                .filter(a -> "APP-CRM".equals(a.id())).findFirst().orElseThrow();
        assertThat(crm.name()).isEqualTo("Customer CRM");
        assertThat(crm.processId()).isEqualTo("BP-O2C");
        assertThat(crm.lifecycleStatus()).isEqualTo(LifecycleStatus.ACTIVE);

        // Mixed-case enum "EOL" and blank fields become null.
        Application scada = model.applications().stream()
                .filter(a -> "APP-SCADA".equals(a.id())).findFirst().orElseThrow();
        assertThat(scada.lifecycleStatus()).isEqualTo(LifecycleStatus.EOL);

        // JSON "provider"/"consumer" -> providerId/consumerId, "Event" -> EVENT.
        Interface invoice = model.interfaces().stream()
                .filter(i -> "IF-003".equals(i.id())).findFirst().orElseThrow();
        assertThat(invoice.providerId()).isEqualTo("APP-BILL");
        assertThat(invoice.consumerId()).isEqualTo("APP-ERP");
        assertThat(invoice.type()).isEqualTo(InterfaceType.EVENT);

        // Blank consumer maps to null rather than empty string.
        Interface legacyExport = model.interfaces().stream()
                .filter(i -> "IF-021".equals(i.id())).findFirst().orElseThrow();
        assertThat(legacyExport.consumerId()).isNull();
    }
}

