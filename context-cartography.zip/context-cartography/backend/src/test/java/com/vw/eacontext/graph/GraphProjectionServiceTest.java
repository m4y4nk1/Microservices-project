package com.vw.eacontext.graph;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.InputStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import com.vw.eacontext.dto.GraphDto;
import com.vw.eacontext.dto.GraphEdge;
import com.vw.eacontext.dto.GraphNode;
import com.vw.eacontext.ingestion.JsonEaDataParser;
import com.vw.eacontext.model.CanonicalModel;

@SpringBootTest
class GraphProjectionServiceTest {

    @Autowired
    private JsonEaDataParser parser;

    @Autowired
    private GraphProjectionService projectionService;

    private CanonicalModel model;

    @BeforeEach
    void loadSample() throws Exception {
        try (InputStream in = new ClassPathResource("sample_ea_dataset.json").getInputStream()) {
            model = parser.parse(in);
        }
    }

    @Test
    void applicationViewProjectsAppsAndInterfaces() {
        GraphDto dto = projectionService.applicationView(model);

        assertThat(dto.frame()).isEqualTo("application");
        assertThat(dto.nodes()).hasSize(18);
        assertThat(dto.nodes()).allMatch(n -> "application".equals(n.type()));
        // 22 interfaces minus IF-021 (blank consumer) = 21 edges.
        assertThat(dto.edges()).hasSize(21);

        GraphEdge order = edge(dto, "IF-001");
        assertThat(order.source()).isEqualTo("APP-CRM");
        assertThat(order.target()).isEqualTo("APP-BILL");
        assertThat(order.type()).isEqualTo("API");
    }

    @Test
    void businessProcessViewLinksProcessesToMemberApps() {
        GraphDto dto = projectionService.businessProcessView(model);

        assertThat(dto.frame()).isEqualTo("process");
        // 6 processes + 16 mapped apps (APP-ANALYT and APP-LEGACYRP have no process) = 22 nodes.
        assertThat(dto.nodes().stream().filter(n -> "process".equals(n.type()))).hasSize(6);
        assertThat(dto.nodes().stream().filter(n -> "application".equals(n.type()))).hasSize(16);
        // One membership edge per mapped app.
        assertThat(dto.edges()).hasSize(16);
        assertThat(dto.edges()).allMatch(e -> "membership".equals(e.type()));
        assertThat(dto.edges()).anyMatch(e -> "BP-O2C".equals(e.source()) && "APP-CRM".equals(e.target()));
    }

    @Test
    void domainViewAggregatesAppsAndCollapsesEdges() {
        GraphDto dto = projectionService.domainView(model);

        assertThat(dto.frame()).isEqualTo("domain");
        // 6 domains, each represented once.
        assertThat(dto.nodes()).hasSize(6);
        assertThat(dto.nodes()).allMatch(n -> "domain".equals(n.type()));
        assertThat(node(dto, "DOM-SALES").data().get("applicationCount")).isEqualTo(2);

        // IF-001 (CRM/SALES -> BILL/FIN) collapses to a DOM-SALES -> DOM-FIN edge.
        assertThat(dto.edges())
                .anyMatch(e -> "DOM-SALES".equals(e.source()) && "DOM-FIN".equals(e.target()));
        // Collapsed edges carry an interface count.
        assertThat(dto.edges()).allMatch(e -> e.data().containsKey("interfaceCount"));
    }

    @Test
    void informationFlowViewInsertsInformationObjects() {
        GraphDto dto = projectionService.informationFlowView(model);

        assertThat(dto.frame()).isEqualTo("informationObject");
        // 21 valid interfaces each produce 2 edges (produces + consumes) = 42.
        assertThat(dto.edges()).hasSize(42);
        assertThat(dto.edges()).allMatch(e -> "produces".equals(e.type()) || "consumes".equals(e.type()));

        // 16 distinct information objects flow across the valid interfaces.
        assertThat(dto.nodes().stream().filter(n -> "informationObject".equals(n.type()))).hasSize(16);
        assertThat(dto.nodes()).anyMatch(n -> "informationObject".equals(n.type()) && "Order".equals(n.label()));

        // Provider -> IO -> consumer for the Order flow (IF-001).
        assertThat(dto.edges())
                .anyMatch(e -> "APP-CRM".equals(e.source()) && "produces".equals(e.type()));
    }

    private static GraphNode node(GraphDto dto, String id) {
        return dto.nodes().stream().filter(n -> id.equals(n.id())).findFirst().orElseThrow();
    }

    private static GraphEdge edge(GraphDto dto, String id) {
        return dto.edges().stream().filter(e -> id.equals(e.id())).findFirst().orElseThrow();
    }
}

