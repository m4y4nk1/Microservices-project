package com.vw.eacontext.security;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.vw.eacontext.security.model.AppUser;
import com.vw.eacontext.security.model.PermissionCode;
import com.vw.eacontext.security.model.Role;
import com.vw.eacontext.security.model.RoleName;
import com.vw.eacontext.security.repository.PermissionRepository;
import com.vw.eacontext.security.repository.RoleRepository;
import com.vw.eacontext.security.repository.UserRepository;

/**
 * Verifies the {@code DataInitializer} seeds the exact role/permission matrix
 * from the enterprise blueprint, plus the bootstrap administrator.
 */
@SpringBootTest
class DataInitializerTest {

    @Autowired
    private PermissionRepository permissions;

    @Autowired
    private RoleRepository roles;

    @Autowired
    private UserRepository users;

    @Test
    void everyPermissionCodeIsSeeded() {
        assertThat(permissions.count()).isEqualTo(PermissionCode.values().length);
        for (PermissionCode code : PermissionCode.values()) {
            assertThat(permissions.findByCode(code.name()))
                    .as("permission %s", code)
                    .isPresent();
        }
    }

    @Test
    void everyRoleIsSeededWithItsDefaultMatrix() {
        for (RoleName roleName : RoleName.values()) {
            Role role = roles.findByName(roleName.name()).orElseThrow();
            Set<String> expected = roleName.defaultPermissions().stream()
                    .map(PermissionCode::name)
                    .collect(java.util.stream.Collectors.toSet());

            assertThat(role.permissionCodes())
                    .as("permissions of %s", roleName)
                    .containsExactlyInAnyOrderElementsOf(expected);
            assertThat(role.isSystemRole()).isTrue();
        }
    }

    @Test
    void superAdminHoldsEveryPermission() {
        Role superAdmin = roles.findByName(RoleName.SUPER_ADMIN.name()).orElseThrow();
        assertThat(superAdmin.permissionCodes()).hasSize(PermissionCode.values().length);
    }

    @Test
    void viewerHasNoAiOrExportRights() {
        Role viewer = roles.findByName(RoleName.VIEWER.name()).orElseThrow();

        assertThat(viewer.grants(PermissionCode.DIAGRAM_VIEW)).isTrue();
        assertThat(viewer.grants(PermissionCode.AI_SUMMARY)).isFalse();
        assertThat(viewer.grants(PermissionCode.AI_QUERY)).isFalse();
        assertThat(viewer.grants(PermissionCode.EXPORT_PDF)).isFalse();
        assertThat(viewer.grants(PermissionCode.DATA_UPLOAD)).isFalse();
    }

    @Test
    void guestSeesOnlyTheApplicationFrame() {
        Role guest = roles.findByName(RoleName.GUEST.name()).orElseThrow();

        assertThat(guest.grants(PermissionCode.DIAGRAM_VIEW_APPLICATION)).isTrue();
        assertThat(guest.grants(PermissionCode.DIAGRAM_VIEW_PROCESS)).isFalse();
        assertThat(guest.grants(PermissionCode.DIAGRAM_VIEW_DOMAIN)).isFalse();
        assertThat(guest.grants(PermissionCode.DIAGRAM_VIEW_INFOFLOW)).isFalse();
    }

    @Test
    void onlySuperAdminMayConfigureAi() {
        assertThat(roles.findByName(RoleName.SUPER_ADMIN.name()).orElseThrow()
                .grants(PermissionCode.AI_CONFIG)).isTrue();
        assertThat(roles.findByName(RoleName.ADMIN.name()).orElseThrow()
                .grants(PermissionCode.AI_CONFIG)).isFalse();
        assertThat(roles.findByName(RoleName.ARCHITECT.name()).orElseThrow()
                .grants(PermissionCode.AI_CONFIG)).isFalse();
    }

    @Test
    void bootstrapSuperAdminIsCreatedAndMustChangePassword() {
        AppUser admin = users.findByEmailIgnoreCase("admin@contexa.local").orElseThrow();

        assertThat(admin.roleName()).isEqualTo(RoleName.SUPER_ADMIN.name());
        assertThat(admin.isActive()).isTrue();
        assertThat(admin.isMustChangePassword()).isTrue();
        assertThat(admin.getPasswordHash()).startsWith("$2");   // BCrypt, never plaintext
    }
}

