package com.vw.eacontext.security;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vw.eacontext.admin.dto.AiSettingsRequest;
import com.vw.eacontext.security.dto.LoginRequest;

/**
 * End-to-end authorization tests with the JWT filter chain and method security
 * switched <em>on</em> (the rest of the suite runs unsecured for legacy
 * reasons).
 *
 * <p>Authorities are injected with {@code @WithMockUser} so each case isolates
 * one permission rule.</p>
 */
@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(properties = {
        "contexa.security.enabled=true",
        "ea.sample.autoload=true"
})
class RbacEndpointSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    // --- Authentication ---------------------------------------------------

    @Test
    void unauthenticatedRequestsAreRejected() throws Exception {
        mockMvc.perform(get("/api/graph/application"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.status").value(401));
    }

    @Test
    void loginWithSeededAdminReturnsTokenAndPermissions() throws Exception {
        String body = objectMapper.writeValueAsString(
                new LoginRequest("admin@contexa.local", "ChangeMe#123"));

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").isNotEmpty())
                .andExpect(jsonPath("$.tokenType").value("Bearer"))
                .andExpect(jsonPath("$.role").value("SUPER_ADMIN"))
                .andExpect(jsonPath("$.mustChangePassword").value(true))
                .andExpect(jsonPath("$.permissions").isArray());
    }

    @Test
    void loginWithWrongPasswordReturns401() throws Exception {
        String body = objectMapper.writeValueAsString(
                new LoginRequest("admin@contexa.local", "definitely-wrong"));

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Invalid email or password."));
    }

    // --- Diagram permissions ---------------------------------------------

    @Test
    @WithMockUser(authorities = {"DIAGRAM_VIEW", "DIAGRAM_VIEW_APPLICATION"})
    void guestLikeUserCanReadTheApplicationFrame() throws Exception {
        mockMvc.perform(get("/api/graph/application"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.frame").value("application"));
    }

    @Test
    @WithMockUser(authorities = {"DIAGRAM_VIEW", "DIAGRAM_VIEW_APPLICATION"})
    void guestLikeUserCannotReadOtherFrames() throws Exception {
        mockMvc.perform(get("/api/graph/domain"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.status").value(403));
    }

    @Test
    @WithMockUser(authorities = "ANALYSIS_RISK")
    void diagramAccessRequiresDiagramViewPermission() throws Exception {
        mockMvc.perform(get("/api/graph/application"))
                .andExpect(status().isForbidden());
    }

    // --- AI permissions ---------------------------------------------------

    @Test
    @WithMockUser(authorities = {"DIAGRAM_VIEW", "DIAGRAM_VIEW_APPLICATION"})
    void viewerCannotInvokeTheAiSummary() throws Exception {
        mockMvc.perform(get("/api/summary"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.status").value(403));
    }

    @Test
    @WithMockUser(username = "analyst@contexa.local", authorities = "AI_SUMMARY")
    void aiSummaryPermissionGrantsAccess() throws Exception {
        mockMvc.perform(get("/api/summary"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.summary").isNotEmpty());
    }

    // --- Data and export permissions --------------------------------------

    @Test
    @WithMockUser(authorities = "DIAGRAM_VIEW")
    void uploadRequiresDataUploadPermission() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file", "dataset.json", MediaType.APPLICATION_JSON_VALUE, "{}".getBytes());

        mockMvc.perform(multipart("/api/upload").file(file))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.status").value(403));
    }

    @Test
    @WithMockUser(authorities = "EXPORT_PNG")
    void exportIsCheckedPerFormat() throws Exception {
        mockMvc.perform(get("/api/export").param("type", "png"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/api/export").param("type", "pdf"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(authorities = "ANALYSIS_RISK")
    void insightsRequireAnalysisRiskPermission() throws Exception {
        mockMvc.perform(get("/api/insights"))
                .andExpect(status().isOk());
    }

    // --- Admin surface ----------------------------------------------------

    @Test
    @WithMockUser(authorities = "DIAGRAM_VIEW")
    void nonAdminCannotReachTheAdminApi() throws Exception {
        mockMvc.perform(get("/api/admin/users"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(authorities = "USER_MANAGE")
    void userManagerCanListUsers() throws Exception {
        mockMvc.perform(get("/api/admin/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].email").isNotEmpty())
                .andExpect(jsonPath("$[0].passwordHash").doesNotExist());
    }

    @Test
    @WithMockUser(authorities = "USER_MANAGE")
    void changingAiSettingsRequiresAiConfig() throws Exception {
        // USER_MANAGE may read current AI policy...
        mockMvc.perform(get("/api/admin/ai-settings"))
                .andExpect(status().isOk());

        // ...but only AI_CONFIG may change it.
        String body = objectMapper.writeValueAsString(new AiSettingsRequest(
                true, "gpt-4o", 1000, true, true, true, true, false));

        mockMvc.perform(put("/api/admin/ai-settings")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(authorities = {"AI_CONFIG", "USER_MANAGE"})
    void aiConfigPermissionAllowsUpdatingAiSettings() throws Exception {
        String body = objectMapper.writeValueAsString(new AiSettingsRequest(
                true, "gpt-4o-mini", 2500, true, true, true, true, false));

        mockMvc.perform(put("/api/admin/ai-settings")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.model").value("gpt-4o-mini"))
                .andExpect(jsonPath("$.dailyTokenBudgetPerUser").value(2500));
    }

    @Test
    @WithMockUser(authorities = "AUDIT_VIEW")
    void auditorCanReadTheAuditTrail() throws Exception {
        mockMvc.perform(get("/api/admin/audit"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }
}




