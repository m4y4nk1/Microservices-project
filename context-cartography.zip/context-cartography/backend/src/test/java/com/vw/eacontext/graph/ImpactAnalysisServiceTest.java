package com.vw.eacontext.graph;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.InputStream;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import com.vw.eacontext.dto.GraphEdge;
import com.vw.eacontext.dto.ImpactAnalysisResult;
import com.vw.eacontext.exception.EaNotFoundException;
import com.vw.eacontext.ingestion.JsonEaDataParser;
import com.vw.eacontext.model.CanonicalModel;

@SpringBootTest
class ImpactAnalysisServiceTest {

    @Autowired
    private JsonEaDataParser parser;

    @Autowired
    private ImpactAnalysisService impactAnalysisService;

    private CanonicalModel model;

    @BeforeEach
    void loadSample() throws Exception {
        try (InputStream in = new ClassPathResource("sample_ea_dataset.json").getInputStream()) {
            model = parser.parse(in);
        }
    }

    @Test
    void computesUpstreamAndDownstreamBlastRadius() {
        ImpactAnalysisResult result = impactAnalysisService.impactAnalysis(model, "APP-BILL");

        // Downstream: BILL -> ERP -> {PAY, DWH -> ANALYT}.
        assertThat(result.downstream())
                .containsExactlyInAnyOrder("APP-ERP", "APP-PAY", "APP-DWH", "APP-ANALYT");

        // Upstream: CRM -> BILL, with CRM fed by ECOM, IAM, ESB, NOTIF.
        assertThat(result.upstream())
                .containsExactlyInAnyOrder("APP-CRM", "APP-ECOM", "APP-IAM", "APP-ESB", "APP-NOTIF");

        // Affected = upstream + downstream + origin (all distinct here).
        assertThat(result.affected()).hasSize(10).contains("APP-BILL");

        // Connecting edges include both an upstream and a downstream interface.
        assertThat(result.edges()).extracting(GraphEdge::id)
                .contains("IF-001", "IF-003", "IF-019");
        assertThat(result.edges()).hasSize(9);
    }

    @Test
    void leafConsumerHasNoDownstream() {
        // APP-PAY is only ever a consumer (no outgoing interfaces).
        ImpactAnalysisResult result = impactAnalysisService.impactAnalysis(model, "APP-PAY");

        assertThat(result.downstream()).isEmpty();
        assertThat(result.upstream()).isNotEmpty();
        assertThat(result.affected()).contains("APP-PAY");
    }

    @Test
    void unknownApplicationThrows() {
        assertThatThrownBy(() -> impactAnalysisService.impactAnalysis(model, "APP-NOPE"))
                .isInstanceOf(EaNotFoundException.class)
                .hasMessageContaining("APP-NOPE");
    }

    @Test
    void edgesReferenceOnlyAffectedNodes() {
        ImpactAnalysisResult result = impactAnalysisService.impactAnalysis(model, "APP-BILL");
        List<GraphEdge> edges = result.edges();
        assertThat(edges).allSatisfy(e -> {
            assertThat(result.affected()).contains(e.source());
            assertThat(result.affected()).contains(e.target());
        });
    }
}

