package com.vw.eacontext.validation;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import com.vw.eacontext.ingestion.JsonEaDataParser;
import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Interface;
import com.vw.eacontext.model.InterfaceType;

@SpringBootTest
class ValidationServiceTest {

    @Autowired
    private JsonEaDataParser parser;

    @Autowired
    private ValidationService validationService;

    private CanonicalModel sample;

    @BeforeEach
    void loadSample() throws Exception {
        try (InputStream in = new ClassPathResource("sample_ea_dataset.json").getInputStream()) {
            sample = parser.parse(in);
        }
    }

    @Test
    void validFileHasNoErrors() {
        ValidationReport report = validationService.validate(sample);

        // The sample has intentional data-quality gaps (missing owners, an empty
        // consumer) but no blocking errors: all IDs unique, required fields present,
        // and every populated provider/consumer references an existing application.
        assertThat(report.isValid()).isTrue();
        assertThat(report.hasErrors()).isFalse();
        assertThat(report.errors()).isEmpty();
    }

    @Test
    void missingOwnerIsReportedAsWarning() {
        ValidationReport report = validationService.validate(sample);

        // APP-BILL in the sample has a blank owner.
        assertThat(report.warnings())
                .anyMatch(issue -> issue.message().contains("APP-BILL")
                        && issue.message().contains("owner"));
        // Missing owner must not be an error.
        assertThat(report.errors())
                .noneMatch(issue -> issue.message().contains("owner"));
    }

    @Test
    void brokenReferenceIsReportedAsError() {
        Interface broken = Interface.builder()
                .id("IF-BROKEN")
                .name("Dangling reference")
                .providerId("APP-DOES-NOT-EXIST")
                .consumerId("APP-CRM")
                .type(InterfaceType.API)
                .dataObject("Ghost")
                .build();

        CanonicalModel model = withExtraInterface(sample, broken);
        ValidationReport report = validationService.validate(model);

        assertThat(report.hasErrors()).isTrue();
        assertThat(report.errors())
                .anyMatch(issue -> issue.message().contains("IF-BROKEN")
                        && issue.message().contains("APP-DOES-NOT-EXIST")
                        && issue.message().contains("provider"));
    }

    @Test
    void duplicateIdIsReportedAsError() {
        Application duplicate = Application.builder()
                .id("APP-CRM") // already exists in the sample
                .name("Duplicate CRM")
                .owner("Someone")
                .build();

        CanonicalModel model = withExtraApplication(sample, duplicate);
        ValidationReport report = validationService.validate(model);

        assertThat(report.hasErrors()).isTrue();
        assertThat(report.errors())
                .anyMatch(issue -> issue.message().contains("Duplicate")
                        && issue.message().contains("APP-CRM"));
    }

    private static CanonicalModel withExtraInterface(CanonicalModel base, Interface extra) {
        List<Interface> interfaces = new ArrayList<>(base.interfaces());
        interfaces.add(extra);
        return CanonicalModel.builder()
                .domains(base.domains())
                .businessProcesses(base.businessProcesses())
                .applications(base.applications())
                .interfaces(interfaces)
                .informationObjects(base.informationObjects())
                .build();
    }

    private static CanonicalModel withExtraApplication(CanonicalModel base, Application extra) {
        List<Application> applications = new ArrayList<>(base.applications());
        applications.add(extra);
        return CanonicalModel.builder()
                .domains(base.domains())
                .businessProcesses(base.businessProcesses())
                .applications(applications)
                .interfaces(base.interfaces())
                .informationObjects(base.informationObjects())
                .build();
    }
}

