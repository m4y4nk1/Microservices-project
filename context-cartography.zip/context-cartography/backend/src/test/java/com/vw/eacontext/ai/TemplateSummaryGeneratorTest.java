package com.vw.eacontext.ai;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.FindingType;
import com.vw.eacontext.validation.Severity;

class TemplateSummaryGeneratorTest {

    private final SummaryGenerator generator = new TemplateSummaryGenerator();

    private static final GraphStats STATS = GraphStats.builder()
            .applicationCount(18)
            .interfaceCount(21)
            .domainCount(6)
            .businessProcessCount(6)
            .informationObjectCount(17)
            .mostConnectedApplicationId("APP-ERP")
            .maxDegree(7)
            .build();

    private static final List<Finding> FINDINGS = List.of(
            new Finding(FindingType.OWNERSHIP_GAP, Severity.WARNING, "APP-BILL", "x"),
            new Finding(FindingType.OWNERSHIP_GAP, Severity.WARNING, "APP-PAYROLL", "x"),
            new Finding(FindingType.LIFECYCLE_RISK, Severity.ERROR, "APP-SCADA", "x"),
            new Finding(FindingType.ORPHAN_INTERFACE, Severity.WARNING, "IF-021", "x"),
            new Finding(FindingType.DEPENDENCY_HOTSPOT, Severity.WARNING, "APP-ERP", "x"));

    @Test
    void producesDeterministicOutput() {
        String first = generator.summarize(FINDINGS, STATS);
        String second = generator.summarize(FINDINGS, STATS);
        assertThat(first).isEqualTo(second);
    }

    @Test
    void includesOverviewTotalsAndSections() {
        String summary = generator.summarize(FINDINGS, STATS);

        assertThat(summary)
                .contains("Analyzed 18 application(s) across 6 domain(s)")
                .contains("connected by 21 interface(s)")
                .contains("Detected 5 issue(s): 1 error(s) and 4 warning(s).")
                .contains("Ownership gaps: 2 application(s) without an owner (APP-BILL, APP-PAYROLL).")
                .contains("Lifecycle risks: 1 EOL/Deprecated application(s) (APP-SCADA).")
                .contains("Orphan interfaces: 1 interface(s) with no consumer (IF-021).")
                .contains("Dependency hotspots: 1 potential single point(s) of failure (APP-ERP).")
                .contains("Most connected application: APP-ERP (degree 7).");
    }

    @Test
    void ownershipIdsAreSortedForDeterminism() {
        List<Finding> unordered = List.of(
                new Finding(FindingType.OWNERSHIP_GAP, Severity.WARNING, "APP-PAYROLL", "x"),
                new Finding(FindingType.OWNERSHIP_GAP, Severity.WARNING, "APP-BILL", "x"));
        String summary = generator.summarize(unordered, STATS);
        assertThat(summary).contains("(APP-BILL, APP-PAYROLL)");
    }

    @Test
    void handlesNoFindings() {
        String summary = generator.summarize(List.of(), STATS);
        assertThat(summary).contains("No issues were detected.");
    }
}

