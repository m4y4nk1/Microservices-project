package com.vw.eacontext.ai;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.vw.eacontext.config.AzureOpenAiProperties;
import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.FindingType;
import com.vw.eacontext.validation.Severity;

class AzureOpenAiSummaryGeneratorTest {

    private static final GraphStats STATS = GraphStats.builder()
            .applicationCount(18).interfaceCount(21).domainCount(6)
            .businessProcessCount(6).informationObjectCount(17)
            .mostConnectedApplicationId("APP-ERP").maxDegree(7)
            .build();

    private static final List<Finding> FINDINGS = List.of(
            new Finding(FindingType.OWNERSHIP_GAP, Severity.WARNING, "APP-BILL", "no owner"),
            new Finding(FindingType.DEPENDENCY_HOTSPOT, Severity.WARNING, "APP-ERP", "hotspot"));

    @Test
    void fallsBackToTemplateWhenEndpointUnreachable() {
        AzureOpenAiProperties props = new AzureOpenAiProperties();
        props.setEndpoint("http://localhost:1"); // nothing listening -> connection refused
        props.setApiKey("dummy");
        props.setDeployment("dummy");
        props.setTimeout(Duration.ofSeconds(2));

        AzureOpenAiSummaryGenerator azure = new AzureOpenAiSummaryGenerator(props);

        String result = azure.summarize(FINDINGS, STATS);

        // On failure it must return the deterministic template output, not throw.
        String expectedTemplate = new TemplateSummaryGenerator().summarize(FINDINGS, STATS);
        assertThat(result).isEqualTo(expectedTemplate);
    }
}

