package com.vw.eacontext.insight;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.InputStream;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import com.vw.eacontext.ingestion.JsonEaDataParser;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.validation.Severity;

@SpringBootTest
class InsightServiceTest {

    @Autowired
    private JsonEaDataParser parser;

    @Autowired
    private InsightService insightService;

    private List<Finding> findings;

    @BeforeEach
    void analyzeSample() throws Exception {
        CanonicalModel model;
        try (InputStream in = new ClassPathResource("sample_ea_dataset.json").getInputStream()) {
            model = parser.parse(in);
        }
        findings = insightService.analyze(model);
    }

    @Test
    void ownershipGapsMatchSample() {
        assertThat(entityIds(FindingType.OWNERSHIP_GAP))
                .containsExactlyInAnyOrder("APP-BILL", "APP-PAYROLL", "APP-LEGACYRP");
        assertThat(of(FindingType.OWNERSHIP_GAP))
                .allMatch(f -> f.severity() == Severity.WARNING);
    }

    @Test
    void orphanInterfacesMatchSample() {
        // Only IF-021 has a blank consumer.
        assertThat(entityIds(FindingType.ORPHAN_INTERFACE))
                .containsExactly("IF-021");
    }

    @Test
    void missingProcessMappingsMatchSample() {
        assertThat(entityIds(FindingType.MISSING_PROCESS_MAPPING))
                .containsExactlyInAnyOrder("APP-ANALYT", "APP-LEGACYRP");
    }

    @Test
    void lifecycleRisksMatchSample() {
        assertThat(entityIds(FindingType.LIFECYCLE_RISK))
                .containsExactlyInAnyOrder("APP-PAYROLL", "APP-SCADA", "APP-LEGACYRP");

        // EOL -> ERROR, Deprecated -> WARNING.
        assertThat(finding(FindingType.LIFECYCLE_RISK, "APP-SCADA").severity()).isEqualTo(Severity.ERROR);
        assertThat(finding(FindingType.LIFECYCLE_RISK, "APP-LEGACYRP").severity()).isEqualTo(Severity.ERROR);
        assertThat(finding(FindingType.LIFECYCLE_RISK, "APP-PAYROLL").severity()).isEqualTo(Severity.WARNING);
    }

    @Test
    void dependencyHotspotMatchesSample() {
        // With the default degree threshold of 5, only APP-ERP (degree 7) qualifies.
        assertThat(entityIds(FindingType.DEPENDENCY_HOTSPOT))
                .containsExactly("APP-ERP");
    }

    @Test
    void totalFindingCountMatchesSample() {
        // 3 ownership + 1 orphan + 2 missing-process + 3 lifecycle + 1 hotspot = 10.
        assertThat(findings).hasSize(10);
    }

    private List<Finding> of(FindingType type) {
        return findings.stream().filter(f -> f.type() == type).toList();
    }

    private List<String> entityIds(FindingType type) {
        return of(type).stream().map(Finding::entityId).toList();
    }

    private Finding finding(FindingType type, String entityId) {
        return of(type).stream()
                .filter(f -> entityId.equals(f.entityId()))
                .findFirst()
                .orElseThrow();
    }
}

