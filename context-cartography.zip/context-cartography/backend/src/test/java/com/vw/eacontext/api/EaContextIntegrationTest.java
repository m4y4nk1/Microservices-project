package com.vw.eacontext.api;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.vw.eacontext.dto.GraphDto;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.FindingType;
import com.vw.eacontext.validation.Severity;

/**
 * Full-stack integration test: boots the application (embedded server) and hits
 * the REST endpoints over HTTP against the auto-loaded bundled sample dataset.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class EaContextIntegrationTest {

    @Autowired
    private TestRestTemplate rest;

    @Test
    void applicationGraphHasExpectedNodeAndEdgeCounts() {
        ResponseEntity<GraphDto> response = rest.getForEntity("/api/graph/application", GraphDto.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        GraphDto graph = response.getBody();
        assertThat(graph).isNotNull();
        assertThat(graph.frame()).isEqualTo("application");
        assertThat(graph.nodes()).hasSize(18);
        assertThat(graph.edges()).hasSize(21);
    }

    @Test
    void insightsContainKnownFindings() {
        ResponseEntity<Finding[]> response = rest.getForEntity("/api/insights", Finding[].class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        List<Finding> findings = Arrays.asList(response.getBody());

        // 3 ownership gaps.
        assertThat(idsOf(findings, FindingType.OWNERSHIP_GAP))
                .containsExactlyInAnyOrder("APP-BILL", "APP-PAYROLL", "APP-LEGACYRP");

        // EOL applications are lifecycle risks with ERROR severity.
        List<Finding> lifecycle = findings.stream()
                .filter(f -> f.type() == FindingType.LIFECYCLE_RISK)
                .toList();
        assertThat(lifecycle).extracting(Finding::entityId)
                .contains("APP-SCADA", "APP-LEGACYRP");
        assertThat(lifecycle.stream()
                .filter(f -> f.entityId().equals("APP-SCADA") || f.entityId().equals("APP-LEGACYRP"))
                .allMatch(f -> f.severity() == Severity.ERROR)).isTrue();

        // ERP is the dependency hotspot (single point of failure).
        assertThat(idsOf(findings, FindingType.DEPENDENCY_HOTSPOT))
                .containsExactly("APP-ERP");
    }

    private List<String> idsOf(List<Finding> findings, FindingType type) {
        return findings.stream()
                .filter(f -> f.type() == type)
                .map(Finding::entityId)
                .toList();
    }
}

