package com.vw.eacontext.admin;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.TestPropertySource;

import com.vw.eacontext.admin.dto.AiSettingsRequest;
import com.vw.eacontext.admin.model.AiFeature;
import com.vw.eacontext.admin.model.AuditAction;
import com.vw.eacontext.admin.repository.AiUsageRepository;
import com.vw.eacontext.admin.repository.AuditEntryRepository;
import com.vw.eacontext.admin.service.AiGovernanceService;
import com.vw.eacontext.admin.service.AiSettingsService;
import com.vw.eacontext.exception.AiFeatureDisabledException;
import com.vw.eacontext.exception.TokenQuotaExceededException;

/**
 * Verifies the three AI gates — master switch, per-feature toggle and per-user
 * daily token budget — and that every outcome is audited.
 */
@SpringBootTest
@TestPropertySource(properties = "contexa.security.enabled=true")
class AiGovernanceServiceTest {

    private static final String ACTOR = "quota-test@contexa.local";

    @Autowired
    private AiGovernanceService governance;

    @Autowired
    private AiSettingsService settings;

    @Autowired
    private AiUsageRepository usage;

    @Autowired
    private AuditEntryRepository auditEntries;

    @BeforeEach
    void authenticateAndReset() {
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(ACTOR, null,
                        java.util.List.of(new SimpleGrantedAuthority("AI_SUMMARY"))));
        usage.deleteAll();
        auditEntries.deleteAll();
        // Generous budget by default; individual tests tighten it.
        settings.update(new AiSettingsRequest(
                true, "gpt-4o-mini", 100_000, true, true, true, true, false));
    }

    @Test
    void successfulCallIsExecutedChargedAndAudited() {
        String result = governance.execute(AiFeature.SUMMARY, 700, () -> "summary text");

        assertThat(result).isEqualTo("summary text");
        assertThat(governance.tokensUsedToday(ACTOR)).isEqualTo(700);
        assertThat(auditEntries.findAll())
                .anyMatch(e -> e.getAction() == AuditAction.AI_CALL
                        && ACTOR.equals(e.getActor())
                        && Integer.valueOf(700).equals(e.getTokensUsed()));
    }

    @Test
    void masterSwitchBlocksEveryFeature() {
        settings.update(new AiSettingsRequest(
                false, "gpt-4o-mini", 100_000, true, true, true, true, false));

        assertThatThrownBy(() -> governance.execute(AiFeature.SUMMARY, 700, () -> "x"))
                .isInstanceOf(AiFeatureDisabledException.class)
                .hasMessageContaining("disabled by an administrator");

        assertThat(auditEntries.findAll())
                .anyMatch(e -> e.getAction() == AuditAction.AI_CALL_DENIED);
    }

    @Test
    void individualFeatureToggleBlocksOnlyThatFeature() {
        // Summary off, query on.
        settings.update(new AiSettingsRequest(
                true, "gpt-4o-mini", 100_000, false, true, true, true, false));

        assertThatThrownBy(() -> governance.execute(AiFeature.SUMMARY, 700, () -> "x"))
                .isInstanceOf(AiFeatureDisabledException.class);

        assertThatCode(() -> governance.execute(AiFeature.QUERY, 10, () -> "ok"))
                .doesNotThrowAnyException();
    }

    @Test
    void dailyBudgetIsEnforcedPerUser() {
        settings.update(new AiSettingsRequest(
                true, "gpt-4o-mini", 1_000, true, true, true, true, false));

        governance.execute(AiFeature.SUMMARY, 600, () -> "first");
        assertThat(governance.tokensUsedToday(ACTOR)).isEqualTo(600);

        // 600 + 600 would exceed the 1000-token budget.
        assertThatThrownBy(() -> governance.execute(AiFeature.SUMMARY, 600, () -> "second"))
                .isInstanceOf(TokenQuotaExceededException.class)
                .hasMessageContaining("Daily AI token budget exhausted");

        // The rejected call must not have been charged.
        assertThat(governance.tokensUsedToday(ACTOR)).isEqualTo(600);
        assertThat(auditEntries.findAll())
                .anyMatch(e -> e.getAction() == AuditAction.AI_QUOTA_EXCEEDED);
    }

    @Test
    void zeroBudgetMeansUnlimited() {
        settings.update(new AiSettingsRequest(
                true, "gpt-4o-mini", 0, true, true, true, true, false));

        assertThatCode(() -> {
            governance.execute(AiFeature.SUMMARY, 50_000, () -> "a");
            governance.execute(AiFeature.SUMMARY, 50_000, () -> "b");
        }).doesNotThrowAnyException();
    }

    @Test
    void failedCallIsAuditedAsUnsuccessful() {
        assertThatThrownBy(() -> governance.execute(AiFeature.SUMMARY, 100, () -> {
            throw new IllegalStateException("provider exploded");
        })).isInstanceOf(IllegalStateException.class);

        assertThat(auditEntries.findAll())
                .anyMatch(e -> e.getAction() == AuditAction.AI_CALL_DENIED && !e.isSuccess());
    }
}

