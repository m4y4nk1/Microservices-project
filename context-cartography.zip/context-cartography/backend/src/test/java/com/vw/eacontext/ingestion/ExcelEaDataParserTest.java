package com.vw.eacontext.ingestion;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.InputStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Interface;
import com.vw.eacontext.model.InterfaceType;
import com.vw.eacontext.model.LifecycleStatus;

@SpringBootTest
class ExcelEaDataParserTest {

    @Autowired
    private ExcelEaDataParser parser;

    @Test
    void parsesSampleWorkbookUsingSharedMapping() throws Exception {
        CanonicalModel model;
        try (InputStream in = new ClassPathResource("sample_ea_dataset.xlsx").getInputStream()) {
            model = parser.parse(in);
        }

        // Counts across the per-entity sheets.
        assertThat(model.domains()).hasSize(6);
        assertThat(model.businessProcesses()).hasSize(6);
        assertThat(model.applications()).hasSize(18);
        assertThat(model.interfaces()).hasSize(22);
        assertThat(model.informationObjects()).hasSize(17);

        // Column remapping: Excel "process" -> processId; enum mapping.
        Application crm = model.applications().stream()
                .filter(a -> "APP-CRM".equals(a.id())).findFirst().orElseThrow();
        assertThat(crm.name()).isEqualTo("Customer CRM");
        assertThat(crm.processId()).isEqualTo("BP-O2C");
        assertThat(crm.lifecycleStatus()).isEqualTo(LifecycleStatus.ACTIVE);

        // "provider"/"consumer" -> providerId/consumerId, "Event" -> EVENT.
        Interface invoice = model.interfaces().stream()
                .filter(i -> "IF-003".equals(i.id())).findFirst().orElseThrow();
        assertThat(invoice.providerId()).isEqualTo("APP-BILL");
        assertThat(invoice.consumerId()).isEqualTo("APP-ERP");
        assertThat(invoice.type()).isEqualTo(InterfaceType.EVENT);
    }
}

