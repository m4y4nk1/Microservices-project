package com.vw.eacontext.graph;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.InputStream;

import org.jgrapht.Graph;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;

import com.vw.eacontext.ingestion.JsonEaDataParser;
import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.InterfaceType;

@SpringBootTest
class GraphBuilderServiceTest {

    @Autowired
    private JsonEaDataParser parser;

    @Autowired
    private GraphBuilderService graphBuilderService;

    @Test
    void buildsDirectedGraphFromSample() throws Exception {
        CanonicalModel model;
        try (InputStream in = new ClassPathResource("sample_ea_dataset.json").getInputStream()) {
            model = parser.parse(in);
        }

        Graph<Application, InterfaceEdge> graph = graphBuilderService.build(model);

        // 18 applications -> 18 vertices.
        assertThat(graph.vertexSet()).hasSize(18);
        // 22 interfaces, but IF-021 has a blank consumer so its edge is skipped -> 21.
        assertThat(graph.edgeSet()).hasSize(21);

        Application crm = vertex(graph, "APP-CRM");
        Application bill = vertex(graph, "APP-BILL");

        // Edge direction is provider -> consumer (IF-001: CRM -> Billing).
        InterfaceEdge orderEdge = graph.getEdge(crm, bill);
        assertThat(orderEdge).isNotNull();
        assertThat(orderEdge.getInterfaceId()).isEqualTo("IF-001");
        assertThat(orderEdge.getType()).isEqualTo(InterfaceType.API);
        assertThat(graph.getEdgeSource(orderEdge)).isEqualTo(crm);
        assertThat(graph.getEdgeTarget(orderEdge)).isEqualTo(bill);

        // No reverse edge Billing -> CRM.
        assertThat(graph.getEdge(bill, crm)).isNull();
    }

    private static Application vertex(Graph<Application, InterfaceEdge> graph, String id) {
        return graph.vertexSet().stream()
                .filter(a -> id.equals(a.id()))
                .findFirst()
                .orElseThrow();
    }
}

