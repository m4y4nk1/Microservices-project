package com.vw.eacontext.ingestion;

import static com.vw.eacontext.ingestion.IngestionSupport.APPLICATION;
import static com.vw.eacontext.ingestion.IngestionSupport.BUSINESS_PROCESS;
import static com.vw.eacontext.ingestion.IngestionSupport.DOMAIN;
import static com.vw.eacontext.ingestion.IngestionSupport.INTERFACE;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Interface;
import com.vw.eacontext.model.InterfaceType;
import com.vw.eacontext.model.LifecycleStatus;

@SpringBootTest
class CsvEaDataParserTest {

    private static final String DOMAINS_CSV = """
            id,name
            DOM-SALES,Sales & CRM
            DOM-FIN,Finance
            """;

    private static final String PROCESSES_CSV = """
            id,name,domain
            BP-O2C,Order-to-Cash,DOM-SALES
            """;

    // Source columns use the mapped names: process, (owner may be blank).
    private static final String APPLICATIONS_CSV = """
            id,name,owner,domain,lifecycleStatus,techStack,process
            APP-CRM,Customer CRM,Priya Nair,DOM-SALES,Active,"Java, Oracle",BP-O2C
            APP-BILL,Billing Engine,,DOM-FIN,Active,"Java, PostgreSQL",BP-O2C
            """;

    // Source columns use the mapped names: provider, consumer.
    private static final String INTERFACES_CSV = """
            id,name,provider,consumer,type,dataObject
            IF-003,Billing->ERP Invoice,APP-BILL,APP-ERP,Event,Invoice
            """;

    @Autowired
    private CsvEaDataParser parser;

    @Test
    void parsesFromPerEntityStreamMap() {
        Map<String, InputStream> sources = new LinkedHashMap<>();
        sources.put(DOMAIN, stream(DOMAINS_CSV));
        sources.put(BUSINESS_PROCESS, stream(PROCESSES_CSV));
        sources.put(APPLICATION, stream(APPLICATIONS_CSV));
        sources.put(INTERFACE, stream(INTERFACES_CSV));

        CanonicalModel model = parser.parse(sources);

        assertThat(model.domains()).hasSize(2);
        assertThat(model.businessProcesses()).hasSize(1);
        assertThat(model.applications()).hasSize(2);
        assertThat(model.interfaces()).hasSize(1);

        Application crm = model.applications().stream()
                .filter(a -> "APP-CRM".equals(a.id())).findFirst().orElseThrow();
        assertThat(crm.processId()).isEqualTo("BP-O2C");
        assertThat(crm.lifecycleStatus()).isEqualTo(LifecycleStatus.ACTIVE);

        // Blank owner -> null.
        Application bill = model.applications().stream()
                .filter(a -> "APP-BILL".equals(a.id())).findFirst().orElseThrow();
        assertThat(bill.owner()).isNull();

        Interface invoice = model.interfaces().get(0);
        assertThat(invoice.providerId()).isEqualTo("APP-BILL");
        assertThat(invoice.consumerId()).isEqualTo("APP-ERP");
        assertThat(invoice.type()).isEqualTo(InterfaceType.EVENT);
    }

    @Test
    void parsesFromZipArchiveViaInterface() throws Exception {
        Map<String, String> files = new LinkedHashMap<>();
        files.put("domains.csv", DOMAINS_CSV);
        files.put("business_processes.csv", PROCESSES_CSV);
        files.put("applications.csv", APPLICATIONS_CSV);
        files.put("interfaces.csv", INTERFACES_CSV);

        byte[] zip = zip(files);
        CanonicalModel model = parser.parse(new ByteArrayInputStream(zip));

        assertThat(model.domains()).hasSize(2);
        assertThat(model.businessProcesses()).hasSize(1);
        assertThat(model.applications()).hasSize(2);
        assertThat(model.interfaces()).hasSize(1);
    }

    private static InputStream stream(String content) {
        return new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));
    }

    private static byte[] zip(Map<String, String> files) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(out)) {
            for (Map.Entry<String, String> e : files.entrySet()) {
                zos.putNextEntry(new ZipEntry(e.getKey()));
                zos.write(e.getValue().getBytes(StandardCharsets.UTF_8));
                zos.closeEntry();
            }
        }
        return out.toByteArray();
    }
}

