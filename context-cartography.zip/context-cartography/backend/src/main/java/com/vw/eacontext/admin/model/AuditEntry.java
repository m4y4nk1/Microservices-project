package com.vw.eacontext.admin.model;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * One immutable row of the audit trail.
 *
 * <p>Every privileged operation — logins, user/role changes, AI invocations,
 * uploads and exports — writes exactly one entry. Rows are never updated or
 * deleted through the API.</p>
 */
@Entity
@Table(name = "audit_entries", indexes = {
        @Index(name = "idx_audit_created_at", columnList = "created_at"),
        @Index(name = "idx_audit_actor", columnList = "actor"),
        @Index(name = "idx_audit_action", columnList = "action")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class AuditEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Email of the acting user, or {@code system}/{@code anonymous}. */
    @Column(name = "actor", nullable = false, length = 190)
    private String actor;

    @Enumerated(EnumType.STRING)
    @Column(name = "action", nullable = false, length = 48)
    private AuditAction action;

    /** Free-form context, e.g. the affected entity or a summary of the change. */
    @Column(name = "detail", length = 1000)
    private String detail;

    /** Non-null for AI actions: tokens consumed by the call. */
    @Column(name = "tokens_used")
    private Integer tokensUsed;

    /** {@code true} when the audited operation completed successfully. */
    @Builder.Default
    @Column(name = "success", nullable = false)
    private boolean success = true;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @PrePersist
    void onCreate() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }
}

