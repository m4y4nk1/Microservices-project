package com.vw.eacontext.admin.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vw.eacontext.admin.model.AuditAction;
import com.vw.eacontext.admin.model.AuditEntry;
import com.vw.eacontext.admin.repository.AuditEntryRepository;
import com.vw.eacontext.security.service.CurrentUserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Writes and reads the Contexa audit trail.
 *
 * <p>Writes run in a {@link Propagation#REQUIRES_NEW} transaction and swallow
 * their own failures: auditing must never roll back or break the business
 * operation it is recording.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuditService {

    private static final int MAX_DETAIL_LENGTH = 1000;

    private final AuditEntryRepository repository;
    private final CurrentUserService currentUser;

    /** Records a successful action performed by the current user. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(AuditAction action, String detail) {
        write(currentUser.actor(), action, detail, null, true);
    }

    /** Records an action attributed to an explicit actor (e.g. failed logins). */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(String actor, AuditAction action, String detail) {
        write(actor, action, detail, null, true);
    }

    /** Records a failed attempt, e.g. a denied AI call or a rejected upload. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logFailure(String actor, AuditAction action, String detail) {
        write(actor, action, detail, null, false);
    }

    /** Records an AI invocation together with the tokens it consumed. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logAiCall(String actor, String feature, int tokensUsed, boolean success) {
        write(actor,
                success ? AuditAction.AI_CALL : AuditAction.AI_CALL_DENIED,
                "feature=" + feature,
                tokensUsed,
                success);
    }

    /** @return the most recent audit entries, newest first. */
    @Transactional(readOnly = true)
    public Page<AuditEntry> recent(int page, int size) {
        Pageable pageable = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 500));
        return repository.findAllByOrderByCreatedAtDesc(pageable);
    }

    /** @return audit entries for one actor, newest first. */
    @Transactional(readOnly = true)
    public Page<AuditEntry> byActor(String actor, int page, int size) {
        Pageable pageable = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 500));
        return repository.findByActorIgnoreCaseOrderByCreatedAtDesc(actor, pageable);
    }

    /** @return audit entries restricted to the given actions, newest first. */
    @Transactional(readOnly = true)
    public Page<AuditEntry> byActions(List<AuditAction> actions, int page, int size) {
        Pageable pageable = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 500));
        return repository.findByActionInOrderByCreatedAtDesc(actions, pageable);
    }

    private void write(String actor, AuditAction action, String detail,
                       Integer tokensUsed, boolean success) {
        try {
            repository.save(AuditEntry.builder()
                    .actor(actor == null ? CurrentUserService.SYSTEM_ACTOR : actor)
                    .action(action)
                    .detail(truncate(detail))
                    .tokensUsed(tokensUsed)
                    .success(success)
                    .build());
        } catch (Exception e) {
            // Auditing is best-effort; never fail the caller because of it.
            log.warn("Failed to write audit entry {} for {}: {}", action, actor, e.toString());
        }
    }

    private String truncate(String detail) {
        if (detail == null) {
            return null;
        }
        return detail.length() <= MAX_DETAIL_LENGTH
                ? detail
                : detail.substring(0, MAX_DETAIL_LENGTH - 3) + "...";
    }
}




