package com.vw.eacontext.admin.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vw.eacontext.admin.dto.PermissionDto;
import com.vw.eacontext.admin.dto.RoleDto;
import com.vw.eacontext.admin.dto.UpdateRolePermissionsRequest;
import com.vw.eacontext.admin.service.AdminRoleService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;

/**
 * Role and permission administration, gated on
 * {@link com.vw.eacontext.security.model.PermissionCode#ROLE_MANAGE}.
 *
 * <p>The permission catalogue is also readable with {@code USER_MANAGE} so the
 * user-editing screen can display what a role grants.</p>
 */
@RestController
@RequestMapping(value = "/api/admin", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
public class AdminRoleController {

    private final AdminRoleService roleService;

    /** Lists all roles with their permissions and user counts. */
    @PreAuthorize("hasAnyAuthority('ROLE_MANAGE','USER_MANAGE')")
    @GetMapping("/roles")
    public ResponseEntity<List<RoleDto>> listRoles() {
        return ResponseEntity.ok(roleService.list());
    }

    /** Fetches one role by name. */
    @PreAuthorize("hasAnyAuthority('ROLE_MANAGE','USER_MANAGE')")
    @GetMapping("/roles/{name}")
    public ResponseEntity<RoleDto> getRole(@PathVariable String name) {
        return ResponseEntity.ok(roleService.get(name));
    }

    /** Returns the full permission catalogue for the admin matrix UI. */
    @PreAuthorize("hasAnyAuthority('ROLE_MANAGE','USER_MANAGE')")
    @GetMapping("/permissions")
    public ResponseEntity<List<PermissionDto>> listPermissions() {
        return ResponseEntity.ok(roleService.catalogue());
    }

    /** Replaces a role's permission set. */
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @PutMapping(value = "/roles/{name}/permissions", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RoleDto> updatePermissions(
            @PathVariable String name,
            @Valid @RequestBody UpdateRolePermissionsRequest request) {
        return ResponseEntity.ok(roleService.updatePermissions(name, request));
    }

    /** Creates a custom role with no permissions. */
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @PostMapping("/roles")
    public ResponseEntity<RoleDto> createRole(@RequestParam @NotBlank String name,
                                              @RequestParam(required = false) String description) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(roleService.create(name, description));
    }

    /** Deletes an unused custom role. */
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @DeleteMapping("/roles/{name}")
    public ResponseEntity<Void> deleteRole(@PathVariable String name) {
        roleService.delete(name);
        return ResponseEntity.noContent().build();
    }
}

