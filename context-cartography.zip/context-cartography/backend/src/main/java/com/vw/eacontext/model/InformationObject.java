package com.vw.eacontext.model;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;

/**
 * Canonical representation of an information/data object exchanged across
 * interfaces or managed by applications.
 *
 * @param id   unique information object identifier (required)
 * @param name human-readable information object name (required)
 */
@Builder
public record InformationObject(
        @NotBlank String id,
        @NotBlank String name
) {
}

