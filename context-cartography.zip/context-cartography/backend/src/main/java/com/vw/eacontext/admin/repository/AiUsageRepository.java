package com.vw.eacontext.admin.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vw.eacontext.admin.model.AiUsage;

/** Repository for per-user daily AI token consumption. */
public interface AiUsageRepository extends JpaRepository<AiUsage, Long> {

    Optional<AiUsage> findByUserEmailAndUsageDate(String userEmail, LocalDate usageDate);

    List<AiUsage> findByUsageDateOrderByTokensUsedDesc(LocalDate usageDate);
}

