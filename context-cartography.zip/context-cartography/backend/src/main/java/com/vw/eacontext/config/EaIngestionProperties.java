package com.vw.eacontext.config;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * Externalized, format-independent configuration for EA ingestion.
 *
 * <p>Bound from {@code ea.ingestion.*} in {@code application.yml}. The
 * {@link #fields column mapping} is shared by every parser (JSON, CSV, Excel),
 * while each format contributes only its own locator config (JSON array names,
 * Excel sheet names, CSV file names). Renaming a source column/field/sheet is a
 * pure configuration change.</p>
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "ea.ingestion")
public class EaIngestionProperties {

    /**
     * Shared per-entity field mapping: outer key is the entity type
     * (e.g. {@code application}), inner map is {@code modelField -> sourceColumn}.
     * The source column is the JSON property, CSV header, or Excel column header.
     */
    private Map<String, Map<String, String>> fields = new LinkedHashMap<>();

    /** JSON-specific configuration. */
    private Json json = new Json();

    /** Excel-specific configuration. */
    private Excel excel = new Excel();

    /** CSV-specific configuration. */
    private Csv csv = new Csv();

    /**
     * Resolves the source column/field name for a canonical model field,
     * falling back to the model field name when no explicit mapping exists.
     *
     * @param entity     entity type key (e.g. {@code application})
     * @param modelField canonical model field name (e.g. {@code lifecycleStatus})
     * @return the source column/field name to read
     */
    public String column(String entity, String modelField) {
        return fields.getOrDefault(entity, Map.of()).getOrDefault(modelField, modelField);
    }

    /** JSON parser configuration. */
    @Getter
    @Setter
    public static class Json {
        /** Names of the top-level JSON arrays holding each entity type. */
        private Roots roots = new Roots();

        @Getter
        @Setter
        public static class Roots {
            private String domains = "domains";
            private String businessProcesses = "businessProcesses";
            private String applications = "applications";
            private String interfaces = "interfaces";
            private String informationObjects = "informationObjects";
        }
    }

    /** Excel parser configuration. */
    @Getter
    @Setter
    public static class Excel {
        /** Entity type -> worksheet name. */
        private Map<String, String> sheets = new LinkedHashMap<>();
    }

    /** CSV parser configuration. */
    @Getter
    @Setter
    public static class Csv {
        /** Entity type -> file name (used when reading a ZIP of CSV files). */
        private Map<String, String> files = new LinkedHashMap<>();
    }
}

