package com.vw.eacontext.security.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import lombok.RequiredArgsConstructor;

/**
 * The production security wiring: stateless JWT authentication plus
 * method-level authorization via {@code @PreAuthorize}.
 *
 * <p>Everything under {@code /api/**} requires authentication except the login
 * endpoint. Fine-grained rules are expressed as permission checks on the
 * controller methods themselves rather than URL patterns, so a permission can
 * be re-assigned in the admin console without touching this class.</p>
 *
 * <p>Activated unless {@code contexa.security.enabled=false}; see
 * {@link NoSecurityConfig} for the opt-out used by the legacy test-suite.</p>
 */
@Configuration
@EnableMethodSecurity
@RequiredArgsConstructor
@ConditionalOnProperty(name = "contexa.security.enabled", havingValue = "true", matchIfMissing = true)
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;
    private final SecurityErrorHandlers errorHandlers;
    private final DaoAuthenticationProvider authenticationProvider;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // Stateless JWT API: CSRF tokens are not applicable.
                .csrf(csrf -> csrf.disable())
                // Reuse the existing WebMvc CORS registration (see CorsConfig).
                .cors(cors -> { })
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .exceptionHandling(e -> e
                        .authenticationEntryPoint(errorHandlers)
                        .accessDeniedHandler(errorHandlers))
                .authorizeHttpRequests(auth -> auth
                        // Pre-flight must never be challenged.
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        // Login is the only anonymous API surface.
                        .requestMatchers("/api/auth/login").permitAll()
                        .requestMatchers("/error", "/actuator/health").permitAll()
                        .requestMatchers("/h2-console/**").permitAll()
                        // The admin surface additionally needs one of the admin permissions.
                        .requestMatchers("/api/admin/**")
                        .hasAnyAuthority("USER_MANAGE", "ROLE_MANAGE", "AI_CONFIG", "AUDIT_VIEW")
                        .requestMatchers("/api/**").authenticated()
                        .anyRequest().permitAll())
                .headers(h -> h.frameOptions(f -> f.sameOrigin()))
                .authenticationProvider(authenticationProvider)
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}


