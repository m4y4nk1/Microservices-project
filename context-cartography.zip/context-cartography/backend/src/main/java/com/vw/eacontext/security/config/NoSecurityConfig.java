package com.vw.eacontext.security.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Opt-out chain enabled only by {@code contexa.security.enabled=false}.
 *
 * <p>It permits every request and — crucially — does <em>not</em> switch on
 * {@code @EnableMethodSecurity}, so the {@code @PreAuthorize} annotations on the
 * EA controllers become inert. This exists so the pre-existing graph/ingestion
 * test-suite can keep calling the API anonymously; it must never be used in a
 * deployed environment.</p>
 */
@Configuration
@ConditionalOnProperty(name = "contexa.security.enabled", havingValue = "false")
public class NoSecurityConfig {

    @Bean
    public SecurityFilterChain permitAllFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .cors(cors -> { })
                .authorizeHttpRequests(auth -> auth.anyRequest().permitAll())
                .headers(h -> h.frameOptions(f -> f.sameOrigin()));
        return http.build();
    }
}

