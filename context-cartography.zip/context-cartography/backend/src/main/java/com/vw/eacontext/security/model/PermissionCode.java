package com.vw.eacontext.security.model;

import java.util.Arrays;
import java.util.List;

/**
 * The complete catalogue of feature-level permissions in Contexa.
 *
 * <p>Features are bound to <em>permissions</em>, never to roles. Roles are only
 * bundles of permissions, which is what makes individual capabilities (in
 * particular the cost-bearing AI features) grantable one by one from the admin
 * console.</p>
 *
 * <p>The enum name is the Spring Security authority string, so
 * {@code @PreAuthorize("hasAuthority('AI_SUMMARY')")} lines up 1:1 with
 * {@link #AI_SUMMARY}.</p>
 */
public enum PermissionCode {

    // ---- Data ------------------------------------------------------------
    DATA_UPLOAD(Category.DATA, "Upload an EA dataset"),
    DATA_EDIT(Category.DATA, "Edit the canonical model"),
    DATA_DELETE(Category.DATA, "Delete / reset the loaded model"),

    // ---- Diagrams (frame level) ------------------------------------------
    DIAGRAM_VIEW(Category.DIAGRAM, "Access the diagram endpoints at all"),
    DIAGRAM_VIEW_APPLICATION(Category.DIAGRAM, "View the application frame"),
    DIAGRAM_VIEW_PROCESS(Category.DIAGRAM, "View the business process frame"),
    DIAGRAM_VIEW_DOMAIN(Category.DIAGRAM, "View the domain frame"),
    DIAGRAM_VIEW_INFOFLOW(Category.DIAGRAM, "View the information flow frame"),

    // ---- Analysis --------------------------------------------------------
    ANALYSIS_DEPENDENCY(Category.ANALYSIS, "Inspect dependency structure"),
    ANALYSIS_IMPACT(Category.ANALYSIS, "Run blast-radius / impact analysis"),
    ANALYSIS_RISK(Category.ANALYSIS, "View insight findings and risks"),
    ANALYSIS_GOVERNANCE(Category.ANALYSIS, "View governance / ownership analysis"),

    // ---- AI (cost bearing) -----------------------------------------------
    AI_SUMMARY(Category.AI, "Generate the natural-language landscape summary"),
    AI_QUERY(Category.AI, "Ask natural-language questions about the landscape"),
    AI_ENRICHMENT(Category.AI, "Use AI-assisted schema mapping and data cleaning"),
    AI_RECOMMENDATION(Category.AI, "Receive AI remediation recommendations"),
    AI_AGENT(Category.AI, "Run autonomous AI agent workflows"),

    // ---- Export ----------------------------------------------------------
    EXPORT_PNG(Category.EXPORT, "Export the landscape as PNG"),
    EXPORT_PDF(Category.EXPORT, "Export the landscape as PDF"),
    EXPORT_PPTX(Category.EXPORT, "Export the landscape as PPTX"),

    // ---- Administration --------------------------------------------------
    USER_MANAGE(Category.ADMIN, "Create, invite, edit and deactivate users"),
    ROLE_MANAGE(Category.ADMIN, "Assign roles and edit role permissions"),
    AI_CONFIG(Category.ADMIN, "Configure the AI model, budgets and feature toggles"),
    AUDIT_VIEW(Category.ADMIN, "Read the audit trail");

    /** Grouping used by the admin UI to render the permission matrix. */
    public enum Category {
        DATA, DIAGRAM, ANALYSIS, AI, EXPORT, ADMIN
    }

    private final Category category;
    private final String description;

    PermissionCode(Category category, String description) {
        this.category = category;
        this.description = description;
    }

    public Category category() {
        return category;
    }

    public String description() {
        return description;
    }

    /** @return every permission code, in declaration order. */
    public static List<PermissionCode> all() {
        return Arrays.asList(values());
    }

    /** @return {@code true} if the given string is a known permission code. */
    public static boolean isValid(String code) {
        return Arrays.stream(values()).anyMatch(p -> p.name().equals(code));
    }
}

