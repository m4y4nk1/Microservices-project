package com.vw.eacontext.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jgrapht.Graph;
import org.springframework.stereotype.Service;

import com.vw.eacontext.dto.GraphDto;
import com.vw.eacontext.dto.GraphEdge;
import com.vw.eacontext.dto.GraphNode;
import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.BusinessProcess;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Domain;
import com.vw.eacontext.model.InformationObject;
import com.vw.eacontext.model.Interface;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Projects a {@link CanonicalModel} into the four observation frames, each
 * returned as a frame-agnostic {@link GraphDto} (nodes + edges) for the frontend.
 *
 * <ul>
 *   <li>{@link #applicationView(CanonicalModel)} â€” applications as nodes,
 *       interfaces as provider &rarr; consumer edges.</li>
 *   <li>{@link #businessProcessView(CanonicalModel)} â€” processes and the
 *       applications that realize them (membership edges).</li>
 *   <li>{@link #domainView(CanonicalModel)} â€” applications aggregated into their
 *       domain, with cross-domain interfaces collapsed into domain &rarr; domain edges.</li>
 *   <li>{@link #informationFlowView(CanonicalModel)} â€” information objects as
 *       intermediary nodes: provider &rarr; object (produces) &rarr; consumer (consumes).</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class GraphProjectionService {

    private static final String TYPE_APPLICATION = "application";
    private static final String TYPE_DOMAIN = "domain";
    private static final String TYPE_PROCESS = "process";
    private static final String TYPE_INFORMATION_OBJECT = "informationObject";
    private static final String UNASSIGNED_DOMAIN = "__UNASSIGNED__";

    private final GraphBuilderService graphBuilderService;

    /** Application frame: applications as nodes, interfaces as directed edges. */
    public GraphDto applicationView(CanonicalModel model) {
        return applicationView(graphBuilderService.build(model));
    }

    /** Application frame reusing a pre-built graph. */
    public GraphDto applicationView(Graph<Application, InterfaceEdge> graph) {
        List<GraphNode> nodes = new ArrayList<>();
        for (Application app : graph.vertexSet()) {
            nodes.add(applicationNode(app));
        }

        List<GraphEdge> edges = new ArrayList<>();
        for (InterfaceEdge edge : graph.edgeSet()) {
            Application provider = graph.getEdgeSource(edge);
            Application consumer = graph.getEdgeTarget(edge);
            Map<String, Object> data = GraphNode.attrs();
            data.put("dataObject", edge.getDataObject());
            edges.add(new GraphEdge(
                    edge.getInterfaceId(),
                    provider.id(),
                    consumer.id(),
                    edge.getName(),
                    edge.getType() == null ? null : edge.getType().name(),
                    data));
        }
        return new GraphDto(TYPE_APPLICATION, nodes, edges);
    }

    /** Business-process frame: processes and their member applications. */
    public GraphDto businessProcessView(CanonicalModel model) {

        List<GraphNode> nodes = new ArrayList<>();
        List<GraphEdge> edges = new ArrayList<>();
        Set<String> addedApps = new HashSet<>();
        Set<String> processIds = new HashSet<>();

        for (BusinessProcess process : model.businessProcesses()) {
            if (isBlank(process.id())) {
                continue;
            }
            processIds.add(process.id());
            Map<String, Object> data = GraphNode.attrs();
            data.put("domainId", process.domainId());
            nodes.add(new GraphNode(process.id(), process.name(), TYPE_PROCESS, data));
        }

        for (Application app : model.applications()) {
            String processId = app.processId();
            if (isBlank(processId) || !processIds.contains(processId)) {
                continue; // unmapped apps are not part of the process frame
            }
            if (addedApps.add(app.id())) {
                nodes.add(applicationNode(app));
            }
            edges.add(new GraphEdge(
                    processId + "->" + app.id(),
                    processId,
                    app.id(),
                    "realizes",
                    "membership"));
        }
        return new GraphDto(TYPE_PROCESS, nodes, edges);
    }

    /** Domain frame: apps aggregated into domains; cross-domain edges collapsed. */
    public GraphDto domainView(CanonicalModel model) {
        return domainView(model, graphBuilderService.build(model));
    }

    /** Domain frame reusing a pre-built graph. */
    public GraphDto domainView(CanonicalModel model, Graph<Application, InterfaceEdge> graph) {
        Map<String, String> domainNameById = new HashMap<>();
        for (Domain domain : model.domains()) {
            if (!isBlank(domain.id())) {
                domainNameById.put(domain.id(), domain.name());
            }
        }

        // Count applications per domain.
        Map<String, Integer> appCountByDomain = new LinkedHashMap<>();
        Map<String, String> domainKeyByAppId = new HashMap<>();
        for (Application app : model.applications()) {
            if (isBlank(app.id())) {
                continue;
            }
            String domainKey = isBlank(app.domain()) ? UNASSIGNED_DOMAIN : app.domain();
            domainKeyByAppId.put(app.id(), domainKey);
            appCountByDomain.merge(domainKey, 1, Integer::sum);
        }

        List<GraphNode> nodes = new ArrayList<>();
        appCountByDomain.forEach((domainKey, count) -> {
            String name = UNASSIGNED_DOMAIN.equals(domainKey)
                    ? "Unassigned"
                    : domainNameById.getOrDefault(domainKey, domainKey);
            Map<String, Object> data = GraphNode.attrs();
            data.put("applicationCount", count);
            nodes.add(new GraphNode(domainKey, name + " (" + count + ")", TYPE_DOMAIN, data));
        });

        // Collapse cross-domain interfaces into weighted domain -> domain edges.
        Map<String, Integer> edgeWeights = new LinkedHashMap<>();
        for (InterfaceEdge edge : graph.edgeSet()) {
            String from = domainKeyByAppId.get(graph.getEdgeSource(edge).id());
            String to = domainKeyByAppId.get(graph.getEdgeTarget(edge).id());
            if (from == null || to == null || from.equals(to)) {
                continue; // ignore intra-domain interfaces
            }
            edgeWeights.merge(from + ">" + to, 1, Integer::sum);
        }

        List<GraphEdge> edges = new ArrayList<>();
        edgeWeights.forEach((key, weight) -> {
            String[] parts = key.split(">", 2);
            Map<String, Object> data = GraphNode.attrs();
            data.put("interfaceCount", weight);
            edges.add(new GraphEdge(
                    "DOM_" + key,
                    parts[0],
                    parts[1],
                    weight + " interface(s)",
                    "domainFlow",
                    data));
        });
        return new GraphDto(TYPE_DOMAIN, nodes, edges);
    }

    /** Information-flow frame: provider -> information object -> consumer. */
    public GraphDto informationFlowView(CanonicalModel model) {
        Map<String, Application> appById = indexApplications(model);

        // Map information object name -> id (interfaces reference objects by name).
        Map<String, String> ioIdByName = new HashMap<>();
        for (InformationObject io : model.informationObjects()) {
            if (!isBlank(io.name())) {
                ioIdByName.put(io.name(), io.id());
            }
        }

        Map<String, GraphNode> nodes = new LinkedHashMap<>();
        List<GraphEdge> edges = new ArrayList<>();

        for (Interface iface : model.interfaces()) {
            Application provider = appById.get(iface.providerId());
            Application consumer = appById.get(iface.consumerId());
            String dataObject = iface.dataObject();
            if (provider == null || consumer == null || isBlank(dataObject)) {
                continue;
            }

            nodes.putIfAbsent(provider.id(), applicationNode(provider));
            nodes.putIfAbsent(consumer.id(), applicationNode(consumer));

            String ioId = ioIdByName.getOrDefault(dataObject, "IO:" + dataObject);
            nodes.putIfAbsent(ioId, new GraphNode(ioId, dataObject, TYPE_INFORMATION_OBJECT));

            Map<String, Object> data = GraphNode.attrs();
            data.put("interfaceId", iface.id());
            edges.add(new GraphEdge(
                    iface.id() + ":produces", provider.id(), ioId, "produces", "produces", data));
            edges.add(new GraphEdge(
                    iface.id() + ":consumes", ioId, consumer.id(), "consumes", "consumes", data));
        }
        return new GraphDto(TYPE_INFORMATION_OBJECT, new ArrayList<>(nodes.values()), edges);
    }

    // --- helpers --------------------------------------------------------------

    private GraphNode applicationNode(Application app) {
        Map<String, Object> data = GraphNode.attrs();
        data.put("domain", app.domain());
        data.put("owner", app.owner());
        data.put("lifecycleStatus", app.lifecycleStatus() == null ? null : app.lifecycleStatus().name());
        data.put("techStack", app.techStack());
        data.put("processId", app.processId());
        return new GraphNode(app.id(), app.name(), TYPE_APPLICATION, data);
    }

    private Map<String, Application> indexApplications(CanonicalModel model) {
        Map<String, Application> byId = new HashMap<>();
        for (Application app : model.applications()) {
            if (!isBlank(app.id())) {
                byId.putIfAbsent(app.id(), app);
            }
        }
        return byId;
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}

