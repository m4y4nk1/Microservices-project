package com.vw.eacontext.security.model;

import static com.vw.eacontext.security.model.PermissionCode.AI_AGENT;
import static com.vw.eacontext.security.model.PermissionCode.AI_CONFIG;
import static com.vw.eacontext.security.model.PermissionCode.AI_ENRICHMENT;
import static com.vw.eacontext.security.model.PermissionCode.AI_QUERY;
import static com.vw.eacontext.security.model.PermissionCode.AI_RECOMMENDATION;
import static com.vw.eacontext.security.model.PermissionCode.AI_SUMMARY;
import static com.vw.eacontext.security.model.PermissionCode.ANALYSIS_DEPENDENCY;
import static com.vw.eacontext.security.model.PermissionCode.ANALYSIS_GOVERNANCE;
import static com.vw.eacontext.security.model.PermissionCode.ANALYSIS_IMPACT;
import static com.vw.eacontext.security.model.PermissionCode.ANALYSIS_RISK;
import static com.vw.eacontext.security.model.PermissionCode.AUDIT_VIEW;
import static com.vw.eacontext.security.model.PermissionCode.DATA_DELETE;
import static com.vw.eacontext.security.model.PermissionCode.DATA_EDIT;
import static com.vw.eacontext.security.model.PermissionCode.DATA_UPLOAD;
import static com.vw.eacontext.security.model.PermissionCode.DIAGRAM_VIEW;
import static com.vw.eacontext.security.model.PermissionCode.DIAGRAM_VIEW_APPLICATION;
import static com.vw.eacontext.security.model.PermissionCode.DIAGRAM_VIEW_DOMAIN;
import static com.vw.eacontext.security.model.PermissionCode.DIAGRAM_VIEW_INFOFLOW;
import static com.vw.eacontext.security.model.PermissionCode.DIAGRAM_VIEW_PROCESS;
import static com.vw.eacontext.security.model.PermissionCode.EXPORT_PDF;
import static com.vw.eacontext.security.model.PermissionCode.EXPORT_PNG;
import static com.vw.eacontext.security.model.PermissionCode.EXPORT_PPTX;
import static com.vw.eacontext.security.model.PermissionCode.ROLE_MANAGE;
import static com.vw.eacontext.security.model.PermissionCode.USER_MANAGE;

import java.util.EnumSet;
import java.util.Set;

/**
 * The seeded, out-of-the-box roles and their default permission matrix.
 *
 * <p>These are only <em>defaults</em>: once the application has started, an
 * administrator with {@link PermissionCode#ROLE_MANAGE} can change any role's
 * permissions from the Contexa Admin console, and the seeder will not overwrite
 * existing roles.</p>
 */
public enum RoleName {

    /** Platform owner. Everything, including AI configuration. */
    SUPER_ADMIN(EnumSet.allOf(PermissionCode.class)),

    /** Manages people and governance, but not the AI model/budget itself. */
    ADMIN(EnumSet.of(
            DATA_UPLOAD, DATA_EDIT, DATA_DELETE,
            DIAGRAM_VIEW, DIAGRAM_VIEW_APPLICATION, DIAGRAM_VIEW_PROCESS,
            DIAGRAM_VIEW_DOMAIN, DIAGRAM_VIEW_INFOFLOW,
            ANALYSIS_DEPENDENCY, ANALYSIS_IMPACT, ANALYSIS_RISK, ANALYSIS_GOVERNANCE,
            AI_SUMMARY, AI_QUERY, AI_ENRICHMENT, AI_RECOMMENDATION,
            EXPORT_PNG, EXPORT_PDF, EXPORT_PPTX,
            USER_MANAGE, ROLE_MANAGE, AUDIT_VIEW)),

    /** Full data + diagram + AI + export rights; no administration. */
    ARCHITECT(EnumSet.of(
            DATA_UPLOAD, DATA_EDIT, DATA_DELETE,
            DIAGRAM_VIEW, DIAGRAM_VIEW_APPLICATION, DIAGRAM_VIEW_PROCESS,
            DIAGRAM_VIEW_DOMAIN, DIAGRAM_VIEW_INFOFLOW,
            ANALYSIS_DEPENDENCY, ANALYSIS_IMPACT, ANALYSIS_RISK, ANALYSIS_GOVERNANCE,
            AI_SUMMARY, AI_QUERY, AI_ENRICHMENT, AI_RECOMMENDATION,
            EXPORT_PNG, EXPORT_PDF, EXPORT_PPTX)),

    /** Reads and analyses, may use AI; cannot change data. */
    ANALYST(EnumSet.of(
            DIAGRAM_VIEW, DIAGRAM_VIEW_APPLICATION, DIAGRAM_VIEW_PROCESS,
            DIAGRAM_VIEW_DOMAIN, DIAGRAM_VIEW_INFOFLOW,
            ANALYSIS_DEPENDENCY, ANALYSIS_IMPACT, ANALYSIS_RISK, ANALYSIS_GOVERNANCE,
            AI_SUMMARY, AI_QUERY, AI_RECOMMENDATION,
            EXPORT_PNG, EXPORT_PDF, EXPORT_PPTX)),

    /** Read-only diagrams. No AI, no export, no analysis. */
    VIEWER(EnumSet.of(
            DIAGRAM_VIEW, DIAGRAM_VIEW_APPLICATION, DIAGRAM_VIEW_PROCESS,
            DIAGRAM_VIEW_DOMAIN, DIAGRAM_VIEW_INFOFLOW)),

    /** Demo access: the application frame only. */
    GUEST(EnumSet.of(DIAGRAM_VIEW, DIAGRAM_VIEW_APPLICATION));

    private final Set<PermissionCode> defaultPermissions;

    RoleName(Set<PermissionCode> defaultPermissions) {
        this.defaultPermissions = defaultPermissions;
    }

    /** @return an unmodifiable copy of this role's seeded permissions. */
    public Set<PermissionCode> defaultPermissions() {
        return Set.copyOf(defaultPermissions);
    }

    /** Sanity guard so {@link #AI_AGENT} stays SUPER_ADMIN-only by default. */
    static {
        assert !ADMIN.defaultPermissions.contains(AI_AGENT);
        assert !ADMIN.defaultPermissions.contains(AI_CONFIG);
    }
}

