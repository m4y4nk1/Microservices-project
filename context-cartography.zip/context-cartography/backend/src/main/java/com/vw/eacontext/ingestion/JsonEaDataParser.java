package com.vw.eacontext.ingestion;

import static com.vw.eacontext.ingestion.IngestionSupport.APPLICATION;
import static com.vw.eacontext.ingestion.IngestionSupport.BUSINESS_PROCESS;
import static com.vw.eacontext.ingestion.IngestionSupport.DOMAIN;
import static com.vw.eacontext.ingestion.IngestionSupport.INFORMATION_OBJECT;
import static com.vw.eacontext.ingestion.IngestionSupport.INTERFACE;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vw.eacontext.config.EaIngestionProperties;
import com.vw.eacontext.exception.EaIngestionException;
import com.vw.eacontext.model.CanonicalModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * {@link EaDataParser} for JSON sources, backed by Jackson.
 *
 * <p>The mapping from JSON property names to canonical model fields is fully
 * externalized via {@link EaIngestionProperties}, so property renames in the
 * source require only a configuration change.</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JsonEaDataParser implements EaDataParser {

    private final ObjectMapper objectMapper;
    private final EaIngestionProperties properties;

    @Override
    public CanonicalModel parse(InputStream in) {
        final JsonNode root;
        try {
            root = objectMapper.readTree(in);
        } catch (IOException e) {
            throw new EaIngestionException("Failed to read JSON EA dataset", e);
        }
        if (root == null || root.isNull()) {
            throw new EaIngestionException("JSON EA dataset is empty");
        }

        EaIngestionProperties.Json.Roots roots = properties.getJson().getRoots();

        CanonicalModel model = CanonicalModel.builder()
                .domains(mapArray(root, roots.getDomains(), DOMAIN, IngestionSupport::toDomain))
                .businessProcesses(mapArray(root, roots.getBusinessProcesses(), BUSINESS_PROCESS, IngestionSupport::toBusinessProcess))
                .applications(mapArray(root, roots.getApplications(), APPLICATION, IngestionSupport::toApplication))
                .interfaces(mapArray(root, roots.getInterfaces(), INTERFACE, IngestionSupport::toInterface))
                .informationObjects(mapArray(root, roots.getInformationObjects(), INFORMATION_OBJECT, IngestionSupport::toInformationObject))
                .build();

        log.info("Parsed JSON EA dataset: {} domains, {} processes, {} applications, {} interfaces, {} information objects",
                model.domains().size(), model.businessProcesses().size(), model.applications().size(),
                model.interfaces().size(), model.informationObjects().size());
        return model;
    }

    private <T> List<T> mapArray(JsonNode root, String arrayName, String entity,
                                 Function<Function<String, String>, T> builder) {
        JsonNode array = root.get(arrayName);
        if (array == null || !array.isArray()) {
            log.warn("Expected JSON array '{}' not found; treating as empty", arrayName);
            return List.of();
        }
        List<T> result = new ArrayList<>(array.size());
        for (JsonNode node : array) {
            Function<String, String> reader = modelField -> {
                JsonNode value = node.get(properties.column(entity, modelField));
                return (value == null || value.isNull()) ? null : IngestionSupport.blankToNull(value.asText());
            };
            result.add(builder.apply(reader));
        }
        return result;
    }
}

