package com.vw.eacontext.admin.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vw.eacontext.admin.dto.AiSettingsRequest;
import com.vw.eacontext.admin.model.AiSettings;
import com.vw.eacontext.admin.model.AuditAction;
import com.vw.eacontext.admin.repository.AiSettingsRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Reads and updates the singleton {@link AiSettings} row.
 *
 * <p>The row is created lazily on first access so a fresh database needs no
 * migration step.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AiSettingsService {

    private final AiSettingsRepository repository;
    private final AuditService audit;

    /** @return the current settings, creating defaults on first call. */
    @Transactional
    public AiSettings get() {
        return repository.findById(AiSettings.SINGLETON_ID)
                .orElseGet(() -> repository.save(AiSettings.defaults()));
    }

    /**
     * Applies an administrator's changes to the AI governance settings.
     *
     * @param request the requested new values
     * @return the persisted settings
     */
    @Transactional
    public AiSettings update(AiSettingsRequest request) {
        AiSettings settings = get();
        settings.setAiEnabled(request.aiEnabled());
        settings.setModel(request.model());
        settings.setDailyTokenBudgetPerUser(Math.max(request.dailyTokenBudgetPerUser(), 0));
        settings.setSummaryEnabled(request.summaryEnabled());
        settings.setQueryEnabled(request.queryEnabled());
        settings.setEnrichmentEnabled(request.enrichmentEnabled());
        settings.setRecommendationEnabled(request.recommendationEnabled());
        settings.setAgentEnabled(request.agentEnabled());

        AiSettings saved = repository.save(settings);
        audit.log(AuditAction.AI_SETTINGS_UPDATED,
                "aiEnabled=" + saved.isAiEnabled()
                        + ", model=" + saved.getModel()
                        + ", dailyTokenBudgetPerUser=" + saved.getDailyTokenBudgetPerUser());
        log.info("AI settings updated: {}", saved);
        return saved;
    }
}

