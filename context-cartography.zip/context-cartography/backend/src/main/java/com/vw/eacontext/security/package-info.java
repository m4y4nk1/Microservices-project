/**
 * Contexa's role-based access control: JWT authentication, the user/role/
 * permission model, and the authorization helpers used across the API.
 *
 * <p>Features are always bound to <em>permissions</em> rather than roles, so an
 * administrator can re-grant any capability from the admin console without a
 * code change.</p>
 */
package com.vw.eacontext.security;

