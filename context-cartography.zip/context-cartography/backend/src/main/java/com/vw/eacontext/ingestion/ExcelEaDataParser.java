package com.vw.eacontext.ingestion;

import static com.vw.eacontext.ingestion.IngestionSupport.APPLICATION;
import static com.vw.eacontext.ingestion.IngestionSupport.BUSINESS_PROCESS;
import static com.vw.eacontext.ingestion.IngestionSupport.DOMAIN;
import static com.vw.eacontext.ingestion.IngestionSupport.INFORMATION_OBJECT;
import static com.vw.eacontext.ingestion.IngestionSupport.INTERFACE;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import com.vw.eacontext.config.EaIngestionProperties;
import com.vw.eacontext.exception.EaIngestionException;
import com.vw.eacontext.model.CanonicalModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * {@link EaDataParser} for Excel (.xlsx) workbooks, backed by Apache POI, using
 * one worksheet per entity.
 *
 * <p>Sheet names are configured via {@code ea.ingestion.excel.sheets} and the
 * column-to-field mapping is shared with the other parsers via
 * {@link EaIngestionProperties}. The header row is detected dynamically (it does
 * not need to be the first row), so leading title/description rows are tolerated.</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ExcelEaDataParser implements EaDataParser {

    private final EaIngestionProperties properties;
    private final DataFormatter dataFormatter = new DataFormatter();

    @Override
    public CanonicalModel parse(InputStream in) {
        try (Workbook workbook = new XSSFWorkbook(in)) {
            Map<String, String> sheets = properties.getExcel().getSheets();

            CanonicalModel model = CanonicalModel.builder()
                    .domains(readSheet(workbook, sheets.get(DOMAIN), DOMAIN, IngestionSupport::toDomain))
                    .businessProcesses(readSheet(workbook, sheets.get(BUSINESS_PROCESS), BUSINESS_PROCESS, IngestionSupport::toBusinessProcess))
                    .applications(readSheet(workbook, sheets.get(APPLICATION), APPLICATION, IngestionSupport::toApplication))
                    .interfaces(readSheet(workbook, sheets.get(INTERFACE), INTERFACE, IngestionSupport::toInterface))
                    .informationObjects(readSheet(workbook, sheets.get(INFORMATION_OBJECT), INFORMATION_OBJECT, IngestionSupport::toInformationObject))
                    .build();

            log.info("Parsed Excel EA dataset: {} domains, {} processes, {} applications, {} interfaces, {} information objects",
                    model.domains().size(), model.businessProcesses().size(), model.applications().size(),
                    model.interfaces().size(), model.informationObjects().size());
            return model;
        } catch (IOException e) {
            throw new EaIngestionException("Failed to read Excel EA dataset", e);
        }
    }

    private <T> List<T> readSheet(Workbook workbook, String sheetName, String entity,
                                  Function<Function<String, String>, T> builder) {
        if (sheetName == null || sheetName.isBlank()) {
            log.warn("No sheet configured for entity '{}'; treating as empty", entity);
            return List.of();
        }
        Sheet sheet = workbook.getSheet(sheetName);
        if (sheet == null) {
            log.warn("Sheet '{}' not found for entity '{}'; treating as empty", sheetName, entity);
            return List.of();
        }

        String idColumn = properties.column(entity, "id");
        String nameColumn = properties.column(entity, "name");
        Map<String, Integer> headerIndex = findHeader(sheet, idColumn, nameColumn);
        if (headerIndex == null) {
            log.warn("Header row not found in sheet '{}' (expected columns '{}' and '{}'); treating as empty",
                    sheetName, idColumn, nameColumn);
            return List.of();
        }

        int headerRowNum = headerIndex.remove("__row__");
        List<T> result = new ArrayList<>();
        for (int r = headerRowNum + 1; r <= sheet.getLastRowNum(); r++) {
            Row row = sheet.getRow(r);
            if (row == null || isRowBlank(row, headerIndex)) {
                continue;
            }
            Function<String, String> read = modelField -> {
                Integer col = headerIndex.get(properties.column(entity, modelField));
                if (col == null) {
                    return null;
                }
                return IngestionSupport.blankToNull(cellText(row.getCell(col)));
            };
            result.add(builder.apply(read));
        }
        return result;
    }

    /**
     * Scans the first rows for the header (the row containing both the id and
     * name column headers) and returns a header-name -> column-index map, with
     * the special key {@code __row__} holding the header row number.
     */
    private Map<String, Integer> findHeader(Sheet sheet, String idColumn, String nameColumn) {
        int lastRow = Math.min(sheet.getLastRowNum(), sheet.getFirstRowNum() + 25);
        for (int r = sheet.getFirstRowNum(); r <= lastRow; r++) {
            Row row = sheet.getRow(r);
            if (row == null) {
                continue;
            }
            Map<String, Integer> index = new LinkedHashMap<>();
            for (Cell cell : row) {
                String text = cellText(cell);
                if (text != null && !text.isBlank()) {
                    index.putIfAbsent(text.trim(), cell.getColumnIndex());
                }
            }
            if (index.containsKey(idColumn) && index.containsKey(nameColumn)) {
                index.put("__row__", r);
                return index;
            }
        }
        return null;
    }

    private boolean isRowBlank(Row row, Map<String, Integer> headerIndex) {
        for (Integer col : headerIndex.values()) {
            if (IngestionSupport.blankToNull(cellText(row.getCell(col))) != null) {
                return false;
            }
        }
        return true;
    }

    private String cellText(Cell cell) {
        return cell == null ? null : dataFormatter.formatCellValue(cell);
    }
}

