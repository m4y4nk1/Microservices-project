package com.vw.eacontext.ingestion;

import static com.vw.eacontext.ingestion.IngestionSupport.APPLICATION;
import static com.vw.eacontext.ingestion.IngestionSupport.BUSINESS_PROCESS;
import static com.vw.eacontext.ingestion.IngestionSupport.DOMAIN;
import static com.vw.eacontext.ingestion.IngestionSupport.INFORMATION_OBJECT;
import static com.vw.eacontext.ingestion.IngestionSupport.INTERFACE;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;

import com.vw.eacontext.config.EaIngestionProperties;
import com.vw.eacontext.exception.EaIngestionException;
import com.vw.eacontext.model.CanonicalModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * {@link EaDataParser} for CSV sources, backed by Apache Commons CSV, using one
 * CSV file per entity.
 *
 * <p>Two entry points are offered:</p>
 * <ul>
 *   <li>{@link #parse(Map)} â€” the natural API: a map of entity type to the
 *       corresponding CSV stream.</li>
 *   <li>{@link #parse(InputStream)} â€” the {@link EaDataParser} contract, reading
 *       a ZIP archive whose entries are the per-entity CSV files (matched to
 *       entities via {@code ea.ingestion.csv.files}).</li>
 * </ul>
 *
 * <p>Column-to-field mapping is shared with the other parsers via
 * {@link EaIngestionProperties}; CSV headers are the "source columns".</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CsvEaDataParser implements EaDataParser {

    private final EaIngestionProperties properties;

    /**
     * Parses a set of per-entity CSV streams into the canonical model.
     *
     * @param csvByEntity map of entity type key (see {@link IngestionSupport})
     *                    to its CSV {@link InputStream}; missing entities yield
     *                    empty lists
     * @return the populated canonical model
     */
    public CanonicalModel parse(Map<String, InputStream> csvByEntity) {
        CanonicalModel model = CanonicalModel.builder()
                .domains(readCsv(csvByEntity.get(DOMAIN), DOMAIN, IngestionSupport::toDomain))
                .businessProcesses(readCsv(csvByEntity.get(BUSINESS_PROCESS), BUSINESS_PROCESS, IngestionSupport::toBusinessProcess))
                .applications(readCsv(csvByEntity.get(APPLICATION), APPLICATION, IngestionSupport::toApplication))
                .interfaces(readCsv(csvByEntity.get(INTERFACE), INTERFACE, IngestionSupport::toInterface))
                .informationObjects(readCsv(csvByEntity.get(INFORMATION_OBJECT), INFORMATION_OBJECT, IngestionSupport::toInformationObject))
                .build();

        log.info("Parsed CSV EA dataset: {} domains, {} processes, {} applications, {} interfaces, {} information objects",
                model.domains().size(), model.businessProcesses().size(), model.applications().size(),
                model.interfaces().size(), model.informationObjects().size());
        return model;
    }

    /**
     * Reads a ZIP archive of per-entity CSV files. Entry names are matched to
     * entity types via {@code ea.ingestion.csv.files} (basename, case-insensitive).
     */
    @Override
    public CanonicalModel parse(InputStream in) {
        Map<String, InputStream> csvByEntity = new LinkedHashMap<>();
        Map<String, String> fileToEntity = invertFileMapping();
        try (ZipInputStream zip = new ZipInputStream(in)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                String base = baseName(entry.getName()).toLowerCase();
                String entity = fileToEntity.get(base);
                if (entity == null) {
                    log.warn("Unmapped CSV archive entry '{}'; skipping", entry.getName());
                    continue;
                }
                csvByEntity.put(entity, new ByteArrayInputStream(readAll(zip)));
            }
        } catch (IOException e) {
            throw new EaIngestionException("Failed to read CSV ZIP archive", e);
        }
        if (csvByEntity.isEmpty()) {
            throw new EaIngestionException("CSV ZIP archive contained no recognized entity files");
        }
        return parse(csvByEntity);
    }

    private <T> List<T> readCsv(InputStream in, String entity, Function<Function<String, String>, T> builder) {
        if (in == null) {
            log.warn("No CSV provided for entity '{}'; treating as empty", entity);
            return List.of();
        }
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .setIgnoreSurroundingSpaces(true)
                .setTrim(true)
                .setIgnoreEmptyLines(true)
                .build();
        List<T> result = new ArrayList<>();
        try (Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8);
             CSVParser parser = format.parse(reader)) {
            for (CSVRecord record : parser) {
                Function<String, String> read = modelField -> {
                    String column = properties.column(entity, modelField);
                    if (!record.isMapped(column) || !record.isSet(column)) {
                        return null;
                    }
                    return IngestionSupport.blankToNull(record.get(column));
                };
                result.add(builder.apply(read));
            }
        } catch (IOException e) {
            throw new EaIngestionException("Failed to read CSV for entity '" + entity + "'", e);
        }
        return result;
    }

    private Map<String, String> invertFileMapping() {
        Map<String, String> inverted = new LinkedHashMap<>();
        properties.getCsv().getFiles().forEach((entity, file) ->
                inverted.put(baseName(file).toLowerCase(), entity));
        return inverted;
    }

    private static String baseName(String path) {
        String normalized = path.replace('\\', '/');
        int slash = normalized.lastIndexOf('/');
        return slash >= 0 ? normalized.substring(slash + 1) : normalized;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
        return out.toByteArray();
    }
}

