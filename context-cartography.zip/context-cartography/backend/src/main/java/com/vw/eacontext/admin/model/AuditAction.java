package com.vw.eacontext.admin.model;

/**
 * The catalogue of auditable actions recorded in the Contexa audit trail.
 *
 * <p>Kept as an enum (rather than free-text) so the audit log stays queryable
 * and the admin console can filter reliably.</p>
 */
public enum AuditAction {

    // --- Authentication ---------------------------------------------------
    LOGIN_SUCCESS,
    LOGIN_FAILURE,
    PASSWORD_CHANGED,

    // --- Identity administration -----------------------------------------
    USER_CREATED,
    USER_INVITED,
    USER_UPDATED,
    USER_ROLE_CHANGED,
    USER_ACTIVATED,
    USER_DEACTIVATED,
    USER_DELETED,
    USER_PASSWORD_RESET,
    ROLE_CREATED,
    ROLE_PERMISSIONS_UPDATED,
    ROLE_DELETED,

    // --- AI governance ----------------------------------------------------
    AI_SETTINGS_UPDATED,
    AI_CALL,
    AI_CALL_DENIED,
    AI_QUOTA_EXCEEDED,

    // --- EA data lifecycle ------------------------------------------------
    DATA_UPLOADED,
    DATA_UPLOAD_FAILED,
    EXPORT_GENERATED
}

