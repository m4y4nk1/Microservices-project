package com.vw.eacontext.exception;

/**
 * Raised when a user has exhausted their daily AI token allowance.
 *
 * <p>Mapped to HTTP 429 (Too Many Requests) by the global handler.</p>
 */
public class TokenQuotaExceededException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public TokenQuotaExceededException(String message) {
        super(message);
    }
}

