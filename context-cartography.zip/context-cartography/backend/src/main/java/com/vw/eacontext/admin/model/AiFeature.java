package com.vw.eacontext.admin.model;

import java.util.function.Predicate;

/**
 * The AI capabilities that can be governed independently.
 *
 * <p>Each constant links the runtime toggle in {@link AiSettings} to the
 * permission that guards the corresponding endpoint, and carries a default
 * token cost used for quota accounting when the provider does not report actual
 * usage.</p>
 */
public enum AiFeature {

    SUMMARY("landscape summary", AiSettings::isSummaryEnabled, 700),
    QUERY("natural-language query", AiSettings::isQueryEnabled, 500),
    ENRICHMENT("smart ingestion mapping", AiSettings::isEnrichmentEnabled, 400),
    RECOMMENDATION("remediation recommendations", AiSettings::isRecommendationEnabled, 600),
    AGENT("autonomous agent", AiSettings::isAgentEnabled, 1500);

    private final String displayName;
    private final Predicate<AiSettings> toggle;
    private final int defaultTokenCost;

    AiFeature(String displayName, Predicate<AiSettings> toggle, int defaultTokenCost) {
        this.displayName = displayName;
        this.toggle = toggle;
        this.defaultTokenCost = defaultTokenCost;
    }

    public String displayName() {
        return displayName;
    }

    /** @return the estimated tokens charged for one invocation. */
    public int defaultTokenCost() {
        return defaultTokenCost;
    }

    /** @return {@code true} if this capability is switched on in the settings. */
    public boolean isEnabledIn(AiSettings settings) {
        return toggle.test(settings);
    }
}

