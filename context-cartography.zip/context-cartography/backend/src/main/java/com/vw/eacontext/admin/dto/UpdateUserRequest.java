package com.vw.eacontext.admin.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * Payload for {@code PUT /api/admin/users/{id}}.
 *
 * @param name     new display name
 * @param roleName new role name
 * @param active   new activation state
 */
public record UpdateUserRequest(
        @NotBlank(message = "name is required")
        String name,

        @NotBlank(message = "roleName is required")
        String roleName,

        boolean active) {
}

