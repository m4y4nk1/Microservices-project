package com.vw.eacontext.insight;

import java.util.ArrayList;
import java.util.List;

import org.jgrapht.Graph;
import org.springframework.stereotype.Service;

import com.vw.eacontext.config.InsightProperties;
import com.vw.eacontext.graph.GraphBuilderService;
import com.vw.eacontext.graph.InterfaceEdge;
import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Interface;
import com.vw.eacontext.model.LifecycleStatus;
import com.vw.eacontext.validation.Severity;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Detects architecturally significant patterns over the canonical model and
 * its graph, producing a flat {@link List} of {@link Finding}s.
 *
 * <p>Detectors: ownership gaps, orphan interfaces (missing consumer), missing
 * process mappings, lifecycle risks (EOL/Deprecated) and dependency hotspots
 * (single points of failure by graph degree).</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class InsightService {

    private final GraphBuilderService graphBuilderService;
    private final InsightProperties properties;

    /**
     * Runs all detectors against the given model (building the graph internally).
     *
     * @param model the canonical model to analyze (must not be {@code null})
     * @return all findings, grouped by detector in declaration order
     */
    public List<Finding> analyze(CanonicalModel model) {
        return analyze(model, graphBuilderService.build(model));
    }

    /**
     * Runs all detectors reusing a pre-built graph (avoids rebuilding).
     *
     * @param model the canonical model to analyze
     * @param graph the pre-built application/interface graph
     * @return all findings, grouped by detector in declaration order
     */
    public List<Finding> analyze(CanonicalModel model, Graph<Application, InterfaceEdge> graph) {
        List<Finding> findings = new ArrayList<>();

        detectOwnershipGaps(model, findings);
        detectOrphanInterfaces(model, findings);
        detectMissingProcessMappings(model, findings);
        detectLifecycleRisks(model, findings);
        detectDependencyHotspots(graph, findings);

        log.info("Insight analysis produced {} finding(s)", findings.size());
        return findings;
    }

    private void detectOwnershipGaps(CanonicalModel model, List<Finding> findings) {
        for (Application app : model.applications()) {
            if (isBlank(app.owner())) {
                findings.add(new Finding(FindingType.OWNERSHIP_GAP, Severity.WARNING, app.id(),
                        "Application '" + app.id() + "' (" + app.name() + ") has no owner"));
            }
        }
    }

    private void detectOrphanInterfaces(CanonicalModel model, List<Finding> findings) {
        for (Interface iface : model.interfaces()) {
            if (isBlank(iface.consumerId())) {
                findings.add(new Finding(FindingType.ORPHAN_INTERFACE, Severity.WARNING, iface.id(),
                        "Interface '" + iface.id() + "' (" + iface.name() + ") has no consumer"));
            }
        }
    }

    private void detectMissingProcessMappings(CanonicalModel model, List<Finding> findings) {
        for (Application app : model.applications()) {
            if (isBlank(app.processId())) {
                findings.add(new Finding(FindingType.MISSING_PROCESS_MAPPING, Severity.WARNING, app.id(),
                        "Application '" + app.id() + "' (" + app.name() + ") is not mapped to a business process"));
            }
        }
    }

    private void detectLifecycleRisks(CanonicalModel model, List<Finding> findings) {
        for (Application app : model.applications()) {
            LifecycleStatus status = app.lifecycleStatus();
            if (status == LifecycleStatus.EOL || status == LifecycleStatus.DEPRECATED) {
                Severity severity = status == LifecycleStatus.EOL ? Severity.ERROR : Severity.WARNING;
                findings.add(new Finding(FindingType.LIFECYCLE_RISK, severity, app.id(),
                        "Application '" + app.id() + "' (" + app.name() + ") is " + status));
            }
        }
    }

    private void detectDependencyHotspots(Graph<Application, InterfaceEdge> graph, List<Finding> findings) {
        int threshold = properties.getHotspotDegreeThreshold();
        for (Application app : graph.vertexSet()) {
            int degree = graph.degreeOf(app);
            if (degree > threshold) {
                findings.add(new Finding(FindingType.DEPENDENCY_HOTSPOT, Severity.WARNING, app.id(),
                        "Application '" + app.id() + "' (" + app.name() + ") is a dependency hotspot with degree "
                                + degree + " (threshold " + threshold + ") â€” potential single point of failure"));
            }
        }
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}

