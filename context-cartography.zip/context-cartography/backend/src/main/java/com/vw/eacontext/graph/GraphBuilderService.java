package com.vw.eacontext.graph;

import java.util.HashMap;
import java.util.Map;

import org.jgrapht.Graph;
import org.jgrapht.graph.DirectedPseudograph;
import org.springframework.stereotype.Service;

import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Interface;

import lombok.extern.slf4j.Slf4j;

/**
 * Builds a JGraphT graph from a {@link CanonicalModel}.
 *
 * <p>Applications become vertices and interfaces become directed edges from the
 * provider to the consumer. A {@link DirectedPseudograph} is used so that
 * self-loops (an application integrating with itself) and multiple parallel
 * edges (several interfaces between the same two applications) are supported.
 * Each edge carries its interface metadata via {@link InterfaceEdge}.</p>
 */
@Slf4j
@Service
public class GraphBuilderService {

    /**
     * Converts the canonical model into a directed pseudograph of applications
     * connected by interfaces.
     *
     * <p>Interfaces whose provider or consumer cannot be resolved to a known
     * application are skipped (and logged); use the validation service to detect
     * such referential-integrity issues.</p>
     *
     * @param model the canonical model (must not be {@code null})
     * @return a directed pseudograph with applications as vertices and
     *         {@link InterfaceEdge}s as edges
     */
    public Graph<Application, InterfaceEdge> build(CanonicalModel model) {
        DirectedPseudograph<Application, InterfaceEdge> graph =
                new DirectedPseudograph<>(null, null, false);

        // Add application vertices, indexing by id for edge resolution.
        Map<String, Application> byId = new HashMap<>();
        for (Application app : model.applications()) {
            if (app.id() == null || app.id().isBlank()) {
                log.warn("Skipping application with blank id: {}", app);
                continue;
            }
            if (byId.putIfAbsent(app.id(), app) == null) {
                graph.addVertex(app);
            } else {
                log.warn("Skipping duplicate application id '{}'", app.id());
            }
        }

        // Add interface edges provider -> consumer.
        int added = 0;
        for (Interface iface : model.interfaces()) {
            Application provider = byId.get(iface.providerId());
            Application consumer = byId.get(iface.consumerId());
            if (provider == null || consumer == null) {
                log.warn("Skipping interface '{}': unresolved provider '{}' or consumer '{}'",
                        iface.id(), iface.providerId(), iface.consumerId());
                continue;
            }
            InterfaceEdge edge = new InterfaceEdge(
                    iface.id(), iface.type(), iface.name(), iface.dataObject());
            graph.addEdge(provider, consumer, edge);
            added++;
        }

        log.info("Built graph: {} application node(s), {} interface edge(s)",
                graph.vertexSet().size(), added);
        return graph;
    }
}

