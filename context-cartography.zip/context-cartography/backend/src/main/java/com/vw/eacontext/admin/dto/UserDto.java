package com.vw.eacontext.admin.dto;

import java.time.Instant;
import java.util.List;

import com.vw.eacontext.security.model.AppUser;

/**
 * Administrative read model for a user. Deliberately omits the password hash.
 *
 * @param id           surrogate key
 * @param email        login address
 * @param name         display name
 * @param role         role name
 * @param permissions  effective permission codes
 * @param active       whether the account may authenticate
 * @param mustChangePassword whether a password change is pending
 * @param createdAt    creation timestamp
 * @param lastLoginAt  last successful login, or {@code null}
 */
public record UserDto(
        Long id,
        String email,
        String name,
        String role,
        List<String> permissions,
        boolean active,
        boolean mustChangePassword,
        Instant createdAt,
        Instant lastLoginAt) {

    public static UserDto from(AppUser user) {
        return new UserDto(
                user.getId(),
                user.getEmail(),
                user.getName(),
                user.roleName(),
                List.copyOf(user.permissionCodes()),
                user.isActive(),
                user.isMustChangePassword(),
                user.getCreatedAt(),
                user.getLastLoginAt());
    }
}

