package com.vw.eacontext.model;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;

/**
 * Canonical representation of a business process.
 *
 * @param id       unique business process identifier (required)
 * @param name     human-readable process name (required)
 * @param domainId id of the {@link Domain} that owns this process
 */
@Builder
public record BusinessProcess(
        @NotBlank String id,
        @NotBlank String name,
        String domainId
) {
}

