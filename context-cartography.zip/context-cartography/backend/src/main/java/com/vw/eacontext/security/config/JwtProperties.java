package com.vw.eacontext.security.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * JWT signing and lifetime configuration, bound from {@code contexa.jwt.*}.
 *
 * <p>The secret must be supplied from the environment (or Azure Key Vault) in
 * every non-local environment and must be at least 32 characters so that
 * HMAC-SHA256 key derivation succeeds.</p>
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "contexa.jwt")
public class JwtProperties {

    /** HMAC signing secret; minimum 32 characters (256 bits). */
    private String secret = "contexa-dev-secret-change-me-in-production-0123456789";

    /** Access-token lifetime in milliseconds (default 24h). */
    private long expiryMs = 86_400_000L;

    /** {@code iss} claim value. */
    private String issuer = "contexa";
}

