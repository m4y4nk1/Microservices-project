package com.vw.eacontext.model;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;

/**
 * Canonical representation of an integration between two applications.
 *
 * @param id         unique interface identifier (required)
 * @param name       human-readable interface name (required)
 * @param providerId id of the providing {@link Application}
 * @param consumerId id of the consuming {@link Application}
 * @param type       technical {@link InterfaceType type} of the integration
 * @param dataObject the {@link InformationObject} exchanged, by name/id
 */
@Builder
public record Interface(
        @NotBlank String id,
        @NotBlank String name,
        String providerId,
        String consumerId,
        InterfaceType type,
        String dataObject
) {
}

