package com.vw.eacontext.admin.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Tenant-wide AI governance settings, held as a single row ({@code id = 1}).
 *
 * <p>These are runtime switches owned by a {@code SUPER_ADMIN}: they gate AI
 * features and cap spend without a redeploy, and they layer on top of — never
 * replace — the per-user {@code AI_*} permissions.</p>
 */
@Entity
@Table(name = "ai_settings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class AiSettings {

    /** The singleton row identifier. */
    public static final Long SINGLETON_ID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    /** Master kill-switch for every AI feature. */
    @Builder.Default
    @Column(name = "ai_enabled", nullable = false)
    private boolean aiEnabled = true;

    /** Deployment/model name used for AI calls, e.g. {@code gpt-4o-mini}. */
    @Builder.Default
    @Column(name = "model", nullable = false, length = 100)
    private String model = "gpt-4o-mini";

    /** Per-user daily token allowance; {@code 0} disables the quota. */
    @Builder.Default
    @Column(name = "daily_token_budget_per_user", nullable = false)
    private int dailyTokenBudgetPerUser = 5_000;

    /** Feature toggle for the natural-language landscape summary. */
    @Builder.Default
    @Column(name = "summary_enabled", nullable = false)
    private boolean summaryEnabled = true;

    /** Feature toggle for natural-language querying. */
    @Builder.Default
    @Column(name = "query_enabled", nullable = false)
    private boolean queryEnabled = true;

    /** Feature toggle for AI-assisted ingestion mapping/cleaning. */
    @Builder.Default
    @Column(name = "enrichment_enabled", nullable = false)
    private boolean enrichmentEnabled = true;

    /** Feature toggle for AI remediation recommendations. */
    @Builder.Default
    @Column(name = "recommendation_enabled", nullable = false)
    private boolean recommendationEnabled = true;

    /** Feature toggle for autonomous agent workflows (off by default). */
    @Builder.Default
    @Column(name = "agent_enabled", nullable = false)
    private boolean agentEnabled = false;

    /** @return the default settings row used when none exists yet. */
    public static AiSettings defaults() {
        return AiSettings.builder().id(SINGLETON_ID).build();
    }
}

