package com.vw.eacontext.insight;

/**
 * The category of an insight {@link Finding}.
 */
public enum FindingType {
    /** An application with no declared owner. */
    OWNERSHIP_GAP,
    /** An interface with no consumer (a dangling integration). */
    ORPHAN_INTERFACE,
    /** An application not mapped to any business process. */
    MISSING_PROCESS_MAPPING,
    /** An application on a risky lifecycle status (EOL / Deprecated). */
    LIFECYCLE_RISK,
    /** A highly-connected application (potential single point of failure). */
    DEPENDENCY_HOTSPOT
}

