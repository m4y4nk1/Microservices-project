package com.vw.eacontext.security.dto;

import java.util.List;

/**
 * Successful authentication result.
 *
 * <p>The permission list is returned alongside the token purely so the frontend
 * can hide controls the user cannot use; it is never trusted for enforcement.</p>
 *
 * @param token              the signed access token
 * @param tokenType          always {@code Bearer}
 * @param expiresInSeconds   remaining lifetime of the token
 * @param email              the authenticated user's email
 * @param name               display name
 * @param role               role name, e.g. {@code ARCHITECT}
 * @param permissions        effective permission codes
 * @param mustChangePassword {@code true} when the account still uses its seeded/invited password
 */
public record LoginResponse(
        String token,
        String tokenType,
        long expiresInSeconds,
        String email,
        String name,
        String role,
        List<String> permissions,
        boolean mustChangePassword) {

    public LoginResponse {
        permissions = permissions == null ? List.of() : List.copyOf(permissions);
    }
}

