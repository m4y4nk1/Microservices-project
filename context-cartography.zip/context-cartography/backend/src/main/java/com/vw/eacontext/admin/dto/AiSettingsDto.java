package com.vw.eacontext.admin.dto;

import com.vw.eacontext.admin.model.AiSettings;

/**
 * Read model for the AI governance settings.
 *
 * @param aiEnabled               master switch
 * @param model                   deployment/model name
 * @param dailyTokenBudgetPerUser per-user daily token cap ({@code 0} = unlimited)
 * @param summaryEnabled          toggle for the landscape summary
 * @param queryEnabled            toggle for natural-language query
 * @param enrichmentEnabled       toggle for AI-assisted ingestion
 * @param recommendationEnabled   toggle for AI recommendations
 * @param agentEnabled            toggle for autonomous agent workflows
 */
public record AiSettingsDto(
        boolean aiEnabled,
        String model,
        int dailyTokenBudgetPerUser,
        boolean summaryEnabled,
        boolean queryEnabled,
        boolean enrichmentEnabled,
        boolean recommendationEnabled,
        boolean agentEnabled) {

    public static AiSettingsDto from(AiSettings s) {
        return new AiSettingsDto(
                s.isAiEnabled(),
                s.getModel(),
                s.getDailyTokenBudgetPerUser(),
                s.isSummaryEnabled(),
                s.isQueryEnabled(),
                s.isEnrichmentEnabled(),
                s.isRecommendationEnabled(),
                s.isAgentEnabled());
    }
}

