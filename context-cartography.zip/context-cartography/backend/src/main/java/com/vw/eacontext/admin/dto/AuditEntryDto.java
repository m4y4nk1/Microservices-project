package com.vw.eacontext.admin.dto;

import java.time.Instant;

import com.vw.eacontext.admin.model.AuditEntry;

/**
 * Read model for one audit-trail row.
 *
 * @param id         surrogate key
 * @param actor      who performed the action
 * @param action     what was done
 * @param detail     contextual information
 * @param tokensUsed tokens consumed, for AI actions
 * @param success    whether the operation succeeded
 * @param createdAt  when it happened
 */
public record AuditEntryDto(
        Long id,
        String actor,
        String action,
        String detail,
        Integer tokensUsed,
        boolean success,
        Instant createdAt) {

    public static AuditEntryDto from(AuditEntry entry) {
        return new AuditEntryDto(
                entry.getId(),
                entry.getActor(),
                entry.getAction() == null ? null : entry.getAction().name(),
                entry.getDetail(),
                entry.getTokensUsed(),
                entry.isSuccess(),
                entry.getCreatedAt());
    }
}

