package com.vw.eacontext.security.service;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;

import javax.crypto.SecretKey;

import org.springframework.stereotype.Service;

import com.vw.eacontext.security.config.JwtProperties;
import com.vw.eacontext.security.model.AppUser;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;

/**
 * Issues and verifies the stateless access tokens used by the API.
 *
 * <p>The token carries the user's effective permission codes in a {@code perms}
 * claim so that authorization needs no database round-trip per request. Because
 * permissions are embedded, a role change only takes full effect on the user's
 * next login (or token refresh) — an intentional trade-off for statelessness.</p>
 */
@Slf4j
@Service
public class JwtService {

    /** Claim holding the flat list of granted authority strings. */
    public static final String CLAIM_PERMISSIONS = "perms";

    /** Claim holding the user's role name (informational / UI only). */
    public static final String CLAIM_ROLE = "role";

    /** Claim holding the display name. */
    public static final String CLAIM_NAME = "name";

    private final SecretKey key;
    private final JwtProperties properties;

    public JwtService(JwtProperties properties) {
        this.properties = properties;
        String secret = properties.getSecret();
        if (secret == null || secret.getBytes(StandardCharsets.UTF_8).length < 32) {
            throw new IllegalStateException(
                    "contexa.jwt.secret must be at least 32 characters; set CONTEXA_JWT_SECRET");
        }
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Issues a signed access token for the given user.
     *
     * @param user the authenticated user
     * @return a compact JWS string
     */
    public String issue(AppUser user) {
        Date now = new Date();
        Date expiry = new Date(now.getTime() + properties.getExpiryMs());
        return Jwts.builder()
                .issuer(properties.getIssuer())
                .subject(user.getEmail())
                .claim(CLAIM_NAME, user.getName())
                .claim(CLAIM_ROLE, user.roleName())
                .claim(CLAIM_PERMISSIONS, List.copyOf(user.permissionCodes()))
                .issuedAt(now)
                .expiration(expiry)
                .signWith(key)
                .compact();
    }

    /**
     * Verifies a token's signature and expiry.
     *
     * @param token the compact JWS string
     * @return the parsed claims
     * @throws JwtException if the token is malformed, expired or badly signed
     */
    public Jws<Claims> parse(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .requireIssuer(properties.getIssuer())
                .build()
                .parseSignedClaims(token);
    }

    /** @return the permission codes carried by the token, never {@code null}. */
    @SuppressWarnings("unchecked")
    public List<String> permissionsOf(Claims claims) {
        Object raw = claims.get(CLAIM_PERMISSIONS);
        if (raw instanceof List<?> list) {
            return list.stream().map(String::valueOf).toList();
        }
        return List.of();
    }

    /** @return the configured token lifetime in seconds, for the login response. */
    public long expiresInSeconds() {
        return properties.getExpiryMs() / 1000L;
    }
}

