package com.vw.eacontext.security.service;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vw.eacontext.security.model.AppUser;
import com.vw.eacontext.security.repository.UserRepository;

import lombok.RequiredArgsConstructor;

/**
 * Bridges {@link AppUser} into Spring Security, translating the user's role
 * permissions directly into {@link SimpleGrantedAuthority granted authorities}.
 *
 * <p>Authorities are the raw permission codes (no {@code ROLE_} prefix), which
 * is why every rule in the codebase reads
 * {@code hasAuthority('SOME_PERMISSION')} rather than {@code hasRole(...)}.</p>
 */
@Service
@RequiredArgsConstructor
public class AppUserDetailsService implements UserDetailsService {

    private final UserRepository users;

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String email) {
        AppUser user = users.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new UsernameNotFoundException("No user with email " + email));

        Set<SimpleGrantedAuthority> authorities = user.permissionCodes().stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toSet());

        return User.builder()
                .username(user.getEmail())
                .password(user.getPasswordHash())
                .disabled(!user.isActive())
                .authorities(authorities)
                .build();
    }
}

