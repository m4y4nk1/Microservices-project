package com.vw.eacontext.admin.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vw.eacontext.admin.dto.PermissionDto;
import com.vw.eacontext.admin.dto.RoleDto;
import com.vw.eacontext.admin.dto.UpdateRolePermissionsRequest;
import com.vw.eacontext.admin.model.AuditAction;
import com.vw.eacontext.exception.EaNotFoundException;
import com.vw.eacontext.security.model.Permission;
import com.vw.eacontext.security.model.PermissionCode;
import com.vw.eacontext.security.model.Role;
import com.vw.eacontext.security.model.RoleName;
import com.vw.eacontext.security.repository.PermissionRepository;
import com.vw.eacontext.security.repository.RoleRepository;
import com.vw.eacontext.security.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Role and permission administration.
 *
 * <p>Roles may be created and re-permissioned freely, with one invariant: the
 * {@code SUPER_ADMIN} role must always retain {@link PermissionCode#ROLE_MANAGE}
 * and {@link PermissionCode#USER_MANAGE}, otherwise an administrator could lock
 * the entire platform out of its own console.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AdminRoleService {

    private final RoleRepository roles;
    private final PermissionRepository permissions;
    private final UserRepository users;
    private final AuditService audit;

    /** @return all roles with their permissions and user counts. */
    @Transactional(readOnly = true)
    public List<RoleDto> list() {
        return roles.findAllWithPermissions().stream()
                .map(role -> RoleDto.from(role, users.countByRoleName(role.getName())))
                .toList();
    }

    /** @return the full permission catalogue, grouped-friendly and sorted. */
    @Transactional(readOnly = true)
    public List<PermissionDto> catalogue() {
        return permissions.findAllByOrderByCategoryAscCodeAsc().stream()
                .map(PermissionDto::from)
                .toList();
    }

    /** @return one role by name. */
    @Transactional(readOnly = true)
    public RoleDto get(String name) {
        Role role = require(name);
        return RoleDto.from(role, users.countByRoleName(role.getName()));
    }

    /**
     * Replaces a role's permission set with the supplied list.
     *
     * @param name    the role to modify
     * @param request the authoritative list of permission codes
     * @return the updated role
     */
    @Transactional
    public RoleDto updatePermissions(String name, UpdateRolePermissionsRequest request) {
        Role role = require(name);

        List<String> requested = request.permissions().stream()
                .map(String::trim)
                .map(String::toUpperCase)
                .distinct()
                .toList();

        List<String> unknown = requested.stream()
                .filter(code -> !PermissionCode.isValid(code))
                .toList();
        if (!unknown.isEmpty()) {
            throw new IllegalArgumentException("Unknown permission codes: " + unknown);
        }

        if (RoleName.SUPER_ADMIN.name().equals(role.getName())
                && !(requested.contains(PermissionCode.ROLE_MANAGE.name())
                        && requested.contains(PermissionCode.USER_MANAGE.name()))) {
            throw new IllegalArgumentException(
                    "SUPER_ADMIN must retain USER_MANAGE and ROLE_MANAGE");
        }

        Set<Permission> resolved = new HashSet<>(permissions.findByCodeIn(requested));
        role.setPermissions(resolved);
        roles.save(role);

        audit.log(AuditAction.ROLE_PERMISSIONS_UPDATED, role.getName() + " = " + requested);
        log.info("Role '{}' now grants {} permission(s)", role.getName(), resolved.size());

        return RoleDto.from(role, users.countByRoleName(role.getName()));
    }

    /**
     * Creates a custom (non-system) role.
     *
     * @param name        the new role's name
     * @param description its purpose
     * @return the created role
     */
    @Transactional
    public RoleDto create(String name, String description) {
        String normalized = name.trim().toUpperCase();
        if (roles.existsByName(normalized)) {
            throw new IllegalArgumentException("A role named '" + normalized + "' already exists");
        }

        Role role = roles.save(Role.builder()
                .name(normalized)
                .description(description)
                .systemRole(false)
                .permissions(new HashSet<>())
                .build());

        audit.log(AuditAction.ROLE_CREATED, normalized);
        return RoleDto.from(role, 0L);
    }

    /** Deletes a custom role that no user currently holds. */
    @Transactional
    public void delete(String name) {
        Role role = require(name);
        if (role.isSystemRole()) {
            throw new IllegalArgumentException(
                    "System role '" + role.getName() + "' cannot be deleted");
        }
        long holders = users.countByRoleName(role.getName());
        if (holders > 0) {
            throw new IllegalArgumentException(
                    "Role '" + role.getName() + "' is still assigned to " + holders + " user(s)");
        }

        roles.delete(role);
        audit.log(AuditAction.ROLE_DELETED, role.getName());
    }

    private Role require(String name) {
        return roles.findByName(name.trim().toUpperCase())
                .orElseThrow(() -> new EaNotFoundException("No role named '" + name + "'"));
    }
}

