package com.vw.eacontext.model;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;

/**
 * Canonical representation of a business/architecture domain.
 *
 * @param id   unique domain identifier (required)
 * @param name human-readable domain name (required)
 */
@Builder
public record Domain(
        @NotBlank String id,
        @NotBlank String name
) {
}

