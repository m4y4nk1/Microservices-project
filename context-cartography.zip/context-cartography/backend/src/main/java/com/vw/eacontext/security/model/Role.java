package com.vw.eacontext.security.model;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * A named bundle of {@link Permission}s.
 *
 * <p>Roles carry no behaviour of their own: authorization decisions are always
 * made against the permissions a role contains, so an administrator can reshape
 * a role without any code change.</p>
 */
@Entity
@Table(name = "roles")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = "permissions")
@EqualsAndHashCode(of = "name")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Role name, e.g. {@code ARCHITECT}. Matches {@link RoleName} for seeded roles. */
    @Column(name = "name", nullable = false, unique = true, length = 64)
    private String name;

    @Column(name = "description", length = 255)
    private String description;

    /** Seeded roles cannot be deleted, only re-permissioned. */
    @Builder.Default
    @Column(name = "system_role", nullable = false)
    private boolean systemRole = false;

    @Builder.Default
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "role_permissions",
            joinColumns = @JoinColumn(name = "role_id"),
            inverseJoinColumns = @JoinColumn(name = "permission_id"))
    private Set<Permission> permissions = new HashSet<>();

    /** @return this role's permission codes, sorted for stable API output. */
    public Set<String> permissionCodes() {
        return permissions.stream()
                .map(Permission::getCode)
                .collect(Collectors.toCollection(TreeSet::new));
    }

    /** @return {@code true} if this role grants the given permission. */
    public boolean grants(PermissionCode code) {
        return permissions.stream().anyMatch(p -> p.getCode().equals(code.name()));
    }
}

