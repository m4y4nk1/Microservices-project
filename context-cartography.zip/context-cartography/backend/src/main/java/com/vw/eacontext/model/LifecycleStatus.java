package com.vw.eacontext.model;

/**
 * Lifecycle state of an {@link Application} within the enterprise architecture.
 */
public enum LifecycleStatus {
    /** Actively used and supported. */
    ACTIVE,
    /** Still running but slated for replacement; avoid new usage. */
    DEPRECATED,
    /** End of life â€” no longer supported. */
    EOL,
    /** Not yet built; planned for the future. */
    PLANNED
}

