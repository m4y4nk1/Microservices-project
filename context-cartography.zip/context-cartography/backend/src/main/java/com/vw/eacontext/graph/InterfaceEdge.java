package com.vw.eacontext.graph;

import org.jgrapht.graph.DefaultEdge;

import com.vw.eacontext.model.InterfaceType;

import lombok.Getter;

/**
 * A graph edge representing an {@link com.vw.eacontext.model.Interface} between
 * two applications, carrying the interface metadata.
 *
 * <p>Extends {@link DefaultEdge} so the source/target applications remain
 * accessible via the graph. Multiple edges may connect the same pair of
 * applications (hence a pseudograph), so identity is per-instance.</p>
 */
@Getter
public class InterfaceEdge extends DefaultEdge {

    /** The originating interface id. */
    private final String interfaceId;

    /** The technical type of the interface (API, FILE, EVENT, DB). */
    private final InterfaceType type;

    /** The interface name (for display/debugging). */
    private final String name;

    /** The information/data object exchanged. */
    private final String dataObject;

    public InterfaceEdge(String interfaceId, InterfaceType type, String name, String dataObject) {
        this.interfaceId = interfaceId;
        this.type = type;
        this.name = name;
        this.dataObject = dataObject;
    }

    @Override
    public String toString() {
        return "InterfaceEdge{id=" + interfaceId + ", type=" + type
                + ", " + getSource() + " -> " + getTarget() + "}";
    }
}

