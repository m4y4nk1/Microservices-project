package com.vw.eacontext.admin.service;

import java.time.LocalDate;
import java.util.function.Supplier;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vw.eacontext.admin.model.AiFeature;
import com.vw.eacontext.admin.model.AiSettings;
import com.vw.eacontext.admin.model.AiUsage;
import com.vw.eacontext.admin.repository.AiUsageRepository;
import com.vw.eacontext.exception.AiFeatureDisabledException;
import com.vw.eacontext.exception.TokenQuotaExceededException;
import com.vw.eacontext.security.service.CurrentUserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * The single choke point through which every AI invocation must pass.
 *
 * <p>Three independent gates are applied, in order:</p>
 * <ol>
 *   <li>the caller must hold the feature's {@code AI_*} permission (already
 *       enforced by {@code @PreAuthorize} on the controller);</li>
 *   <li>the feature must be switched on in {@link AiSettings};</li>
 *   <li>the caller must have daily token budget remaining.</li>
 * </ol>
 *
 * <p>Every outcome — success, denial or quota breach — is written to the audit
 * trail, so AI spend is always attributable.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AiGovernanceService {

    private final AiSettingsService settingsService;
    private final AiUsageRepository usageRepository;
    private final AuditService audit;
    private final CurrentUserService currentUser;

    /**
     * Runs an AI operation under governance.
     *
     * @param feature        the AI capability being invoked
     * @param estimatedCost  tokens to charge against the caller's daily budget
     * @param operation      the actual AI call
     * @param <T>            the operation's result type
     * @return the operation's result
     * @throws AiFeatureDisabledException if an administrator has disabled the feature
     * @throws TokenQuotaExceededException if the caller is out of daily budget
     */
    public <T> T execute(AiFeature feature, int estimatedCost, Supplier<T> operation) {
        String actor = currentUser.actor();
        AiSettings settings = settingsService.get();

        if (!settings.isAiEnabled()) {
            audit.logFailure(actor, com.vw.eacontext.admin.model.AuditAction.AI_CALL_DENIED,
                    "feature=" + feature + ", reason=ai-disabled");
            throw new AiFeatureDisabledException(
                    "AI features are currently disabled by an administrator.");
        }
        if (!feature.isEnabledIn(settings)) {
            audit.logFailure(actor, com.vw.eacontext.admin.model.AuditAction.AI_CALL_DENIED,
                    "feature=" + feature + ", reason=feature-disabled");
            throw new AiFeatureDisabledException(
                    "The AI capability '" + feature.displayName() + "' is currently disabled.");
        }

        reserveBudget(actor, feature, estimatedCost, settings.getDailyTokenBudgetPerUser());

        try {
            T result = operation.get();
            audit.logAiCall(actor, feature.name(), estimatedCost, true);
            return result;
        } catch (RuntimeException e) {
            audit.logAiCall(actor, feature.name(), estimatedCost, false);
            throw e;
        }
    }

    /**
     * Charges the caller's daily allowance, rejecting the call if it would
     * exceed the configured budget.
     */
    @Transactional
    public void reserveBudget(String actor, AiFeature feature, int cost, int dailyBudget) {
        if (dailyBudget <= 0) {
            return; // 0 means "unlimited"
        }
        if (!currentUser.isAuthenticated()) {
            return; // unsecured mode / system tasks are not metered
        }

        LocalDate today = LocalDate.now();
        AiUsage usage = usageRepository.findByUserEmailAndUsageDate(actor, today)
                .orElseGet(() -> AiUsage.builder().userEmail(actor).usageDate(today).build());

        if (usage.getTokensUsed() + cost > dailyBudget) {
            audit.logFailure(actor, com.vw.eacontext.admin.model.AuditAction.AI_QUOTA_EXCEEDED,
                    "feature=" + feature + ", used=" + usage.getTokensUsed()
                            + ", requested=" + cost + ", budget=" + dailyBudget);
            throw new TokenQuotaExceededException(
                    "Daily AI token budget exhausted (" + usage.getTokensUsed() + "/" + dailyBudget
                            + "). Try again tomorrow or ask an administrator to raise your budget.");
        }

        usage.record(cost);
        usageRepository.save(usage);
        log.debug("AI budget charged: actor={}, feature={}, cost={}, total={}/{}",
                actor, feature, cost, usage.getTokensUsed(), dailyBudget);
    }

    /** @return tokens the given user has consumed today. */
    @Transactional(readOnly = true)
    public int tokensUsedToday(String email) {
        return usageRepository.findByUserEmailAndUsageDate(email, LocalDate.now())
                .map(AiUsage::getTokensUsed)
                .orElse(0);
    }
}

