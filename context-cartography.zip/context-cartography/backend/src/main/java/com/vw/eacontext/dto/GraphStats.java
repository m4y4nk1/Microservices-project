package com.vw.eacontext.dto;

import lombok.Builder;

/**
 * High-level statistics about a parsed EA landscape / its graph, used for
 * summaries and dashboards.
 *
 * @param applicationCount         number of applications
 * @param interfaceCount           number of (valid) interfaces / edges
 * @param domainCount              number of domains
 * @param businessProcessCount     number of business processes
 * @param informationObjectCount   number of information objects
 * @param mostConnectedApplicationId id of the highest-degree application (may be {@code null})
 * @param maxDegree                degree of the most connected application
 */
@Builder
public record GraphStats(
        int applicationCount,
        int interfaceCount,
        int domainCount,
        int businessProcessCount,
        int informationObjectCount,
        String mostConnectedApplicationId,
        int maxDegree) {
}

