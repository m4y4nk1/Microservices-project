package com.vw.eacontext.model;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;

/**
 * Canonical representation of an application (system) in the EA landscape.
 *
 * @param id              unique application identifier (required)
 * @param name            human-readable application name (required)
 * @param owner           accountable owner (person/team)
 * @param domain          business/architecture domain this application belongs to
 * @param lifecycleStatus current {@link LifecycleStatus lifecycle state}
 * @param techStack       primary technology stack
 * @param processId       identifier of the {@link BusinessProcess} it supports
 */
@Builder
public record Application(
        @NotBlank String id,
        @NotBlank String name,
        String owner,
        String domain,
        LifecycleStatus lifecycleStatus,
        String techStack,
        String processId
) {
}

