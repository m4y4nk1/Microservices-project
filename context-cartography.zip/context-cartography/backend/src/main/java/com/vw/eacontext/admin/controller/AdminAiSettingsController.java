package com.vw.eacontext.admin.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vw.eacontext.admin.dto.AiSettingsDto;
import com.vw.eacontext.admin.dto.AiSettingsRequest;
import com.vw.eacontext.admin.service.AiSettingsService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

/**
 * AI governance configuration: model selection, per-user token budget and the
 * individual AI feature toggles.
 *
 * <p>Reading is allowed to anyone who can administer users (so the console can
 * display current policy); changing requires
 * {@link com.vw.eacontext.security.model.PermissionCode#AI_CONFIG}, which by
 * default only {@code SUPER_ADMIN} holds.</p>
 */
@RestController
@RequestMapping(value = "/api/admin/ai-settings", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
public class AdminAiSettingsController {

    private final AiSettingsService aiSettingsService;

    /** Returns the current AI governance settings. */
    @PreAuthorize("hasAnyAuthority('AI_CONFIG','USER_MANAGE')")
    @GetMapping
    public ResponseEntity<AiSettingsDto> get() {
        return ResponseEntity.ok(AiSettingsDto.from(aiSettingsService.get()));
    }

    /** Updates the AI governance settings. */
    @PreAuthorize("hasAuthority('AI_CONFIG')")
    @PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AiSettingsDto> update(@Valid @RequestBody AiSettingsRequest request) {
        return ResponseEntity.ok(AiSettingsDto.from(aiSettingsService.update(request)));
    }
}

