package com.vw.eacontext.admin.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vw.eacontext.admin.dto.AuditEntryDto;
import com.vw.eacontext.admin.model.AuditAction;
import com.vw.eacontext.admin.model.AuditEntry;
import com.vw.eacontext.admin.service.AuditService;

import lombok.RequiredArgsConstructor;

/**
 * Read-only access to the audit trail, gated on
 * {@link com.vw.eacontext.security.model.PermissionCode#AUDIT_VIEW}.
 */
@RestController
@RequestMapping(value = "/api/admin/audit", produces = MediaType.APPLICATION_JSON_VALUE)
@PreAuthorize("hasAuthority('AUDIT_VIEW')")
@RequiredArgsConstructor
public class AdminAuditController {

    private final AuditService auditService;

    /**
     * Returns audit entries, newest first, optionally filtered by actor or
     * action.
     *
     * @param actor  restrict to a single user's activity
     * @param action restrict to specific action types (repeatable)
     * @param page   zero-based page index
     * @param size   page size (max 500)
     */
    @GetMapping
    public ResponseEntity<List<AuditEntryDto>> list(
            @RequestParam(required = false) String actor,
            @RequestParam(required = false) List<AuditAction> action,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "100") int size) {

        Page<AuditEntry> result;
        if (actor != null && !actor.isBlank()) {
            result = auditService.byActor(actor, page, size);
        } else if (action != null && !action.isEmpty()) {
            result = auditService.byActions(action, page, size);
        } else {
            result = auditService.recent(page, size);
        }

        return ResponseEntity.ok(result.map(AuditEntryDto::from).getContent());
    }

    /** Convenience view over just the AI-related audit records. */
    @GetMapping("/ai")
    public ResponseEntity<List<AuditEntryDto>> aiActivity(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "100") int size) {

        List<AuditAction> aiActions = List.of(
                AuditAction.AI_CALL,
                AuditAction.AI_CALL_DENIED,
                AuditAction.AI_QUOTA_EXCEEDED,
                AuditAction.AI_SETTINGS_UPDATED);

        return ResponseEntity.ok(
                auditService.byActions(aiActions, page, size).map(AuditEntryDto::from).getContent());
    }
}

