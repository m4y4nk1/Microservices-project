package com.vw.eacontext.admin.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

/**
 * Administrator payload for {@code PUT /api/admin/ai-settings}.
 *
 * @param aiEnabled                master switch for all AI features
 * @param model                    deployment/model name, e.g. {@code gpt-4o-mini}
 * @param dailyTokenBudgetPerUser  per-user daily token cap ({@code 0} = unlimited)
 * @param summaryEnabled           toggle for the landscape summary
 * @param queryEnabled             toggle for natural-language query
 * @param enrichmentEnabled        toggle for AI-assisted ingestion
 * @param recommendationEnabled    toggle for AI recommendations
 * @param agentEnabled             toggle for autonomous agent workflows
 */
public record AiSettingsRequest(
        boolean aiEnabled,

        @NotBlank(message = "model is required")
        String model,

        @Min(value = 0, message = "dailyTokenBudgetPerUser must not be negative")
        int dailyTokenBudgetPerUser,

        boolean summaryEnabled,
        boolean queryEnabled,
        boolean enrichmentEnabled,
        boolean recommendationEnabled,
        boolean agentEnabled) {
}

