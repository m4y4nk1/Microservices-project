package com.vw.eacontext.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vw.eacontext.admin.model.AiSettings;

/** Repository for the singleton {@link AiSettings} row. */
public interface AiSettingsRepository extends JpaRepository<AiSettings, Long> {
}
