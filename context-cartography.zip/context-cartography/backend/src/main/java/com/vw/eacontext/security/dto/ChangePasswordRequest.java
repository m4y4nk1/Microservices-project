package com.vw.eacontext.security.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Payload for {@code POST /api/auth/change-password}.
 *
 * @param currentPassword the existing password, re-verified before the change
 * @param newPassword     the replacement password
 */
public record ChangePasswordRequest(
        @NotBlank(message = "currentPassword is required")
        String currentPassword,

        @NotBlank(message = "newPassword is required")
        @Size(min = 10, message = "newPassword must be at least 10 characters")
        String newPassword) {
}

