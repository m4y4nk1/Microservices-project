package com.vw.eacontext.admin.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Payload for {@code POST /api/admin/users}.
 *
 * <p>{@code password} is optional: when omitted the account is created as an
 * invitation with a generated temporary password that the administrator hands
 * over out-of-band, and the user must change it on first login.</p>
 *
 * @param name     display name
 * @param email    login address (must be unique)
 * @param password optional initial password
 * @param roleName the role to assign, e.g. {@code ANALYST}
 */
public record CreateUserRequest(
        @NotBlank(message = "name is required")
        String name,

        @NotBlank(message = "email is required")
        @Email(message = "email must be a valid address")
        String email,

        @Size(min = 10, message = "password must be at least 10 characters")
        String password,

        @NotBlank(message = "roleName is required")
        String roleName) {
}
