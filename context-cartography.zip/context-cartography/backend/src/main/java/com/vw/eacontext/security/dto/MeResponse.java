package com.vw.eacontext.security.dto;

import java.util.List;

/**
 * The identity of the caller, returned by {@code GET /api/auth/me}.
 *
 * @param email       authenticated principal
 * @param name        display name
 * @param role        role name
 * @param permissions effective permission codes
 */
public record MeResponse(
        String email,
        String name,
        String role,
        List<String> permissions) {

    public MeResponse {
        permissions = permissions == null ? List.of() : List.copyOf(permissions);
    }
}

