/**
 * JPA entities and enums backing Contexa's role-based access control:
 * {@link com.vw.eacontext.security.model.AppUser},
 * {@link com.vw.eacontext.security.model.Role},
 * {@link com.vw.eacontext.security.model.Permission}, plus the
 * {@link com.vw.eacontext.security.model.PermissionCode} catalogue and the
 * {@link com.vw.eacontext.security.model.RoleName} default matrix.
 */
package com.vw.eacontext.security.model;

