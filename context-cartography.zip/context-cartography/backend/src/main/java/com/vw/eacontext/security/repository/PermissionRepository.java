package com.vw.eacontext.security.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vw.eacontext.security.model.Permission;

/** Repository for the seeded {@link Permission} catalogue. */
public interface PermissionRepository extends JpaRepository<Permission, Long> {

    Optional<Permission> findByCode(String code);

    List<Permission> findAllByOrderByCategoryAscCodeAsc();

    List<Permission> findByCodeIn(List<String> codes);
}

