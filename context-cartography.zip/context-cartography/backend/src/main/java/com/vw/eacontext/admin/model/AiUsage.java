package com.vw.eacontext.admin.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Rolling per-user, per-day token counter backing the AI spend quota.
 *
 * <p>One row per {@code (userEmail, usageDate)} pair; the quota check reads and
 * increments this row inside the same transaction as the AI call.</p>
 */
@Entity
@Table(name = "ai_usage", uniqueConstraints = @UniqueConstraint(
        name = "uk_ai_usage_user_day", columnNames = {"user_email", "usage_date"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class AiUsage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_email", nullable = false, length = 190)
    private String userEmail;

    @Column(name = "usage_date", nullable = false)
    private LocalDate usageDate;

    /** Tokens consumed by this user on this day. */
    @Builder.Default
    @Column(name = "tokens_used", nullable = false)
    private int tokensUsed = 0;

    /** Number of AI invocations made on this day. */
    @Builder.Default
    @Column(name = "call_count", nullable = false)
    private int callCount = 0;

    /** Records one AI call of the given size. */
    public void record(int tokens) {
        this.tokensUsed += Math.max(tokens, 0);
        this.callCount += 1;
    }
}

