package com.vw.eacontext.model;

/**
 * Technical nature of an {@link Interface} between two applications.
 */
public enum InterfaceType {
    /** Synchronous programmatic interface (e.g. REST/SOAP/gRPC). */
    API,
    /** File-based exchange (e.g. batch drop, SFTP). */
    FILE,
    /** Asynchronous event/message exchange. */
    EVENT,
    /** Direct database integration. */
    DB
}

