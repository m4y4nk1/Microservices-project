package com.vw.eacontext.api;

import java.util.List;

import org.jgrapht.Graph;
import org.springframework.stereotype.Component;

import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.exception.ModelNotLoadedException;
import com.vw.eacontext.graph.GraphBuilderService;
import com.vw.eacontext.graph.InterfaceEdge;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.InsightService;
import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.CanonicalModel;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * In-memory (no database) store for the current session's uploaded
 * {@link CanonicalModel} together with its derived artifacts â€” the JGraphT
 * {@link Graph}, insight {@link Finding}s and {@link GraphStats}.
 *
 * <p>Derived artifacts are computed once at {@link #load(CanonicalModel) load}
 * time and reused by subsequent read calls, so repeated {@code GET} requests do
 * not re-parse or recompute.</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SessionModelStore {

    private final GraphBuilderService graphBuilderService;
    private final InsightService insightService;

    private volatile Session session;

    /** Immutable snapshot of a loaded model and everything derived from it. */
    private record Session(
            CanonicalModel model,
            Graph<Application, InterfaceEdge> graph,
            List<Finding> findings,
            GraphStats stats) {
    }

    /**
     * Loads a model and eagerly computes and caches its derived graph, findings
     * and statistics, replacing any previously loaded session.
     */
    public synchronized void load(CanonicalModel model) {
        Graph<Application, InterfaceEdge> graph = graphBuilderService.build(model);
        List<Finding> findings = insightService.analyze(model, graph);
        GraphStats stats = computeStats(model, graph);
        this.session = new Session(model, graph, findings, stats);
        log.info("Session loaded: {} applications, {} interfaces, {} findings",
                model.applications().size(), graph.edgeSet().size(), findings.size());
    }

    /** @return {@code true} if a model is currently loaded. */
    public boolean isLoaded() {
        return session != null;
    }

    public CanonicalModel getModel() {
        return require().model();
    }

    public Graph<Application, InterfaceEdge> getGraph() {
        return require().graph();
    }

    public List<Finding> getFindings() {
        return require().findings();
    }

    public GraphStats getStats() {
        return require().stats();
    }

    private Session require() {
        Session current = this.session;
        if (current == null) {
            throw new ModelNotLoadedException(
                    "No dataset loaded. Upload a file via POST /api/upload first.");
        }
        return current;
    }

    private GraphStats computeStats(CanonicalModel model, Graph<Application, InterfaceEdge> graph) {
        String mostConnectedId = null;
        int maxDegree = -1;
        for (Application app : graph.vertexSet()) {
            int degree = graph.degreeOf(app);
            if (degree > maxDegree) {
                maxDegree = degree;
                mostConnectedId = app.id();
            }
        }
        return GraphStats.builder()
                .applicationCount(model.applications().size())
                .interfaceCount(graph.edgeSet().size())
                .domainCount(model.domains().size())
                .businessProcessCount(model.businessProcesses().size())
                .informationObjectCount(model.informationObjects().size())
                .mostConnectedApplicationId(mostConnectedId)
                .maxDegree(Math.max(maxDegree, 0))
                .build();
    }
}

