package com.vw.eacontext.admin.dto;

import com.vw.eacontext.security.model.Permission;

/**
 * Read model for one entry of the permission catalogue.
 *
 * @param code        the authority string, e.g. {@code AI_SUMMARY}
 * @param category    grouping used by the admin UI
 * @param description human-readable explanation
 */
public record PermissionDto(String code, String category, String description) {

    public static PermissionDto from(Permission permission) {
        return new PermissionDto(
                permission.getCode(),
                permission.getCategory() == null ? null : permission.getCategory().name(),
                permission.getDescription());
    }
}

