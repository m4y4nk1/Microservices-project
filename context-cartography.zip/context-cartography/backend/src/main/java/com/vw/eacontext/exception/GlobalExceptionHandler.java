package com.vw.eacontext.exception;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.support.MissingServletRequestPartException;

import com.vw.eacontext.dto.ApiError;

import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;

/**
 * Translates exceptions into consistent, structured JSON {@link ApiError}
 * responses (timestamp, status, error, message, details) with appropriate HTTP
 * status codes.
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /** No dataset loaded yet -> 409 Conflict. */
    @ExceptionHandler(ModelNotLoadedException.class)
    public ResponseEntity<ApiError> handleNotLoaded(ModelNotLoadedException ex) {
        return build(HttpStatus.CONFLICT, ex.getMessage());
    }

    /** Unknown entity -> 404 Not Found. */
    @ExceptionHandler(EaNotFoundException.class)
    public ResponseEntity<ApiError> handleNotFound(EaNotFoundException ex) {
        return build(HttpStatus.NOT_FOUND, ex.getMessage());
    }

    /** Parsing / ingestion problems -> 400 Bad Request. */
    @ExceptionHandler(EaIngestionException.class)
    public ResponseEntity<ApiError> handleIngestion(EaIngestionException ex) {
        return build(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    /** Bad or disabled credentials -> 401 Unauthorized. */
    @ExceptionHandler({BadCredentialsException.class, DisabledException.class})
    public ResponseEntity<ApiError> handleBadCredentials(AuthenticationException ex) {
        // Deliberately generic: never reveal whether the account exists.
        String message = ex instanceof DisabledException
                ? "This account has been deactivated."
                : "Invalid email or password.";
        return build(HttpStatus.UNAUTHORIZED, message);
    }

    /** Any other authentication failure -> 401 Unauthorized. */
    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<ApiError> handleAuthentication(AuthenticationException ex) {
        return build(HttpStatus.UNAUTHORIZED, "Authentication failed.");
    }

    /** Missing permission -> 403 Forbidden. */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiError> handleAccessDenied(AccessDeniedException ex) {
        String message = ex.getMessage() == null || ex.getMessage().isBlank()
                ? "Access denied: your role does not grant permission for this operation."
                : ex.getMessage();
        return build(HttpStatus.FORBIDDEN, message);
    }

    /** Daily AI token budget exhausted -> 429 Too Many Requests. */
    @ExceptionHandler(TokenQuotaExceededException.class)
    public ResponseEntity<ApiError> handleQuota(TokenQuotaExceededException ex) {
        return build(HttpStatus.TOO_MANY_REQUESTS, ex.getMessage());
    }

    /** AI capability switched off by an administrator -> 503 Service Unavailable. */
    @ExceptionHandler(AiFeatureDisabledException.class)
    public ResponseEntity<ApiError> handleAiDisabled(AiFeatureDisabledException ex) {
        return build(HttpStatus.SERVICE_UNAVAILABLE, ex.getMessage());
    }

    /** Bean validation on request bodies -> 400 with per-field details. */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiError> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
        List<String> details = ex.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + ": " + fe.getDefaultMessage())
                .toList();
        return build(HttpStatus.BAD_REQUEST, "Validation failed", details);
    }

    /** Constraint violations on params/path vars -> 400 with details. */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiError> handleConstraintViolation(ConstraintViolationException ex) {
        List<String> details = ex.getConstraintViolations().stream()
                .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                .toList();
        return build(HttpStatus.BAD_REQUEST, "Validation failed", details);
    }

    /** Other bad request conditions -> 400 Bad Request. */
    @ExceptionHandler({
            IllegalArgumentException.class,
            MissingServletRequestParameterException.class,
            MissingServletRequestPartException.class
    })
    public ResponseEntity<ApiError> handleBadRequest(Exception ex) {
        return build(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    /** Wrong HTTP verb for the route -> 405 Method Not Allowed. */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ApiError> handleMethodNotSupported(
            HttpRequestMethodNotSupportedException ex) {
        return build(HttpStatus.METHOD_NOT_ALLOWED, ex.getMessage());
    }

    /** Unsupported request body media type -> 415 Unsupported Media Type. */
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ApiError> handleMediaTypeNotSupported(
            HttpMediaTypeNotSupportedException ex) {
        return build(HttpStatus.UNSUPPORTED_MEDIA_TYPE, ex.getMessage());
    }

    /** Malformed or missing JSON body -> 400 Bad Request. */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiError> handleUnreadableBody(HttpMessageNotReadableException ex) {
        return build(HttpStatus.BAD_REQUEST, "Malformed or missing request body");
    }

    /** Anything else -> 500 Internal Server Error. */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiError> handleGeneric(Exception ex) {
        log.error("Unhandled exception", ex);
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "Unexpected error: " + ex.getMessage());
    }

    private ResponseEntity<ApiError> build(HttpStatus status, String message) {
        return build(status, message, List.of());
    }

    private ResponseEntity<ApiError> build(HttpStatus status, String message, List<String> details) {
        return ResponseEntity.status(status)
                .body(ApiError.of(status.value(), status.getReasonPhrase(), message, details));
    }
}

