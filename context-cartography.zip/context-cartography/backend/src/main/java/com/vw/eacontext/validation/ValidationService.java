package com.vw.eacontext.validation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

import org.springframework.stereotype.Service;

import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.BusinessProcess;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.model.Domain;
import com.vw.eacontext.model.InformationObject;
import com.vw.eacontext.model.Interface;

import lombok.extern.slf4j.Slf4j;

/**
 * Validates a parsed {@link CanonicalModel} for data-quality issues.
 *
 * <p>All findings are collected into a {@link ValidationReport}; this service
 * never throws on data issues. It checks:</p>
 * <ul>
 *   <li><b>Required fields</b> â€” every entity must have a non-blank {@code id} and {@code name} (ERROR).</li>
 *   <li><b>Unique IDs</b> â€” ids must be unique within each entity type (ERROR).</li>
 *   <li><b>Referential integrity</b> â€” each interface's provider/consumer must
 *       reference an existing application (ERROR for unknown ids, WARNING for missing ones).</li>
 *   <li><b>Completeness</b> â€” applications should declare an owner (WARNING).</li>
 * </ul>
 */
@Slf4j
@Service
public class ValidationService {

    /**
     * Validates the given model and returns a report of all issues found.
     *
     * @param model the canonical model to validate (may be {@code null})
     * @return a populated {@link ValidationReport} (never {@code null})
     */
    public ValidationReport validate(CanonicalModel model) {
        List<ValidationIssue> issues = new ArrayList<>();
        if (model == null) {
            issues.add(ValidationIssue.error("Canonical model is null"));
            return new ValidationReport(issues);
        }

        // Required fields + unique IDs per entity type.
        validateEntities(issues, "Domain", model.domains(), Domain::id, Domain::name);
        validateEntities(issues, "BusinessProcess", model.businessProcesses(), BusinessProcess::id, BusinessProcess::name);
        validateEntities(issues, "Application", model.applications(), Application::id, Application::name);
        validateEntities(issues, "Interface", model.interfaces(), Interface::id, Interface::name);
        validateEntities(issues, "InformationObject", model.informationObjects(), InformationObject::id, InformationObject::name);

        // Completeness: applications should have an owner.
        for (Application app : model.applications()) {
            if (isBlank(app.owner())) {
                issues.add(ValidationIssue.warning(
                        "Application '" + idLabel(app.id()) + "' is missing an owner"));
            }
        }

        // Referential integrity: interface provider/consumer -> existing application.
        Set<String> applicationIds = new HashSet<>();
        for (Application app : model.applications()) {
            if (!isBlank(app.id())) {
                applicationIds.add(app.id());
            }
        }
        for (Interface iface : model.interfaces()) {
            checkReference(issues, iface, "provider", iface.providerId(), applicationIds);
            checkReference(issues, iface, "consumer", iface.consumerId(), applicationIds);
        }

        log.info("Validation completed: {} issue(s) ({} error(s), {} warning(s))",
                issues.size(),
                issues.stream().filter(i -> i.severity() == Severity.ERROR).count(),
                issues.stream().filter(i -> i.severity() == Severity.WARNING).count());
        return new ValidationReport(issues);
    }

    private <T> void validateEntities(List<ValidationIssue> issues, String type, List<T> entities,
                                      Function<T, String> idFn, Function<T, String> nameFn) {
        Set<String> seenIds = new HashSet<>();
        int index = 0;
        for (T entity : entities) {
            String id = idFn.apply(entity);
            String name = nameFn.apply(entity);

            if (isBlank(id)) {
                issues.add(ValidationIssue.error(
                        type + " at index " + index + " is missing required field 'id'"));
            } else if (!seenIds.add(id)) {
                issues.add(ValidationIssue.error(
                        "Duplicate " + type + " id '" + id + "'"));
            }

            if (isBlank(name)) {
                issues.add(ValidationIssue.error(
                        type + " '" + idLabel(id) + "' is missing required field 'name'"));
            }
            index++;
        }
    }

    private void checkReference(List<ValidationIssue> issues, Interface iface, String role,
                               String referencedId, Set<String> applicationIds) {
        if (isBlank(referencedId)) {
            issues.add(ValidationIssue.warning(
                    "Interface '" + idLabel(iface.id()) + "' has no " + role));
        } else if (!applicationIds.contains(referencedId)) {
            issues.add(ValidationIssue.error(
                    "Interface '" + idLabel(iface.id()) + "' references unknown " + role
                            + " application '" + referencedId + "'"));
        }
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private static String idLabel(String id) {
        return isBlank(id) ? "<no id>" : id;
    }
}

