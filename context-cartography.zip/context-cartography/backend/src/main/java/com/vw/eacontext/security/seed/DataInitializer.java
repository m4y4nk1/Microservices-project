package com.vw.eacontext.security.seed;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.vw.eacontext.admin.service.AiSettingsService;
import com.vw.eacontext.security.config.SeedProperties;
import com.vw.eacontext.security.model.AppUser;
import com.vw.eacontext.security.model.Permission;
import com.vw.eacontext.security.model.PermissionCode;
import com.vw.eacontext.security.model.Role;
import com.vw.eacontext.security.model.RoleName;
import com.vw.eacontext.security.repository.PermissionRepository;
import com.vw.eacontext.security.repository.RoleRepository;
import com.vw.eacontext.security.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Bootstraps the RBAC tables on startup.
 *
 * <p>Seeding is <em>additive and idempotent</em>: new permission codes are
 * inserted on every boot (so upgrades pick them up automatically), but existing
 * roles are never re-permissioned — an administrator's customisations always
 * survive a restart. Only roles that do not yet exist receive the default
 * matrix from {@link RoleName}.</p>
 *
 * <p>Runs at {@link Order} 0, ahead of the EA
 * {@code SampleDataInitializer}, so identity is in place before any dataset is
 * loaded.</p>
 */
@Slf4j
@Component
@Order(0)
@RequiredArgsConstructor
@ConditionalOnProperty(name = "contexa.seed.enabled", havingValue = "true", matchIfMissing = true)
public class DataInitializer implements ApplicationRunner {

    private final PermissionRepository permissions;
    private final RoleRepository roles;
    private final UserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final AiSettingsService aiSettingsService;
    private final SeedProperties seedProperties;

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        seedPermissions();
        seedRoles();
        seedSuperAdmin();
        aiSettingsService.get();   // materialise the singleton settings row
        log.info("Contexa RBAC seeding complete: {} permission(s), {} role(s), {} user(s)",
                permissions.count(), roles.count(), users.count());
    }

    /** Inserts any permission code that is not yet present. */
    private void seedPermissions() {
        for (PermissionCode code : PermissionCode.all()) {
            permissions.findByCode(code.name())
                    .orElseGet(() -> permissions.save(Permission.from(code)));
        }
    }

    /** Creates missing roles with their default permission matrix. */
    private void seedRoles() {
        for (RoleName roleName : RoleName.values()) {
            if (roles.existsByName(roleName.name())) {
                continue;   // never overwrite an administrator's customisation
            }

            List<String> codes = roleName.defaultPermissions().stream()
                    .map(PermissionCode::name)
                    .toList();
            Set<Permission> granted = new HashSet<>(permissions.findByCodeIn(codes));

            roles.save(Role.builder()
                    .name(roleName.name())
                    .description(describe(roleName))
                    .systemRole(true)
                    .permissions(granted)
                    .build());

            log.info("Seeded role {} with {} permission(s)", roleName, granted.size());
        }
    }

    /** Creates the bootstrap administrator if no SUPER_ADMIN account exists. */
    private void seedSuperAdmin() {
        if (users.countByRoleName(RoleName.SUPER_ADMIN.name()) > 0) {
            return;
        }

        Role superAdmin = roles.findByName(RoleName.SUPER_ADMIN.name())
                .orElseThrow(() -> new IllegalStateException("SUPER_ADMIN role was not seeded"));

        String email = seedProperties.getSuperAdminEmail().toLowerCase();
        users.save(AppUser.builder()
                .name(seedProperties.getSuperAdminName())
                .email(email)
                .passwordHash(passwordEncoder.encode(seedProperties.getSuperAdminPassword()))
                .role(superAdmin)
                .active(true)
                .mustChangePassword(true)
                .build());

        log.warn("Seeded bootstrap SUPER_ADMIN '{}'. Change this password immediately "
                + "via POST /api/auth/change-password.", email);
    }

    private String describe(RoleName roleName) {
        return switch (roleName) {
            case SUPER_ADMIN -> "Platform owner. Full access including AI configuration.";
            case ADMIN -> "Manages users, roles and governance. No AI configuration.";
            case ARCHITECT -> "Full data, diagram, analysis, AI and export rights.";
            case ANALYST -> "Read and analyse the landscape, including AI assistance.";
            case VIEWER -> "Read-only diagram access. No AI, no export.";
            case GUEST -> "Demo access to the application frame only.";
        };
    }
}

