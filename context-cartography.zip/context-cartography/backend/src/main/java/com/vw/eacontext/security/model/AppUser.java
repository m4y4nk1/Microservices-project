package com.vw.eacontext.security.model;

import java.time.Instant;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * An application user.
 *
 * <p>Named {@code AppUser} to avoid clashing with Spring Security's
 * {@code org.springframework.security.core.userdetails.User}. Each user holds
 * exactly one {@link Role}; effective authorities are that role's permissions.</p>
 */
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = "passwordHash")
@EqualsAndHashCode(of = "email")
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Login identifier. */
    @Column(name = "email", nullable = false, unique = true, length = 190)
    private String email;

    @Column(name = "name", length = 190)
    private String name;

    /** BCrypt hash. Never exposed through any DTO. */
    @Column(name = "password_hash", nullable = false, length = 100)
    private String passwordHash;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "role_id", nullable = false)
    private Role role;

    /** Deactivated users keep their audit history but cannot authenticate. */
    @Builder.Default
    @Column(name = "active", nullable = false)
    private boolean active = true;

    /** Set when a user is invited and must choose a password on first login. */
    @Builder.Default
    @Column(name = "must_change_password", nullable = false)
    private boolean mustChangePassword = false;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "last_login_at")
    private Instant lastLoginAt;

    @PrePersist
    void onCreate() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    /** @return the effective authority strings for this user. */
    public Set<String> permissionCodes() {
        return role == null ? Set.of() : role.permissionCodes();
    }

    /** @return the user's role name, or {@code null} when unassigned. */
    public String roleName() {
        return role == null ? null : role.getName();
    }
}

