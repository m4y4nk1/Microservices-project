package com.vw.eacontext.security.service;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.vw.eacontext.security.model.PermissionCode;

/**
 * Read-only access to the caller's identity and authorities.
 *
 * <p>Used for audit attribution, quota accounting and the handful of checks
 * (such as per-frame diagram rights and per-format export rights) that cannot
 * be expressed as a single {@code @PreAuthorize} expression on a controller
 * method.</p>
 */
@Service
public class CurrentUserService {

    /** Actor recorded when no user is authenticated (e.g. startup tasks). */
    public static final String SYSTEM_ACTOR = "system";

    /** Actor recorded for unauthenticated calls when security is disabled. */
    public static final String ANONYMOUS_ACTOR = "anonymous";

    private final boolean securityEnabled;

    public CurrentUserService(
            @Value("${contexa.security.enabled:true}") boolean securityEnabled) {
        this.securityEnabled = securityEnabled;
    }

    /** @return the authenticated principal name, if any. */
    public Optional<String> currentEmail() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || isAnonymous(auth)) {
            return Optional.empty();
        }
        return Optional.ofNullable(auth.getName());
    }

    /** @return the principal name, or {@code anonymous} when unauthenticated. */
    public String actor() {
        return currentEmail().orElse(ANONYMOUS_ACTOR);
    }

    /** @return the caller's granted authority strings. */
    public Set<String> authorities() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || isAnonymous(auth)) {
            return Set.of();
        }
        return auth.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toSet());
    }

    /**
     * Checks a permission against the current authentication.
     *
     * <p>When the security chain is disabled via
     * {@code contexa.security.enabled=false} the check always passes, so the
     * unsecured mode behaves exactly like the pre-RBAC application.</p>
     *
     * @param permission the permission to test
     * @return {@code true} if the caller holds the permission
     */
    public boolean has(PermissionCode permission) {
        if (!securityEnabled) {
            return true;
        }
        return authorities().contains(permission.name());
    }

    /** @return {@code true} when a real (non-anonymous) user is authenticated. */
    public boolean isAuthenticated() {
        return currentEmail().isPresent();
    }

    private boolean isAnonymous(Authentication auth) {
        return auth.getAuthorities().stream()
                .anyMatch(a -> "ROLE_ANONYMOUS".equals(a.getAuthority()));
    }
}


