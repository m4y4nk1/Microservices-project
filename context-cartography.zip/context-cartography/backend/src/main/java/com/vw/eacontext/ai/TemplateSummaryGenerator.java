package com.vw.eacontext.ai;

import java.util.List;

import com.vw.eacontext.dto.GraphStats;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.insight.FindingType;
import com.vw.eacontext.validation.Severity;

/**
 * A deterministic, template-based {@link SummaryGenerator} that requires no
 * external AI service. It composes a stable, human-readable summary from the
 * findings and graph statistics, guaranteeing the application works before any
 * LLM is wired in.
 *
 * <p>Output is fully deterministic: entity ids within each section are sorted,
 * so the same input always yields the same summary.</p>
 */
public class TemplateSummaryGenerator implements SummaryGenerator {

    @Override
    public String summarize(List<Finding> findings, GraphStats stats) {
        List<Finding> safeFindings = findings == null ? List.of() : findings;

        StringBuilder sb = new StringBuilder();
        appendOverview(sb, stats);
        appendIssueTotals(sb, safeFindings);
        appendSection(sb, safeFindings, FindingType.OWNERSHIP_GAP,
                "Ownership gaps", "application(s) without an owner");
        appendSection(sb, safeFindings, FindingType.LIFECYCLE_RISK,
                "Lifecycle risks", "EOL/Deprecated application(s)");
        appendSection(sb, safeFindings, FindingType.ORPHAN_INTERFACE,
                "Orphan interfaces", "interface(s) with no consumer");
        appendSection(sb, safeFindings, FindingType.MISSING_PROCESS_MAPPING,
                "Missing process mappings", "application(s) not mapped to a process");
        appendSection(sb, safeFindings, FindingType.DEPENDENCY_HOTSPOT,
                "Dependency hotspots", "potential single point(s) of failure");
        appendHotspot(sb, stats);
        return sb.toString().stripTrailing();
    }

    private void appendOverview(StringBuilder sb, GraphStats stats) {
        if (stats == null) {
            sb.append("Analyzed the EA landscape.\n");
            return;
        }
        sb.append(String.format(
                "Analyzed %d application(s) across %d domain(s) and %d business process(es), "
                        + "connected by %d interface(s); %d information object(s) tracked.%n",
                stats.applicationCount(), stats.domainCount(), stats.businessProcessCount(),
                stats.interfaceCount(), stats.informationObjectCount()));
    }

    private void appendIssueTotals(StringBuilder sb, List<Finding> findings) {
        if (findings.isEmpty()) {
            sb.append("No issues were detected.\n");
            return;
        }
        long errors = findings.stream().filter(f -> f.severity() == Severity.ERROR).count();
        long warnings = findings.stream().filter(f -> f.severity() == Severity.WARNING).count();
        sb.append(String.format("Detected %d issue(s): %d error(s) and %d warning(s).%n",
                findings.size(), errors, warnings));
    }

    private void appendSection(StringBuilder sb, List<Finding> findings, FindingType type,
                               String title, String noun) {
        List<String> ids = findings.stream()
                .filter(f -> f.type() == type)
                .map(Finding::entityId)
                .distinct()
                .sorted()
                .toList();
        if (ids.isEmpty()) {
            return;
        }
        sb.append(String.format("- %s: %d %s (%s).%n",
                title, ids.size(), noun, String.join(", ", ids)));
    }

    private void appendHotspot(StringBuilder sb, GraphStats stats) {
        if (stats != null && stats.mostConnectedApplicationId() != null) {
            sb.append(String.format("Most connected application: %s (degree %d).%n",
                    stats.mostConnectedApplicationId(), stats.maxDegree()));
        }
    }
}

