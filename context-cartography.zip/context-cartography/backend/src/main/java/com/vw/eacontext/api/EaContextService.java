package com.vw.eacontext.api;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.vw.eacontext.admin.model.AiFeature;
import com.vw.eacontext.admin.model.AuditAction;
import com.vw.eacontext.admin.service.AiGovernanceService;
import com.vw.eacontext.admin.service.AuditService;
import com.vw.eacontext.ai.SummaryGenerator;
import com.vw.eacontext.dto.ExportFile;
import com.vw.eacontext.dto.Frame;
import com.vw.eacontext.dto.GraphDto;
import com.vw.eacontext.dto.ImpactAnalysisResult;
import com.vw.eacontext.exception.EaIngestionException;
import com.vw.eacontext.graph.GraphProjectionService;
import com.vw.eacontext.graph.ImpactAnalysisService;
import com.vw.eacontext.ingestion.CsvEaDataParser;
import com.vw.eacontext.ingestion.EaDataParser;
import com.vw.eacontext.ingestion.ExcelEaDataParser;
import com.vw.eacontext.ingestion.JsonEaDataParser;
import com.vw.eacontext.insight.Finding;
import com.vw.eacontext.model.CanonicalModel;
import com.vw.eacontext.security.model.PermissionCode;
import com.vw.eacontext.security.service.CurrentUserService;
import com.vw.eacontext.security.service.FramePermissionEvaluator;
import com.vw.eacontext.validation.ValidationReport;
import com.vw.eacontext.validation.ValidationService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Application service for the REST layer. Parsing/validation happens on upload;
 * all read operations reuse the derived artifacts cached in
 * {@link SessionModelStore}.
 *
 * <p>This is also where the two authorization rules that cannot be expressed as
 * a controller annotation are applied: per-frame diagram rights, and the AI
 * governance gate (feature toggles plus the caller's daily token budget).
 * Uploads, exports and AI calls are written to the audit trail.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EaContextService {

    private final JsonEaDataParser jsonParser;
    private final ExcelEaDataParser excelParser;
    private final CsvEaDataParser csvParser;
    private final ValidationService validationService;
    private final GraphProjectionService projectionService;
    private final ImpactAnalysisService impactAnalysisService;
    private final SummaryGenerator summaryGenerator;
    private final ExportService exportService;
    private final SessionModelStore store;

    // --- Enterprise layer -------------------------------------------------
    private final FramePermissionEvaluator framePermissions;
    private final AiGovernanceService aiGovernance;
    private final AuditService audit;
    private final CurrentUserService currentUser;

    /**
     * Parses the uploaded file (JSON, XLSX, or ZIP-of-CSVs), caches the model
     * and its derived artifacts, and returns a validation report.
     */
    public ValidationReport upload(MultipartFile file) {
        String actor = currentUser.actor();
        if (file == null || file.isEmpty()) {
            audit.logFailure(actor, AuditAction.DATA_UPLOAD_FAILED, "empty file");
            throw new EaIngestionException("Uploaded file is empty");
        }

        String filename = file.getOriginalFilename();
        EaDataParser parser;
        try {
            parser = parserFor(filename);
        } catch (EaIngestionException e) {
            audit.logFailure(actor, AuditAction.DATA_UPLOAD_FAILED,
                    "unsupported file '" + filename + "'");
            throw e;
        }

        try (InputStream in = file.getInputStream()) {
            CanonicalModel model = parser.parse(in);
            store.load(model);
            log.info("Cached model from '{}'", filename);

            ValidationReport report = validationService.validate(model);
            audit.log(actor, AuditAction.DATA_UPLOADED,
                    "file=" + filename
                            + ", applications=" + model.applications().size()
                            + ", interfaces=" + model.interfaces().size()
                            + ", issues=" + report.issues().size());
            return report;
        } catch (IOException e) {
            audit.logFailure(actor, AuditAction.DATA_UPLOAD_FAILED,
                    "read error on '" + filename + "'");
            throw new EaIngestionException("Failed to read uploaded file", e);
        }
    }

    /**
     * Returns the requested projection after checking the caller holds the
     * frame-specific diagram permission.
     *
     * @throws AccessDeniedException if the frame is not granted to the caller
     */
    public GraphDto graph(Frame frame) {
        framePermissions.check(frame);
        return switch (frame) {
            case APPLICATION -> projectionService.applicationView(store.getGraph());
            case PROCESS -> projectionService.businessProcessView(store.getModel());
            case DOMAIN -> projectionService.domainView(store.getModel(), store.getGraph());
            case INFO_FLOW -> projectionService.informationFlowView(store.getModel());
        };
    }

    public ImpactAnalysisResult impact(String appId) {
        return impactAnalysisService.impactAnalysis(store.getGraph(), appId);
    }

    public List<Finding> insights() {
        return store.getFindings();
    }

    /**
     * Generates the natural-language summary under AI governance.
     *
     * <p>The {@code AI_SUMMARY} permission has already been checked by the
     * controller; here the administrator's feature toggles and the caller's
     * daily token budget are enforced, and the call is audited.</p>
     */
    public String summary() {
        return aiGovernance.execute(
                AiFeature.SUMMARY,
                AiFeature.SUMMARY.defaultTokenCost(),
                () -> summaryGenerator.summarize(store.getFindings(), store.getStats()));
    }

    /**
     * Produces a downloadable export, checking the format-specific permission.
     *
     * @throws AccessDeniedException if the caller may not export this format
     */
    public ExportFile export(String type) {
        checkExportPermission(type);
        ExportFile file = exportService.export(type, store.getStats(), store.getFindings());
        audit.log(currentUser.actor(), AuditAction.EXPORT_GENERATED,
                "type=" + type + ", filename=" + file.filename());
        return file;
    }

    /** Maps an export format onto its permission and verifies the caller holds it. */
    private void checkExportPermission(String type) {
        String normalized = type == null ? "" : type.toLowerCase();
        PermissionCode required = switch (normalized) {
            case "png" -> PermissionCode.EXPORT_PNG;
            case "pdf" -> PermissionCode.EXPORT_PDF;
            case "pptx" -> PermissionCode.EXPORT_PPTX;
            default -> null;
        };
        // Unknown formats fall through to the existing @Pattern validation (400).
        if (required != null && !currentUser.has(required)) {
            throw new AccessDeniedException(
                    "Access denied: exporting '" + normalized + "' requires " + required.name());
        }
    }

    private EaDataParser parserFor(String filename) {
        String name = filename == null ? "" : filename.toLowerCase();
        if (name.endsWith(".json")) {
            return jsonParser;
        }
        if (name.endsWith(".xlsx")) {
            return excelParser;
        }
        if (name.endsWith(".zip")) {
            return csvParser;
        }
        throw new EaIngestionException(
                "Unsupported file type '" + filename + "'. Provide .json, .xlsx, or .zip (CSV files).");
    }
}

