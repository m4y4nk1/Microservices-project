package com.vw.eacontext.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * Configuration for the insight detectors.
 *
 * <p>Bound from {@code ea.insight.*} in {@code application.yml}.</p>
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "ea.insight")
public class InsightProperties {

    /**
     * An application whose total degree (incoming + outgoing interfaces) is
     * strictly greater than this threshold is flagged as a dependency hotspot
     * (a potential single point of failure).
     */
    private int hotspotDegreeThreshold = 5;
}

