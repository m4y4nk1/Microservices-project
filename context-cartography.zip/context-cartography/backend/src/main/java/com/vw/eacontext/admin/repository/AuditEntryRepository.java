package com.vw.eacontext.admin.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.vw.eacontext.admin.model.AuditAction;
import com.vw.eacontext.admin.model.AuditEntry;

/** Repository for the append-only audit trail. */
public interface AuditEntryRepository extends JpaRepository<AuditEntry, Long> {

    Page<AuditEntry> findAllByOrderByCreatedAtDesc(Pageable pageable);

    Page<AuditEntry> findByActorIgnoreCaseOrderByCreatedAtDesc(String actor, Pageable pageable);

    Page<AuditEntry> findByActionInOrderByCreatedAtDesc(List<AuditAction> actions, Pageable pageable);
}

