package com.vw.eacontext.admin.service;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.List;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vw.eacontext.admin.dto.CreateUserRequest;
import com.vw.eacontext.admin.dto.UpdateUserRequest;
import com.vw.eacontext.admin.dto.UserDto;
import com.vw.eacontext.admin.model.AuditAction;
import com.vw.eacontext.exception.EaNotFoundException;
import com.vw.eacontext.security.model.AppUser;
import com.vw.eacontext.security.model.Role;
import com.vw.eacontext.security.model.RoleName;
import com.vw.eacontext.security.repository.RoleRepository;
import com.vw.eacontext.security.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * User lifecycle management for administrators: create/invite, re-role,
 * activate/deactivate, reset password and delete.
 *
 * <p>Two safety rules are enforced here rather than in the controller, so they
 * hold no matter which entry point is used: the last remaining active
 * {@code SUPER_ADMIN} can neither be demoted nor deactivated/deleted.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AdminUserService {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final UserRepository users;
    private final RoleRepository roles;
    private final PasswordEncoder passwordEncoder;
    private final AuditService audit;

    /** @return every user with their role and effective permissions. */
    @Transactional(readOnly = true)
    public List<UserDto> list() {
        return users.findAllWithRole().stream().map(UserDto::from).toList();
    }

    /** @return a single user by id. */
    @Transactional(readOnly = true)
    public UserDto get(Long id) {
        return UserDto.from(require(id));
    }

    /**
     * Creates a user, or invites one when no password is supplied.
     *
     * @param request the new user's details
     * @return the created user, including a flag for a pending password change
     */
    @Transactional
    public UserDto create(CreateUserRequest request) {
        String email = request.email().trim().toLowerCase();
        if (users.existsByEmailIgnoreCase(email)) {
            throw new IllegalArgumentException("A user with email '" + email + "' already exists");
        }

        Role role = requireRole(request.roleName());
        boolean invited = request.password() == null || request.password().isBlank();
        String rawPassword = invited ? generateTemporaryPassword() : request.password();

        AppUser user = users.save(AppUser.builder()
                .name(request.name().trim())
                .email(email)
                .passwordHash(passwordEncoder.encode(rawPassword))
                .role(role)
                .active(true)
                .mustChangePassword(invited)
                .build());

        audit.log(invited ? AuditAction.USER_INVITED : AuditAction.USER_CREATED,
                email + " role=" + role.getName());
        log.info("{} user '{}' with role {}", invited ? "Invited" : "Created", email, role.getName());

        return UserDto.from(user);
    }

    /** Updates a user's name, role and activation state in one call. */
    @Transactional
    public UserDto update(Long id, UpdateUserRequest request) {
        AppUser user = require(id);
        Role newRole = requireRole(request.roleName());

        boolean losingSuperAdmin = isSuperAdmin(user) && !isSuperAdminRole(newRole);
        boolean beingDeactivated = user.isActive() && !request.active();
        if ((losingSuperAdmin || beingDeactivated) && isLastActiveSuperAdmin(user)) {
            throw new IllegalArgumentException(
                    "Cannot demote or deactivate the last active SUPER_ADMIN");
        }

        String previousRole = user.roleName();
        user.setName(request.name().trim());
        user.setRole(newRole);
        user.setActive(request.active());
        users.save(user);

        if (!newRole.getName().equals(previousRole)) {
            audit.log(AuditAction.USER_ROLE_CHANGED,
                    user.getEmail() + ": " + previousRole + " -> " + newRole.getName());
        }
        audit.log(request.active() ? AuditAction.USER_ACTIVATED : AuditAction.USER_DEACTIVATED,
                user.getEmail());

        return UserDto.from(user);
    }

    /** Changes only the user's role. */
    @Transactional
    public UserDto changeRole(Long id, String roleName) {
        AppUser user = require(id);
        Role newRole = requireRole(roleName);

        if (isSuperAdmin(user) && !isSuperAdminRole(newRole) && isLastActiveSuperAdmin(user)) {
            throw new IllegalArgumentException("Cannot demote the last active SUPER_ADMIN");
        }

        String previousRole = user.roleName();
        user.setRole(newRole);
        users.save(user);

        audit.log(AuditAction.USER_ROLE_CHANGED,
                user.getEmail() + ": " + previousRole + " -> " + newRole.getName());
        return UserDto.from(user);
    }

    /** Enables or disables a user's ability to authenticate. */
    @Transactional
    public UserDto setActive(Long id, boolean active) {
        AppUser user = require(id);
        if (!active && isLastActiveSuperAdmin(user)) {
            throw new IllegalArgumentException("Cannot deactivate the last active SUPER_ADMIN");
        }

        user.setActive(active);
        users.save(user);

        audit.log(active ? AuditAction.USER_ACTIVATED : AuditAction.USER_DEACTIVATED,
                user.getEmail());
        return UserDto.from(user);
    }

    /**
     * Issues a new temporary password for a user.
     *
     * @return the plaintext temporary password, shown to the administrator once
     */
    @Transactional
    public String resetPassword(Long id) {
        AppUser user = require(id);
        String temporary = generateTemporaryPassword();
        user.setPasswordHash(passwordEncoder.encode(temporary));
        user.setMustChangePassword(true);
        users.save(user);

        audit.log(AuditAction.USER_PASSWORD_RESET, user.getEmail());
        log.info("Password reset issued for '{}'", user.getEmail());
        return temporary;
    }

    /** Permanently removes a user. */
    @Transactional
    public void delete(Long id) {
        AppUser user = require(id);
        if (isLastActiveSuperAdmin(user)) {
            throw new IllegalArgumentException("Cannot delete the last active SUPER_ADMIN");
        }
        users.delete(user);
        audit.log(AuditAction.USER_DELETED, user.getEmail());
    }

    private AppUser require(Long id) {
        return users.findById(id)
                .orElseThrow(() -> new EaNotFoundException("No user with id " + id));
    }

    private Role requireRole(String roleName) {
        return roles.findByName(roleName.trim().toUpperCase())
                .orElseThrow(() -> new EaNotFoundException("No role named '" + roleName + "'"));
    }

    private boolean isSuperAdmin(AppUser user) {
        return RoleName.SUPER_ADMIN.name().equals(user.roleName());
    }

    private boolean isSuperAdminRole(Role role) {
        return RoleName.SUPER_ADMIN.name().equals(role.getName());
    }

    private boolean isLastActiveSuperAdmin(AppUser user) {
        if (!isSuperAdmin(user) || !user.isActive()) {
            return false;
        }
        long activeSuperAdmins = users.findAllWithRole().stream()
                .filter(u -> RoleName.SUPER_ADMIN.name().equals(u.roleName()))
                .filter(AppUser::isActive)
                .count();
        return activeSuperAdmins <= 1;
    }

    private String generateTemporaryPassword() {
        byte[] bytes = new byte[18];
        RANDOM.nextBytes(bytes);
        return "Cx-" + Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}

