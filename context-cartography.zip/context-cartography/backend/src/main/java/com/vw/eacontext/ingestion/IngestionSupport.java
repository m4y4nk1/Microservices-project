package com.vw.eacontext.ingestion;

import java.util.Locale;
import java.util.function.Function;

import com.vw.eacontext.model.Application;
import com.vw.eacontext.model.BusinessProcess;
import com.vw.eacontext.model.Domain;
import com.vw.eacontext.model.InformationObject;
import com.vw.eacontext.model.Interface;
import com.vw.eacontext.model.InterfaceType;
import com.vw.eacontext.model.LifecycleStatus;

import lombok.extern.slf4j.Slf4j;

/**
 * Shared, format-independent helpers for ingestion parsers.
 *
 * <p>Provides the canonical entity-type keys used in the configuration mapping,
 * value/enum normalization, and builders that assemble domain entities from a
 * simple {@code Function<modelField, rawValue>} field reader. This keeps the
 * JSON, CSV and Excel parsers thin and consistent.</p>
 */
@Slf4j
public final class IngestionSupport {

    /** Entity type keys â€” must match the keys used under {@code ea.ingestion.fields}. */
    public static final String APPLICATION = "application";
    public static final String INTERFACE = "interface";
    public static final String BUSINESS_PROCESS = "businessProcess";
    public static final String DOMAIN = "domain";
    public static final String INFORMATION_OBJECT = "informationObject";

    private IngestionSupport() {
    }

    /** Returns {@code null} for null/blank input, otherwise the trimmed value. */
    public static String blankToNull(String value) {
        return (value == null || value.isBlank()) ? null : value.trim();
    }

    /** Parses a lifecycle status case-insensitively; unknown/blank -> {@code null}. */
    public static LifecycleStatus lifecycleStatus(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return LifecycleStatus.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            log.warn("Unknown lifecycleStatus '{}'; leaving unset", raw);
            return null;
        }
    }

    /** Parses an interface type case-insensitively; unknown/blank -> {@code null}. */
    public static InterfaceType interfaceType(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return InterfaceType.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            log.warn("Unknown interface type '{}'; leaving unset", raw);
            return null;
        }
    }

    // --- Format-agnostic entity builders --------------------------------------
    // Each takes a reader that maps a canonical *model* field name to its raw
    // (already blank-normalized) string value from the source.

    public static Domain toDomain(Function<String, String> read) {
        return Domain.builder()
                .id(read.apply("id"))
                .name(read.apply("name"))
                .build();
    }

    public static BusinessProcess toBusinessProcess(Function<String, String> read) {
        return BusinessProcess.builder()
                .id(read.apply("id"))
                .name(read.apply("name"))
                .domainId(read.apply("domainId"))
                .build();
    }

    public static Application toApplication(Function<String, String> read) {
        return Application.builder()
                .id(read.apply("id"))
                .name(read.apply("name"))
                .owner(read.apply("owner"))
                .domain(read.apply("domain"))
                .lifecycleStatus(lifecycleStatus(read.apply("lifecycleStatus")))
                .techStack(read.apply("techStack"))
                .processId(read.apply("processId"))
                .build();
    }

    public static Interface toInterface(Function<String, String> read) {
        return Interface.builder()
                .id(read.apply("id"))
                .name(read.apply("name"))
                .providerId(read.apply("providerId"))
                .consumerId(read.apply("consumerId"))
                .type(interfaceType(read.apply("type")))
                .dataObject(read.apply("dataObject"))
                .build();
    }

    public static InformationObject toInformationObject(Function<String, String> read) {
        return InformationObject.builder()
                .id(read.apply("id"))
                .name(read.apply("name"))
                .build();
    }
}

