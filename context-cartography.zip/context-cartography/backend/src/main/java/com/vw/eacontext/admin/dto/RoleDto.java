package com.vw.eacontext.admin.dto;

import java.util.List;
import java.util.Set;

import com.vw.eacontext.security.model.Role;

/**
 * Administrative read model for a role and the permissions it bundles.
 *
 * @param id          surrogate key
 * @param name        role name
 * @param description human-readable purpose
 * @param systemRole  {@code true} for seeded roles, which cannot be deleted
 * @param permissions the permission codes granted by this role
 * @param userCount   how many users currently hold the role
 */
public record RoleDto(
        Long id,
        String name,
        String description,
        boolean systemRole,
        List<String> permissions,
        long userCount) {

    public static RoleDto from(Role role, long userCount) {
        Set<String> codes = role.permissionCodes();
        return new RoleDto(
                role.getId(),
                role.getName(),
                role.getDescription(),
                role.isSystemRole(),
                List.copyOf(codes),
                userCount);
    }
}

