package com.vw.eacontext.security.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * A single, feature-level permission row.
 *
 * <p>The {@link #code} is the Spring Security authority granted to a user, e.g.
 * {@code AI_SUMMARY}. Rows are seeded from {@link PermissionCode} on startup and
 * are effectively read-only at runtime.</p>
 */
@Entity
@Table(name = "permissions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@EqualsAndHashCode(of = "code")
public class Permission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** The authority string, e.g. {@code AI_SUMMARY}. */
    @Column(name = "code", nullable = false, unique = true, length = 64)
    private String code;

    /** Grouping used by the admin UI (DATA, DIAGRAM, ANALYSIS, AI, EXPORT, ADMIN). */
    @Enumerated(EnumType.STRING)
    @Column(name = "category", nullable = false, length = 32)
    private PermissionCode.Category category;

    /** Human-readable explanation shown in the admin console. */
    @Column(name = "description", length = 255)
    private String description;

    /** Factory building a persistable row from the enum catalogue. */
    public static Permission from(PermissionCode code) {
        return Permission.builder()
                .code(code.name())
                .category(code.category())
                .description(code.description())
                .build();
    }
}

