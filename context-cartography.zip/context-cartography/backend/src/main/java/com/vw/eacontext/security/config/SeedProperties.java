package com.vw.eacontext.security.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * Startup seeding configuration, bound from {@code contexa.seed.*}.
 *
 * <p>Controls creation of the permission catalogue, the default role matrix and
 * the bootstrap {@code SUPER_ADMIN} account.</p>
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "contexa.seed")
public class SeedProperties {

    /** Master switch for the {@code DataInitializer}. */
    private boolean enabled = true;

    /** Bootstrap administrator login. */
    private String superAdminEmail = "admin@contexa.local";

    /** Bootstrap administrator display name. */
    private String superAdminName = "Contexa Admin";

    /**
     * Bootstrap administrator password. The seeded account is flagged
     * {@code mustChangePassword} so this value is only ever valid once.
     */
    private String superAdminPassword = "ChangeMe#123";
}

