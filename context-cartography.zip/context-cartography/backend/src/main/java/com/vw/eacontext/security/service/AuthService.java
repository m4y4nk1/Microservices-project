package com.vw.eacontext.security.service;

import java.time.Instant;
import java.util.List;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vw.eacontext.admin.model.AuditAction;
import com.vw.eacontext.admin.service.AuditService;
import com.vw.eacontext.exception.EaNotFoundException;
import com.vw.eacontext.security.dto.ChangePasswordRequest;
import com.vw.eacontext.security.dto.LoginRequest;
import com.vw.eacontext.security.dto.LoginResponse;
import com.vw.eacontext.security.dto.MeResponse;
import com.vw.eacontext.security.model.AppUser;
import com.vw.eacontext.security.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Authenticates users and issues access tokens.
 *
 * <p>Both successful and failed logins are audited. Credential verification is
 * delegated to Spring Security's {@link AuthenticationManager} so account state
 * (disabled, locked) is honoured consistently.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserRepository users;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;
    private final AuditService audit;

    /**
     * Verifies credentials and mints a token.
     *
     * @param request the submitted credentials
     * @return the token plus the caller's effective permissions
     * @throws AuthenticationException if the credentials are invalid or the account is disabled
     */
    @Transactional
    public LoginResponse login(LoginRequest request) {
        String email = request.email().trim();
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(email, request.password()));
        } catch (DisabledException e) {
            audit.logFailure(email, AuditAction.LOGIN_FAILURE, "account disabled");
            throw e;
        } catch (AuthenticationException e) {
            audit.logFailure(email, AuditAction.LOGIN_FAILURE, "bad credentials");
            throw e;
        }

        AppUser user = users.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new BadCredentialsException("Invalid email or password"));

        user.setLastLoginAt(Instant.now());
        users.save(user);

        audit.log(email, AuditAction.LOGIN_SUCCESS, "role=" + user.roleName());
        log.info("User '{}' logged in with role {}", email, user.roleName());

        return new LoginResponse(
                jwtService.issue(user),
                "Bearer",
                jwtService.expiresInSeconds(),
                user.getEmail(),
                user.getName(),
                user.roleName(),
                List.copyOf(user.permissionCodes()),
                user.isMustChangePassword());
    }

    /** @return the identity and permissions of the currently authenticated user. */
    @Transactional(readOnly = true)
    public MeResponse me(String email) {
        AppUser user = users.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new EaNotFoundException("No user with email " + email));
        return new MeResponse(
                user.getEmail(),
                user.getName(),
                user.roleName(),
                List.copyOf(user.permissionCodes()));
    }

    /**
     * Changes the caller's own password after re-verifying the current one.
     *
     * @param email   the authenticated principal
     * @param request current and replacement passwords
     */
    @Transactional
    public void changePassword(String email, ChangePasswordRequest request) {
        AppUser user = users.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new EaNotFoundException("No user with email " + email));

        if (!passwordEncoder.matches(request.currentPassword(), user.getPasswordHash())) {
            audit.logFailure(email, AuditAction.PASSWORD_CHANGED, "current password mismatch");
            throw new BadCredentialsException("Current password is incorrect");
        }

        user.setPasswordHash(passwordEncoder.encode(request.newPassword()));
        user.setMustChangePassword(false);
        users.save(user);

        audit.log(email, AuditAction.PASSWORD_CHANGED, "self-service change");
        log.info("User '{}' changed their password", email);
    }
}

