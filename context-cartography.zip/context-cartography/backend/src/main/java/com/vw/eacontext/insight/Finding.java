package com.vw.eacontext.insight;

import com.vw.eacontext.validation.Severity;

/**
 * A single insight produced by the {@link InsightService}.
 *
 * @param type     the {@link FindingType category} of finding
 * @param severity the {@link Severity} of the finding
 * @param entityId the id of the entity the finding concerns (application or interface)
 * @param message  a human-readable description
 */
public record Finding(FindingType type, Severity severity, String entityId, String message) {
}

