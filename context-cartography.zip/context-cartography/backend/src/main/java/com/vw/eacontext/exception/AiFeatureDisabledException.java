package com.vw.eacontext.exception;

/**
 * Raised when an AI feature is switched off by an administrator (either the
 * master {@code aiEnabled} switch or the specific feature toggle).
 *
 * <p>Mapped to HTTP 503 (Service Unavailable) by the global handler: the caller
 * is permitted, but the capability is currently disabled.</p>
 */
public class AiFeatureDisabledException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public AiFeatureDisabledException(String message) {
        super(message);
    }
}

