package com.vw.eacontext.admin.dto;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

/**
 * Payload for {@code PUT /api/admin/roles/{name}/permissions}.
 *
 * <p>The list is authoritative: it fully replaces the role's current permission
 * set, which makes the admin UI's checkbox grid trivially idempotent.</p>
 *
 * @param permissions the complete set of permission codes to grant
 */
public record UpdateRolePermissionsRequest(
        @NotNull(message = "permissions is required")
        @NotEmpty(message = "permissions must not be empty")
        List<String> permissions) {
}

