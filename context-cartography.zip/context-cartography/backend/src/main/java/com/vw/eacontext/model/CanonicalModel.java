package com.vw.eacontext.model;

import java.util.List;

import lombok.Builder;

/**
 * The canonical, in-memory representation of an entire EA dataset after
 * ingestion â€” the single source of truth consumed by the graph and insight
 * layers.
 *
 * <p>Each list is guaranteed to be non-null (empty rather than {@code null})
 * so callers can iterate without null checks.</p>
 *
 * @param domains            business/architecture domains
 * @param businessProcesses  business processes
 * @param applications       applications (systems)
 * @param interfaces         integrations between applications
 * @param informationObjects information/data objects
 */
@Builder
public record CanonicalModel(
        List<Domain> domains,
        List<BusinessProcess> businessProcesses,
        List<Application> applications,
        List<Interface> interfaces,
        List<InformationObject> informationObjects
) {
    public CanonicalModel {
        domains = domains == null ? List.of() : List.copyOf(domains);
        businessProcesses = businessProcesses == null ? List.of() : List.copyOf(businessProcesses);
        applications = applications == null ? List.of() : List.copyOf(applications);
        interfaces = interfaces == null ? List.of() : List.copyOf(interfaces);
        informationObjects = informationObjects == null ? List.of() : List.copyOf(informationObjects);
    }
}

