package com.vw.eacontext.security.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vw.eacontext.security.model.AppUser;

/** Repository for {@link AppUser} identities. */
public interface UserRepository extends JpaRepository<AppUser, Long> {

    Optional<AppUser> findByEmailIgnoreCase(String email);

    boolean existsByEmailIgnoreCase(String email);

    @Query("select u from AppUser u join fetch u.role r left join fetch r.permissions order by u.email")
    List<AppUser> findAllWithRole();

    long countByRoleName(String roleName);
}

