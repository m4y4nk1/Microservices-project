package com.vw.eacontext.security.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vw.eacontext.security.model.Role;

/** Repository for {@link Role} definitions. */
public interface RoleRepository extends JpaRepository<Role, Long> {

    Optional<Role> findByName(String name);

    boolean existsByName(String name);

    @Query("select distinct r from Role r left join fetch r.permissions order by r.name")
    List<Role> findAllWithPermissions();
}

