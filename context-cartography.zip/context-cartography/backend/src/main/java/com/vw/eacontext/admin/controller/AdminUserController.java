package com.vw.eacontext.admin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vw.eacontext.admin.dto.CreateUserRequest;
import com.vw.eacontext.admin.dto.UpdateUserRequest;
import com.vw.eacontext.admin.dto.UserDto;
import com.vw.eacontext.admin.service.AdminUserService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;

/**
 * User administration endpoints, all gated on
 * {@link com.vw.eacontext.security.model.PermissionCode#USER_MANAGE}.
 */
@RestController
@RequestMapping(value = "/api/admin/users", produces = MediaType.APPLICATION_JSON_VALUE)
@PreAuthorize("hasAuthority('USER_MANAGE')")
@RequiredArgsConstructor
public class AdminUserController {

    private final AdminUserService userService;

    /** Lists every user. */
    @GetMapping
    public ResponseEntity<List<UserDto>> list() {
        return ResponseEntity.ok(userService.list());
    }

    /** Fetches one user by id. */
    @GetMapping("/{id}")
    public ResponseEntity<UserDto> get(@PathVariable Long id) {
        return ResponseEntity.ok(userService.get(id));
    }

    /** Creates a user, or invites one when no password is supplied. */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserDto> create(@Valid @RequestBody CreateUserRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.create(request));
    }

    /** Updates a user's name, role and activation state. */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserDto> update(@PathVariable Long id,
                                          @Valid @RequestBody UpdateUserRequest request) {
        return ResponseEntity.ok(userService.update(id, request));
    }

    /** Re-assigns a user's role. */
    @PutMapping("/{id}/role")
    public ResponseEntity<UserDto> changeRole(@PathVariable Long id,
                                              @RequestParam @NotBlank String roleName) {
        return ResponseEntity.ok(userService.changeRole(id, roleName));
    }

    /** Activates or deactivates a user. */
    @PutMapping("/{id}/active")
    public ResponseEntity<UserDto> setActive(@PathVariable Long id,
                                             @RequestParam boolean active) {
        return ResponseEntity.ok(userService.setActive(id, active));
    }

    /**
     * Issues a new temporary password.
     *
     * @return the plaintext password, returned exactly once for hand-over
     */
    @PostMapping("/{id}/reset-password")
    public ResponseEntity<Map<String, String>> resetPassword(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("temporaryPassword", userService.resetPassword(id)));
    }

    /** Permanently deletes a user. */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        userService.delete(id);
        return ResponseEntity.noContent().build();
    }
}

