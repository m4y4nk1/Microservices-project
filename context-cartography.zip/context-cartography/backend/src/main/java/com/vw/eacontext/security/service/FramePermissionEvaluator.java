package com.vw.eacontext.security.service;

import java.util.Map;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;

import com.vw.eacontext.dto.Frame;
import com.vw.eacontext.security.model.PermissionCode;

import lombok.RequiredArgsConstructor;

/**
 * Enforces per-frame diagram rights.
 *
 * <p>All four observation frames are served by the single
 * {@code GET /api/graph/{frame}} endpoint, so a method-level
 * {@code @PreAuthorize} can only express the coarse {@code DIAGRAM_VIEW} gate.
 * This evaluator applies the finer rule — which is what allows a {@code GUEST}
 * to see the application frame and nothing else.</p>
 */
@Component
@RequiredArgsConstructor
public class FramePermissionEvaluator {

    private static final Map<Frame, PermissionCode> FRAME_PERMISSIONS = Map.of(
            Frame.APPLICATION, PermissionCode.DIAGRAM_VIEW_APPLICATION,
            Frame.PROCESS, PermissionCode.DIAGRAM_VIEW_PROCESS,
            Frame.DOMAIN, PermissionCode.DIAGRAM_VIEW_DOMAIN,
            Frame.INFO_FLOW, PermissionCode.DIAGRAM_VIEW_INFOFLOW);

    private final CurrentUserService currentUser;

    /**
     * Verifies the caller may view the given frame.
     *
     * @param frame the requested observation frame
     * @throws AccessDeniedException if the caller lacks the frame's permission
     */
    public void check(Frame frame) {
        PermissionCode required = FRAME_PERMISSIONS.get(frame);
        if (required == null) {
            throw new AccessDeniedException("Unknown frame: " + frame);
        }
        if (!currentUser.has(required)) {
            throw new AccessDeniedException(
                    "Access denied: viewing the '" + frame.slug() + "' frame requires "
                            + required.name());
        }
    }

    /** @return the permission required to view the given frame. */
    public PermissionCode permissionFor(Frame frame) {
        return FRAME_PERMISSIONS.get(frame);
    }
}

