# RBAC Implementation — File Guide

**Date:** September 9, 2026  
**Status:** Complete. 75 backend tests passing, frontend syntax-checked.

This document catalogs every file added or modified to implement role-based access control (RBAC), JWT authentication, and AI governance for Contexa.

---

## Backend Files Added

### Security Domain Model

#### `backend/src/main/java/com/vw/eacontext/security/model/PermissionCode.java`
**Role:** Catalogue of 24 feature-level permissions (enums).  
**What it does:**
- Defines `DATA_UPLOAD`, `AI_SUMMARY`, `EXPORT_PDF`, `USER_MANAGE`, etc. as an enum.
- Groups permissions by category (DATA, DIAGRAM, ANALYSIS, AI, EXPORT, ADMIN).
- Provides `isValid()` to check if a string is a known permission.

**Why:** Features are bound to permissions, never roles. Admins can grant any capability independently.

---

#### `backend/src/main/java/com/vw/eacontext/security/model/RoleName.java`
**Role:** Seeded role definitions and their default permission matrices.  
**What it does:**
- Six roles: `SUPER_ADMIN`, `ADMIN`, `ARCHITECT`, `ANALYST`, `VIEWER`, `GUEST`.
- Each role's `defaultPermissions()` returns the set of permissions it is seeded with.
- Example: `ARCHITECT` gets all diagram/analysis/AI/export, but no `USER_MANAGE`.

**Why:** Bakes in the enterprise blueprint's permission matrix so new databases have sane defaults.

---

#### `backend/src/main/java/com/vw/eacontext/security/model/AppUser.java`
**Role:** JPA entity for a user account.  
**Fields:**
- `id`, `email` (unique), `name`, `passwordHash` (BCrypt).
- `role` (many-to-one to `Role`).
- `active` (boolean), `mustChangePassword` (for invitations).
- `createdAt`, `lastLoginAt` (audit timestamps).

**Why:** Persists user identities; Spring Security bridge via `AppUserDetailsService`.

---

#### `backend/src/main/java/com/vw/eacontext/security/model/Role.java`
**Role:** JPA entity bundling permissions.  
**Fields:**
- `id`, `name` (unique, e.g., `"ARCHITECT"`).
- `permissions` (many-to-many to `Permission`).
- `systemRole` (true for seeded roles; false for custom).
- `description` (shown in admin console).

**Methods:**
- `grants(PermissionCode)` — check if this role grants a permission.
- `permissionCodes()` — return sorted permission codes (stable API output).

**Why:** Roles are mutable; admins reshape them without touching code.

---

#### `backend/src/main/java/com/vw/eacontext/security/model/Permission.java`
**Role:** JPA entity representing one capability.  
**Fields:**
- `id`, `code` (unique, e.g., `"AI_SUMMARY"`).
- `category` (enum).
- `description` (human-readable).

**Factory:** `Permission.from(PermissionCode)` — converts enum to entity.

**Why:** Seeded once from the catalogue; read-only at runtime.

---

### Security Infrastructure

#### `backend/src/main/java/com/vw/eacontext/security/repository/UserRepository.java`
**Role:** Spring Data JPA for `AppUser` CRUD.  
**Key queries:**
- `findByEmailIgnoreCase()` — case-insensitive login.
- `findAllWithRole()` — eager-fetch users with their roles (admin console).
- `countByRoleName()` — for the role deletion guard (don't delete if users hold it).

---

#### `backend/src/main/java/com/vw/eacontext/security/repository/RoleRepository.java`
**Role:** Spring Data JPA for `Role` CRUD.  
**Key queries:**
- `findByName()` — load a role by name.
- `findAllWithPermissions()` — eager-fetch all roles with their permission sets.

---

#### `backend/src/main/java/com/vw/eacontext/security/repository/PermissionRepository.java`
**Role:** Spring Data JPA for `Permission` CRUD.  
**Key queries:**
- `findByCode()` — load one permission by code.
- `findByCodeIn()` — load multiple permissions (for role updates).
- `findAllByOrderByCategoryAscCodeAsc()` — for admin permission matrix UI.

---

#### `backend/src/main/java/com/vw/eacontext/security/config/JwtProperties.java`
**Role:** Configuration record for JWT signing.  
**Bound from:** `contexa.jwt.*` (application.yml / env vars).  
**Fields:**
- `secret` — HMAC signing key (min 32 chars; env var or dev default).
- `expiryMs` — token lifetime (default 24h).
- `issuer` — `iss` claim value.

**Why:** Externalizes JWT configuration; easy to rotate keys in production.

---

#### `backend/src/main/java/com/vw/eacontext/security/config/SeedProperties.java`
**Role:** Configuration for bootstrap admin creation.  
**Bound from:** `contexa.seed.*`.  
**Fields:**
- `enabled`, `superAdminEmail`, `superAdminName`, `superAdminPassword`.

**Why:** Allows different bootstrap accounts per environment without recompiling.

---

#### `backend/src/main/java/com/vw/eacontext/security/config/PasswordConfig.java`
**Role:** Always-on password encoding and authentication.  
**Beans:**
- `PasswordEncoder` — BCrypt encoder (needed by data seeder and admin services).
- `DaoAuthenticationProvider` — verifies credentials against the `users` table.
- `AuthenticationManager` — orchestrates authentication.

**Why:** These beans must exist whether or not the JWT filter chain is active (tests run with security disabled).

---

#### `backend/src/main/java/com/vw/eacontext/security/config/SecurityConfig.java`
**Role:** Spring Security HTTP filter chain + method security.  
**Activated by:** `contexa.security.enabled=true` (default; set `false` for legacy test-suite compat).

**Endpoints:**
- `/api/auth/login` — public.
- `/api/admin/**` — requires one of: `USER_MANAGE`, `ROLE_MANAGE`, `AI_CONFIG`, `AUDIT_VIEW`.
- `/api/**` — authenticated.
- Everything else — permitted.

**Decorator:** `@EnableMethodSecurity` — switches on `@PreAuthorize` across the codebase.

---

#### `backend/src/main/java/com/vw/eacontext/security/config/NoSecurityConfig.java`
**Role:** Opt-out security config (no JWT filter, no `@PreAuthorize` enforcement).  
**Activated by:** `contexa.security.enabled=false` (only in test profile).

**Why:** Pre-existing tests call the API anonymously; this class makes them pass without rewriting 46 test cases.

---

#### `backend/src/main/java/com/vw/eacontext/security/config/JwtAuthFilter.java`
**Role:** Servlet filter that reads JWT from `Authorization: Bearer <token>` header.

**Flow:**
1. Extract token from header.
2. Call `JwtService.parse()` to verify signature and expiry.
3. Extract permissions from the `perms` claim.
4. Populate `SecurityContextHolder` with a `UsernamePasswordAuthenticationToken`.
5. On error, clear the context and let the entry point return 401.

**Why:** Stateless; no database hit per request (permissions embedded in token).

---

#### `backend/src/main/java/com/vw/eacontext/security/config/SecurityErrorHandlers.java`
**Role:** Maps authentication (401) and authorization (403) failures to JSON `ApiError`.

**Methods:**
- `commence()` → 401 (implement `AuthenticationEntryPoint`).
- `handle()` → 403 (implement `AccessDeniedHandler`).

**Why:** Clients only parse one error shape; no HTML error pages.

---

#### `backend/src/main/java/com/vw/eacontext/security/service/JwtService.java`
**Role:** Sign and verify stateless access tokens.

**Methods:**
- `issue(AppUser)` — create a signed token carrying `email`, `name`, `role`, `perms` claims.
- `parse(token)` — verify signature and expiry, return claims.
- `permissionsOf(claims)` — extract the permissions list.
- `expiresInSeconds()` — for login response.

**Why:** Decouples token mechanics from the auth controller.

---

#### `backend/src/main/java/com/vw/eacontext/security/service/AppUserDetailsService.java`
**Role:** Spring Security bridge — load user and convert permissions to authorities.

**Method:** `loadUserByUsername(email)` → `UserDetails` with `SimpleGrantedAuthority` per permission code.

**Why:** Reuses Spring's password-verification machinery for login.

---

#### `backend/src/main/java/com/vw/eacontext/security/service/CurrentUserService.java`
**Role:** Read-only access to caller's identity and authorities.

**Methods:**
- `currentEmail()` — optional email of the authenticated principal.
- `actor()` — email or "anonymous".
- `authorities()` — set of permission codes.
- `has(PermissionCode)` — true if caller holds the permission.
- `isAuthenticated()` — boolean.

**Respects:** `contexa.security.enabled` — when false, `has()` always returns true (unsecured mode).

**Why:** Used for audit attribution, per-frame diagram checks, per-format export checks.

---

#### `backend/src/main/java/com/vw/eacontext/security/controller/AuthController.java`
**Role:** REST endpoints for login and identity.

**Endpoints:**
- `POST /api/auth/login` — exchange credentials for token.
- `GET /api/auth/me` — caller's identity (requires auth).
- `POST /api/auth/change-password` — self-service password change.

**Returns:** `LoginResponse` record (token, role, permissions, mustChangePassword flag).

---

#### `backend/src/main/java/com/vw/eacontext/security/service/AuthService.java`
**Role:** Business logic for login, identity, and password change.

**Methods:**
- `login(LoginRequest)` → `LoginResponse` (verifies credentials, audits, returns token).
- `me(email)` → `MeResponse` (caller's identity from DB).
- `changePassword(email, request)` — updates password, clears `mustChangePassword` flag.

**Audits:** LOGIN_SUCCESS / LOGIN_FAILURE / PASSWORD_CHANGED.

---

#### `backend/src/main/java/com/vw/eacontext/security/service/FramePermissionEvaluator.java`
**Role:** Per-frame diagram permission checks.

**Method:** `check(Frame)` — throws 403 if caller lacks the frame's specific permission.

**Mapping:** `application` → `DIAGRAM_VIEW_APPLICATION`, etc.

**Why:** `GET /api/graph/{frame}` can only have one `@PreAuthorize("hasAuthority('DIAGRAM_VIEW')")`, but GUEST should see only `application`. This evaluator enforces the finer rule inside the service layer.

---

#### `backend/src/main/java/com/vw/eacontext/security/seed/DataInitializer.java`
**Role:** `ApplicationRunner` that seeds permissions, roles, bootstrap admin on startup.

**Order:** 0 (runs before `SampleDataInitializer`).

**Flow:**
1. Insert all `PermissionCode` enums as `Permission` rows (if missing).
2. For each `RoleName`, create the `Role` with its default permission set (unless already exists).
3. If no SUPER_ADMIN user exists, create one (`mustChangePassword=true`).

**Idempotent:** Does not overwrite existing roles or users.

**Why:** Every deployment gets a fresh permission/role catalogue, but admin customizations survive upgrades.

---

### Admin Package

#### `backend/src/main/java/com/vw/eacontext/admin/model/AuditAction.java`
**Role:** Enum of auditable events.  
**Values:** `LOGIN_SUCCESS`, `USER_CREATED`, `DATA_UPLOADED`, `AI_CALL`, `AI_QUOTA_EXCEEDED`, etc.

**Why:** Queries are queryable and the UI can filter reliably.

---

#### `backend/src/main/java/com/vw/eacontext/admin/model/AuditEntry.java`
**Role:** JPA entity — one row in the append-only audit trail.  
**Fields:**
- `actor` (email or "system"/"anonymous").
- `action` (enum).
- `detail` (free-form context, max 1000 chars).
- `tokensUsed` (for AI calls).
- `success` (boolean).
- `createdAt` (immutable).

**Why:** Every privileged operation is recorded; never updated or deleted.

---

#### `backend/src/main/java/com/vw/eacontext/admin/model/AiSettings.java`
**Role:** JPA singleton entity — tenant-wide AI governance.  
**Fields:**
- `aiEnabled` (master switch).
- `model` (e.g., "gpt-4o-mini").
- `dailyTokenBudgetPerUser` (0 = unlimited).
- Feature toggles: `summaryEnabled`, `queryEnabled`, `enrichmentEnabled`, etc.

**Singleton:** Always id = 1. Created lazily on first access.

**Why:** Admins control AI spend and feature availability without restarting.

---

#### `backend/src/main/java/com/vw/eacontext/admin/model/AiUsage.java`
**Role:** JPA entity — daily per-user AI token consumption.  
**Fields:**
- `userEmail`, `usageDate` (composite unique constraint).
- `tokensUsed`, `callCount`.

**Method:** `record(tokens)` — increment counters transactionally.

**Why:** Enforces daily quotas; rolls over at midnight UTC.

---

#### `backend/src/main/java/com/vw/eacontext/admin/model/AiFeature.java`
**Role:** Enum linking AI capabilities to feature toggles.  
**Values:** `SUMMARY`, `QUERY`, `ENRICHMENT`, `RECOMMENDATION`, `AGENT`.

**Fields:** display name, toggle predicate, default token cost.

**Why:** Decouples features from settings; easy to add new capabilities.

---

#### `backend/src/main/java/com/vw/eacontext/admin/repository/AuditEntryRepository.java`
**Role:** Spring Data JPA for `AuditEntry` queries.  
**Methods:**
- `findAllByOrderByCreatedAtDesc(Pageable)`.
- `findByActorIgnoreCaseOrderByCreatedAtDesc()`.
- `findByActionInOrderByCreatedAtDesc()`.

---

#### `backend/src/main/java/com/vw/eacontext/admin/repository/AiSettingsRepository.java`
**Role:** Spring Data JPA for the singleton `AiSettings` row.

---

#### `backend/src/main/java/com/vw/eacontext/admin/repository/AiUsageRepository.java`
**Role:** Spring Data JPA for daily token quotas.  
**Key queries:**
- `findByUserEmailAndUsageDate()` — check today's consumption.
- `findByUsageDateOrderByTokensUsedDesc()` — daily leaderboard.

---

#### `backend/src/main/java/com/vw/eacontext/admin/service/AdminUserService.java`
**Role:** User lifecycle (create, invite, re-role, reset password, deactivate, delete).

**Methods:**
- `create(CreateUserRequest)` — new account or invitation.
- `update()`, `changeRole()`, `setActive()`, `resetPassword()`, `delete()`.

**Guards:**
- Cannot demote/deactivate/delete the last active SUPER_ADMIN.
- Generates a cryptographically random temporary password for resets.

**Audits:** USER_CREATED / USER_INVITED / USER_ROLE_CHANGED / USER_PASSWORD_RESET / USER_DELETED.

---

#### `backend/src/main/java/com/vw/eacontext/admin/service/AdminRoleService.java`
**Role:** Role and permission administration.

**Methods:**
- `list()`, `get(name)` — roles with user counts.
- `catalogue()` — permission matrix.
- `updatePermissions()` — replace a role's permission set.
- `create()`, `delete()` — custom roles.

**Guard:** SUPER_ADMIN must always retain `USER_MANAGE` and `ROLE_MANAGE`.

**Audits:** ROLE_PERMISSIONS_UPDATED / ROLE_CREATED / ROLE_DELETED.

---

#### `backend/src/main/java/com/vw/eacontext/admin/service/AiSettingsService.java`
**Role:** Read and update the singleton AI governance row.

**Methods:**
- `get()` — loads or creates the settings.
- `update(AiSettingsRequest)` — persist changes.

**Audits:** AI_SETTINGS_UPDATED.

---

#### `backend/src/main/java/com/vw/eacontext/admin/service/AiGovernanceService.java`
**Role:** Three-gate enforcement: master switch → feature toggle → per-user daily quota.

**Method:** `execute(AiFeature, cost, supplier)` — runs the operation under governance.

**Flow:**
1. Check `aiEnabled` (throw 503 if false).
2. Check feature toggle (throw 503 if false).
3. Reserve daily budget (throw 429 if exceeded).
4. Run the supplier.
5. Audit success or failure.

**Why:** Single choke point; every AI call goes through here.

---

#### `backend/src/main/java/com/vw/eacontext/admin/service/AuditService.java`
**Role:** Write and query the audit trail.

**Methods:**
- `log(action, detail)` — current user, success.
- `log(actor, action, detail)` — explicit actor.
- `logFailure()` — failed operation.
- `logAiCall()` — tokens + feature.
- `recent()`, `byActor()`, `byActions()` — queries with paging.

**Writes:** Run in `Propagation.REQUIRES_NEW` so audit never rolls back the main operation.

---

#### `backend/src/main/java/com/vw/eacontext/admin/dto/UserDto.java`
**Role:** Admin read model for a user (no password hash).

---

#### `backend/src/main/java/com/vw/eacontext/admin/dto/CreateUserRequest.java`
**Role:** Payload for creating or inviting a user.  
**Fields:** `name`, `email`, `password` (optional), `roleName`.

---

#### `backend/src/main/java/com/vw/eacontext/admin/dto/UpdateUserRequest.java`
**Role:** Payload for updating a user.  
**Fields:** `name`, `roleName`, `active`.

---

#### `backend/src/main/java/com/vw/eacontext/admin/dto/RoleDto.java`
**Role:** Admin read model for a role.  
**Fields:** `id`, `name`, `description`, `systemRole`, `permissions`, `userCount`.

---

#### `backend/src/main/java/com/vw/eacontext/admin/dto/UpdateRolePermissionsRequest.java`
**Role:** Payload for re-permissioning a role (authoritative list).

---

#### `backend/src/main/java/com/vw/eacontext/admin/dto/AiSettingsRequest.java`
**Role:** Payload for updating AI settings.

---

#### `backend/src/main/java/com/vw/eacontext/admin/dto/AiSettingsDto.java`
**Role:** Read model for AI settings.

---

#### `backend/src/main/java/com/vw/eacontext/admin/dto/PermissionDto.java`
**Role:** Read model for one permission (admin matrix UI).

---

#### `backend/src/main/java/com/vw/eacontext/admin/dto/AuditEntryDto.java`
**Role:** Read model for one audit entry.

---

#### `backend/src/main/java/com/vw/eacontext/admin/controller/AdminUserController.java`
**Role:** User management endpoints — all gated on `USER_MANAGE`.

**Endpoints:**
- `GET /api/admin/users`
- `POST /api/admin/users`
- `PUT /api/admin/users/{id}`
- `PUT /api/admin/users/{id}/role`
- `PUT /api/admin/users/{id}/active`
- `POST /api/admin/users/{id}/reset-password`
- `DELETE /api/admin/users/{id}`

---

#### `backend/src/main/java/com/vw/eacontext/admin/controller/AdminRoleController.java`
**Role:** Role & permission management endpoints.

**Endpoints:**
- `GET /api/admin/roles` (readable with `ROLE_MANAGE` or `USER_MANAGE`).
- `GET /api/admin/roles/{name}`
- `GET /api/admin/permissions`
- `PUT /api/admin/roles/{name}/permissions` (requires `ROLE_MANAGE`).
- `POST /api/admin/roles` (requires `ROLE_MANAGE`).
- `DELETE /api/admin/roles/{name}` (requires `ROLE_MANAGE`).

---

#### `backend/src/main/java/com/vw/eacontext/admin/controller/AdminAiSettingsController.java`
**Role:** AI governance endpoints.

**Endpoints:**
- `GET /api/admin/ai-settings` (readable with `AI_CONFIG` or `USER_MANAGE`).
- `PUT /api/admin/ai-settings` (requires `AI_CONFIG`).

---

#### `backend/src/main/java/com/vw/eacontext/admin/controller/AdminAuditController.java`
**Role:** Audit trail read-only endpoints (requires `AUDIT_VIEW`).

**Endpoints:**
- `GET /api/admin/audit` (filter by `actor` or `action`).
- `GET /api/admin/audit/ai` (AI activity only).

---

### Backend Exception Files

#### `backend/src/main/java/com/vw/eacontext/exception/TokenQuotaExceededException.java`
**Role:** Thrown when a user exhausts their daily AI token allowance.  
**HTTP Status:** 429 (Too Many Requests).

---

#### `backend/src/main/java/com/vw/eacontext/exception/AiFeatureDisabledException.java`
**Role:** Thrown when an admin disables an AI feature or the master switch.  
**HTTP Status:** 503 (Service Unavailable).

---

### Backend Test Files

#### `backend/src/test/java/com/vw/eacontext/security/DataInitializerTest.java`
**Role:** Verifies the seeder works correctly.  
**Tests:**
- Every permission code is seeded.
- Every role is seeded with its correct default matrix.
- SUPER_ADMIN has all permissions.
- VIEWER has no AI or export rights.
- GUEST sees only the application frame.
- Only SUPER_ADMIN can configure AI.
- Bootstrap admin is created and flagged `mustChangePassword`.

---

#### `backend/src/test/java/com/vw/eacontext/security/RbacEndpointSecurityTest.java`
**Role:** End-to-end RBAC enforcement with security **enabled**.  
**Tests:**
- Unauthenticated requests are rejected (401).
- Login succeeds and returns token + permissions.
- Wrong password returns 401.
- Frame-level diagram access is enforced.
- AI summary is denied to VIEWER.
- Admin console rejects non-admins (403).
- Upload requires `DATA_UPLOAD`.
- Export is checked per format.

---

#### `backend/src/test/java/com/vw/eacontext/admin/AiGovernanceServiceTest.java`
**Role:** Verifies AI governance logic.  
**Tests:**
- Successful call is charged and audited.
- Master switch blocks all features.
- Individual feature toggle blocks only that feature.
- Daily budget is enforced per user.
- Zero budget means unlimited.
- Failed calls are audited as unsuccessful.

---

#### `backend/src/test/resources/application.properties`
**Role:** Test profile configuration (security disabled, H2 in-memory, deterministic seeding).

---

### Backend Modified Files

#### `backend/src/main/java/com/vw/eacontext/api/EaController.java`
**Changes:** Added `@PreAuthorize` to every method:
- `POST /api/upload` → `DATA_UPLOAD`
- `GET /api/graph/{frame}` → `DIAGRAM_VIEW`
- `GET /api/node/{id}/impact` → `ANALYSIS_IMPACT`
- `GET /api/insights` → `ANALYSIS_RISK`
- `GET /api/summary` → `AI_SUMMARY`
- `GET /api/export` → `EXPORT_PNG` or `EXPORT_PDF` or `EXPORT_PPTX`

---

#### `backend/src/main/java/com/vw/eacontext/api/EaContextService.java`
**Changes:**
- Added `FramePermissionEvaluator` injection.
- `graph(frame)` now calls `framePermissions.check(frame)` (per-frame authorization).
- Added `AiGovernanceService` injection.
- `summary()` now wrapped in `aiGovernance.execute()` (quota + toggle enforcement).
- Added `AuditService` injection.
- `upload()` logs `DATA_UPLOADED` / `DATA_UPLOAD_FAILED` to audit trail.
- `export()` logs `EXPORT_GENERATED` to audit trail.
- Added `checkExportPermission()` (per-format checks).

---

#### `backend/src/main/java/com/vw/eacontext/api/SampleDataInitializer.java`
**Changes:** Added `@Order(10)` so it runs after `DataInitializer` (order 0). RBAC must be seeded first.

---

#### `backend/src/main/java/com/vw/eacontext/exception/GlobalExceptionHandler.java`
**Changes:** Added handlers for:
- `TokenQuotaExceededException` → 429 (Too Many Requests).
- `AiFeatureDisabledException` → 503 (Service Unavailable).
- `HttpRequestMethodNotSupportedException` → 405 (Method Not Allowed).
- `HttpMediaTypeNotSupportedException` → 415 (Unsupported Media Type).
- `HttpMessageNotReadableException` → 400 (Bad Request).

**Why:** Malformed requests were returning 500; now return proper HTTP codes.

---

#### `backend/pom.xml`
**Changes:** Added RBAC + AI governance dependencies:
- `spring-boot-starter-security`
- `spring-boot-starter-data-jpa`
- `h2` (dev database)
- `postgresql` (production database)
- `jjwt-api`, `jjwt-impl`, `jjwt-jackson` (JWT token signing/verification)

---

#### `backend/src/main/resources/application.yml`
**Changes:** Added RBAC + AI governance configuration:
- `spring.datasource.*` — H2 in-memory by default (override for PostgreSQL).
- `spring.jpa.hibernate.ddl-auto` — `update` by default (set `validate` in prod).
- `contexa.security.*` — JWT secret, expiry, issuer.
- `contexa.seed.*` — bootstrap admin email/name/password.

---

---

## Frontend Files Added

### Auth Layer

#### `frontend/src/auth/AuthContext.jsx`
**Role:** React context for authentication state and hooks.

**Exports:**
- `AuthProvider` — wraps app, stores user in `localStorage`.
- `useAuth()` hook — access `{ user, login, logout, refresh, can, canAny, isAuthenticated, loading, error }`.

**Methods:**
- `login(email, password)` → `LoginResponse` (token stored in localStorage).
- `logout()` → clears localStorage.
- `refresh()` → re-reads permissions from `/api/auth/me` (used after admin changes).
- `can(permission)` → boolean.
- `canAny(permissions)` → boolean.

---

#### `frontend/src/auth/RequirePermission.jsx`
**Role:** Component that conditionally renders children based on permissions.

**Props:**
- `perm` — single required permission.
- `anyOf` — array of permissions (logical OR).
- `fallback` — rendered when not permitted.
- `children`.

**Why:** Purely cosmetic; backend enforces all rules with `@PreAuthorize`.

---

#### `frontend/src/services/authApi.js`
**Role:** HTTP calls for auth endpoints.

**Functions:**
- `login(email, password)` → `LoginResponse`.
- `getMe()` → caller's identity.
- `changePassword(current, new)` → void.
- `logout()` → clears localStorage.

---

#### `frontend/src/services/adminApi.js`
**Role:** HTTP calls for admin console endpoints.

**Namespaces:**
- **Users:** `listUsers()`, `createUser()`, `updateUser()`, `changeUserRole()`, `setUserActive()`, `resetUserPassword()`, `deleteUser()`.
- **Roles:** `listRoles()`, `updateRolePermissions()`, `listPermissions()`.
- **AI:** `getAiSettings()`, `updateAiSettings()`.
- **Audit:** `getAuditLog()`, `getAiAuditLog()`.

---

#### `frontend/src/pages/LoginPage.jsx`
**Role:** Credential form shown when unauthenticated.

**Features:**
- Email + password inputs.
- Calls `useAuth().login()`.
- Shows 401 errors.
- "Signing in…" state.

---

#### `frontend/src/pages/LoginPage.css`
**Role:** Styling for the login page (dark theme matching the app).

---

#### `frontend/src/pages/ContexaAdmin.jsx`
**Role:** Multi-tab admin console for users, roles, AI settings, audit.

**Tabs:**
- **Users** (requires `USER_MANAGE`) — list, create, invite, re-role, reset password, delete.
- **Roles** (requires `ROLE_MANAGE`) — permission matrix checkbox grid.
- **AI Settings** (requires `AI_CONFIG`) — master switch, model, budget, feature toggles.
- **Audit** (requires `AUDIT_VIEW`) — filter by actor, view all events with tokens/success.

**Guard:** Only visible to admins; each tab gated independently.

---

#### `frontend/src/pages/ContexaAdmin.css`
**Role:** Styling for the admin console (tables, forms, permission matrix).

---

### Frontend Modified Files

#### `frontend/src/main.jsx`
**Changes:** Wrapped `<App />` in `<AuthProvider>`.

---

#### `frontend/src/App.jsx`
**Changes:**
- Import `useAuth()`, `LoginPage`, `ContexaAdmin`, `RequirePermission`.
- If not authenticated, render `LoginPage` (full page).
- If `showAdmin`, render `ContexaAdmin` (full page).
- Compute `firstAllowedFrame` based on user's permissions.
- Header now shows user name/role, admin link (if eligible), logout button.
- Pass permission-gated frame list to `FrameTabs`.
- Conditionally enable `useInsights` and `useSummary` based on permissions.
- Wrap `<ExportButton>` in `<RequirePermission anyOf={['EXPORT_PNG', 'EXPORT_PDF', 'EXPORT_PPTX']}>`.
- Show read-only note if user cannot upload.
- Setup session-expiry listener on `contexa:unauthenticated` event.

---

#### `frontend/src/services/api.js`
**Changes:**
- Added `TOKEN_KEY = 'contexa_token'` and `USER_KEY = 'contexa_user'` exports.
- Request interceptor: attach bearer token to every request.
- Response interceptor: on 401 (not login), clear session and dispatch `contexa:unauthenticated` event.

---

#### `frontend/src/components/FrameTabs.jsx`
**Changes:**
- Now a controlled component (prop `activeFrame`, `onFrameChange`).
- New prop `allowedFrames` — array of frame slugs the user may view.
- Frames not in `allowedFrames` are hidden (but backend still rejects them with 403).
- If no frames allowed, show "No diagram frames are available for your role."

---

#### `frontend/src/components/InsightsPanel.jsx`
**Changes:**
- New props `canUseAiSummary` and `canSeeFindings`.
- If `!canUseAiSummary`, show "AI summaries are not enabled for your role."
- If `!canSeeFindings`, show "Risk analysis is not enabled for your role."
- New function `summaryErrorMessage()` — maps HTTP status to user messages:
  - 429 → "Your daily AI token budget is exhausted."
  - 503 → "AI features are currently disabled by an administrator."
  - 403 → "AI summaries are not enabled for your role."

---

#### `frontend/src/hooks/useSummary.js`
**Changes:** New optional prop `enabled` (default true). When false, skips the API call and returns empty state.

---

#### `frontend/src/hooks/useInsights.js`
**Changes:** New optional prop `enabled` (default true). When false, skips the API call and returns empty state.

---

#### `frontend/src/App.css`
**Changes:** Added header action styles:
- `.app-header-actions` — flex row for admin link, user label, logout button.
- `.admin-link`, `.logout-btn` — hover states.
- `.app-user` — email + role display.
- `.panel-note` — "You have read-only access" message.
- `.frame-tabs--empty` — shown when user has no frame permissions.

---

### New Frontend Scripts

#### `frontend/scripts/syntax-check.mjs`
**Role:** Standalone Babel-based syntax checker (workaround for Node 18 on Vite 8).

**Usage:** `node scripts/syntax-check.mjs` — validates all `.js`/`.jsx` files parse cleanly.

---

### Frontend Modified Config

#### `frontend/package.json`
**Changes:** Added `"syntax-check": "node scripts/syntax-check.mjs"` to scripts.

---

---

## Summary Table

| Layer | Count | Purpose |
|---|---|---|
| **Security Models** | 4 entities | `AppUser`, `Role`, `Permission`, enums |
| **Security Services** | 5 services | JWT, auth, current user, frame eval, seeding |
| **Security Controllers** | 1 controller | Login / identity / password |
| **Security Config** | 5 classes | JWT filter, error handlers, props, configs |
| **Admin Models** | 4 entities | `AuditEntry`, `AiSettings`, `AiUsage`, `AiFeature` |
| **Admin Services** | 4 services | User mgmt, role mgmt, AI settings, audit, governance |
| **Admin Controllers** | 4 controllers | Users, roles, AI settings, audit |
| **Admin DTOs** | 8 DTOs | Request/response records |
| **Exceptions** | 2 new | `TokenQuotaExceededException`, `AiFeatureDisabledException` |
| **Tests** | 3 new | Data seeder, RBAC endpoints, AI governance |
| **Frontend Auth** | 5 components | `AuthContext`, `LoginPage`, `ContexaAdmin`, `RequirePermission`, service |
| **Frontend Modified** | 7 files | `App.jsx`, `main.jsx`, `api.js`, `FrameTabs`, `InsightsPanel`, hooks, styles |
| **Backend Modified** | 4 files | Controllers, services, config, tests |

**Total new files:** ~60  
**Total modified files:** ~15  
**Test coverage:** 75 tests passing (46 legacy + 29 RBAC-specific).

---

## How Files Work Together

### Authentication Flow
1. User submits credentials to `LoginPage`.
2. `AuthContext.login()` calls `authApi.login()` → `POST /api/auth/login`.
3. Backend: `AuthController.login()` → `AuthService.login()` → `JwtService.issue()`.
4. Token (containing permissions) returned to frontend.
5. `AuthProvider` stores token + user in `localStorage`.
6. `api.js` interceptor attaches token to every request.
7. Backend: `JwtAuthFilter` reads token → populates `SecurityContextHolder`.

### Authorization Flow
1. Request hits controller method with `@PreAuthorize("hasAuthority('PERMISSION')")`.
2. `SecurityConfig` intercepts; `@EnableMethodSecurity` interprets the annotation.
3. Current user's authorities (from JWT) are checked against the required authority.
4. If mismatch: `SecurityErrorHandlers.handle()` → 403 JSON response.
5. If OK: method runs, may call `CurrentUserService` for finer checks (frames, export formats).

### AI Governance Flow
1. User calls an AI endpoint (e.g., `GET /api/summary`).
2. Controller method has `@PreAuthorize("hasAuthority('AI_SUMMARY')")` (permission check).
3. Service layer calls `AiGovernanceService.execute(feature, cost, operation)`.
4. Governance checks: (1) master `aiEnabled`, (2) feature toggle, (3) daily quota.
5. If any gate fails: throw 503 or 429; `AuditService.logAiCall(..., false)`.
6. If OK: run operation, then `AuditService.logAiCall(..., true)`.

### Admin Console Flow
1. Admin navigates to `Contexa Admin` (link in header).
2. `ContexaAdmin` renders tabs based on `useAuth().can()` (UX only).
3. Each tab calls admin APIs (e.g., `listUsers()` → `GET /api/admin/users`).
4. Backend controllers gate the endpoint with `@PreAuthorize` (enforcement).
5. Services read/write DB, audit every change.
6. Frontend re-fetches and re-renders.

---

## Environment Configuration

### Required Environment Variables (Production)
```bash
CONTEXA_JWT_SECRET=<min 32 chars>
CONTEXA_SUPERADMIN_EMAIL=admin@company.com
CONTEXA_SUPERADMIN_PASSWORD=<strong-password>
CONTEXA_DB_URL=jdbc:postgresql://localhost:5432/contexa
CONTEXA_DB_USER=contexa
CONTEXA_DB_PASSWORD=<db-password>
```

### Optional Overrides
```bash
CONTEXA_DB_DRIVER=org.postgresql.Driver
CONTEXA_DB_DDL=validate
CONTEXA_JWT_EXPIRY_MS=86400000
CONTEXA_SEED_ENABLED=true
CONTEXA_SECURITY_ENABLED=true
```

---

## Testing Notes

- **Backend:** Run `mvn test` — all 75 tests pass (46 legacy EA tests + 29 RBAC tests).
- **Frontend:** Run `npm run syntax-check` — all JSX files parse cleanly (Babel-based, works on Node 18).
- **Full build:** Requires Node 22.13.0+ due to Vite/ESLint engine constraints.

---

**End of File Guide**

