/**
 * Standalone syntax check for the frontend sources.
 *
 * The project targets Vite 8 / ESLint 10, which both require Node >= 20.19.
 * On older Node this script still parses every .js/.jsx file with Babel so
 * syntax errors are caught without a full build.
 *
 * Usage: node scripts/syntax-check.mjs
 */
import { parse } from '@babel/parser'
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, extname } from 'node:path'

const ROOT = new URL('../src', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')

/** Recursively collects .js/.jsx files under a directory. */
function collect(dir) {
  return readdirSync(dir).flatMap((entry) => {
    const full = join(dir, entry)
    if (statSync(full).isDirectory()) return collect(full)
    return ['.js', '.jsx'].includes(extname(full)) ? [full] : []
  })
}

let failures = 0
for (const file of collect(ROOT)) {
  try {
    parse(readFileSync(file, 'utf8'), {
      sourceType: 'module',
      plugins: ['jsx'],
    })
  } catch (err) {
    failures += 1
    console.error(`✗ ${file}\n  ${err.message}\n`)
  }
}

if (failures === 0) {
  console.log('✓ All frontend sources parse cleanly.')
} else {
  console.error(`${failures} file(s) failed to parse.`)
  process.exit(1)
}

