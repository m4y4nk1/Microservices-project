import { useEffect, useState } from 'react'
import { getInsights } from '../services/api'

/**
 * Fetches insight findings from getInsights(). Re-fetches when `refreshKey`
 * changes (e.g. after a new dataset upload).
 *
 * @param {unknown} [refreshKey] - Change this to trigger a re-fetch.
 * @param {boolean} [enabled] - Set false to skip the call entirely (e.g. the
 *   user lacks ANALYSIS_RISK), avoiding a pointless 403.
 * @returns {{ findings: Array<object>, loading: boolean, error: unknown }}
 */
export function useInsights(refreshKey, enabled = true) {
  const [findings, setFindings] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!enabled) {
      setFindings([])
      setError(null)
      setLoading(false)
      return undefined
    }

    let cancelled = false
    setLoading(true)
    setError(null)

    getInsights()
      .then((data) => {
        if (cancelled) return
        setFindings(Array.isArray(data) ? data : [])
      })
      .catch((err) => {
        if (cancelled) return
        setError(err)
        setFindings([])
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [refreshKey, enabled])

  return { findings, loading, error }
}

