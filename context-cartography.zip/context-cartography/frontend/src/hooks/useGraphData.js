import { useEffect, useState } from 'react'
import { getGraph } from '../services/api'
import { toCytoscapeElements } from '../services/graphAdapter'

/**
 * Fetches the graph projection for the given frame and converts it to
 * Cytoscape elements. Re-fetches whenever the frame or `refreshKey` changes.
 *
 * @param {string} frame - The active observation frame slug.
 * @param {unknown} [refreshKey] - Change this to force a re-fetch (e.g. after upload).
 * @returns {{ elements: Array<object>, loading: boolean, error: unknown }}
 */
export function useGraphData(frame, refreshKey) {
  const [elements, setElements] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!frame) return undefined

    let cancelled = false
    setLoading(true)
    setError(null)

    getGraph(frame)
      .then((graph) => {
        if (cancelled) return
        setElements(toCytoscapeElements(graph))
      })
      .catch((err) => {
        if (cancelled) return
        setError(err)
        setElements([])
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })

    // Ignore the result of an in-flight request if the frame changes again.
    return () => {
      cancelled = true
    }
  }, [frame, refreshKey])

  return { elements, loading, error }
}

