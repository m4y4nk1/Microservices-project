import './FilterPanel.css'

/** Lifecycle options (value = backend enum name, label = friendly text). */
const LIFECYCLE_OPTIONS = [
  { value: 'ACTIVE', label: 'Active' },
  { value: 'DEPRECATED', label: 'Deprecated' },
  { value: 'EOL', label: 'EOL' },
  { value: 'PLANNED', label: 'Planned' },
]

/** The empty/default filter state. */
export const EMPTY_FILTERS = {
  domain: '',
  lifecycle: '',
  gapOnly: false,
  eolOnly: false,
  search: '',
}

/**
 * Left-panel filter controls, ported from the prototype: domain dropdown,
 * lifecycle dropdown, ownership-gap & EOL checkboxes, search box and reset.
 * Filtering only applies to the application frame (as in the prototype), so the
 * controls are disabled elsewhere.
 *
 * @param {object} props
 * @param {typeof EMPTY_FILTERS} props.filters - Current filter values.
 * @param {(filters: typeof EMPTY_FILTERS) => void} props.onChange - Emits the next filter state.
 * @param {() => void} props.onReset - Clears all filters.
 * @param {string[]} [props.domains] - Available domain names for the dropdown.
 * @param {boolean} [props.disabled] - Disable controls (non-application frames).
 */
function FilterPanel({ filters, onChange, onReset, domains = [], disabled = false }) {
  const update = (key, value) => onChange({ ...filters, [key]: value })

  return (
    <div className="filter-panel" aria-disabled={disabled}>
      <h3 className="filter-label">Filter by Domain</h3>
      <select
        className="filter-input"
        value={filters.domain}
        disabled={disabled}
        onChange={(e) => update('domain', e.target.value)}
      >
        <option value="">All domains</option>
        {domains.map((d) => (
          <option key={d} value={d}>
            {d}
          </option>
        ))}
      </select>

      <h3 className="filter-label">Filter by Lifecycle</h3>
      <select
        className="filter-input"
        value={filters.lifecycle}
        disabled={disabled}
        onChange={(e) => update('lifecycle', e.target.value)}
      >
        <option value="">All statuses</option>
        {LIFECYCLE_OPTIONS.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>

      <h3 className="filter-label">Quick Issue Filters</h3>
      <label className="filter-check">
        <input
          type="checkbox"
          checked={filters.gapOnly}
          disabled={disabled}
          onChange={(e) => update('gapOnly', e.target.checked)}
        />
        Ownership gaps only
      </label>
      <label className="filter-check">
        <input
          type="checkbox"
          checked={filters.eolOnly}
          disabled={disabled}
          onChange={(e) => update('eolOnly', e.target.checked)}
        />
        EOL / Deprecated only
      </label>

      <h3 className="filter-label">Search</h3>
      <input
        type="text"
        className="filter-input"
        placeholder="Type an app name…"
        value={filters.search}
        disabled={disabled}
        onChange={(e) => update('search', e.target.value)}
      />

      <button
        type="button"
        className="filter-reset"
        disabled={disabled}
        onClick={onReset}
      >
        ↺ Reset view
      </button>
    </div>
  )
}

export default FilterPanel

