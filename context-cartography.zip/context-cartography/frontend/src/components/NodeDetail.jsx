import './NodeDetail.css'

/**
 * Human-readable labels for the issue classes carried on a node.
 * @see services/insightAdapter.js (gap / eol / spof)
 */
const BADGES = {
  gap: { label: 'Ownership gap', className: 'badge--gap' },
  eol: { label: 'Lifecycle risk', className: 'badge--eol' },
  spof: { label: 'Single point of failure', className: 'badge--spof' },
}

/**
 * A single label/value row, rendered only when the value is present.
 */
function DetailRow({ label, value }) {
  if (value === null || value === undefined || value === '') return null
  return (
    <div className="detail-row">
      <span className="detail-key">{label}</span>
      <span className="detail-val">{value}</span>
    </div>
  )
}

/**
 * Shows the selected node's details and issue badges, populated from the node
 * data emitted by GraphCanvas' onNodeSelect. Renders a placeholder when nothing
 * is selected.
 *
 * @param {object} props
 * @param {object | null} [props.node] - Selected node data (id, label, type,
 *   domain, owner, lifecycleStatus, techStack, connections, ...).
 * @param {string} [props.issueClasses] - Space-separated issue classes for the
 *   selected node (e.g. "gap eol"), used to render badges.
 */
function NodeDetail({ node, issueClasses = '' }) {
  if (!node) {
    return (
      <div className="node-detail node-detail--empty">
        Click a node to inspect its details and blast radius.
      </div>
    )
  }

  const badges = issueClasses
    .split(' ')
    .filter((cls) => BADGES[cls])

  return (
    <div className="node-detail">
      <div className="node-detail-title">{node.label ?? node.id}</div>

      <DetailRow label="Domain" value={node.domain} />
      <DetailRow label="Owner" value={node.owner} />
      <DetailRow label="Lifecycle" value={node.lifecycleStatus} />
      <DetailRow label="Tech" value={node.techStack} />
      <DetailRow
        label="Connections"
        value={
          typeof node.connections === 'number'
            ? `${node.connections} (blast radius)`
            : undefined
        }
      />

      {badges.length > 0 && (
        <div className="node-detail-badges">
          {badges.map((cls) => (
            <span key={cls} className={`badge ${BADGES[cls].className}`}>
              {BADGES[cls].label}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

export default NodeDetail

