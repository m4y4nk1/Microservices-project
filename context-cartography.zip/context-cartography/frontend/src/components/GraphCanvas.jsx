import { useEffect, useRef } from 'react'
import cytoscape from 'cytoscape'
import { getNodeImpact } from '../services/api'
import { ISSUE_CLASSES } from '../services/insightAdapter'
import './GraphCanvas.css'

/**
 * Cytoscape stylesheet ported from the vanilla prototype (baseStyle()).
 * Nodes are rounded rectangles colored by domain; edges are directed with
 * triangle arrowheads. Extra selectors cover dim/highlight/issue rings and
 * the domain / process frame node variants.
 */
function baseStyle() {
  return [
    {
      selector: 'node',
      style: {
        'background-color': 'data(color)',
        label: 'data(label)',
        color: '#fff',
        'text-valign': 'center',
        'text-halign': 'center',
        'font-size': '10px',
        'font-weight': '600',
        'text-wrap': 'wrap',
        'text-max-width': '90px',
        width: '95px',
        height: '46px',
        shape: 'round-rectangle',
        'border-width': 2,
        'border-color': '#fff',
        'text-outline-width': 0,
      },
    },
    { selector: 'node[sub]', style: { 'font-size': '8px' } },
    { selector: '.dim', style: { opacity: 0.15 } },
    { selector: '.hi', style: { 'border-width': 4, 'border-color': '#ffd23f' } },
    {
      selector: '.spof',
      style: { 'border-width': 4, 'border-color': '#ffd23f', 'border-style': 'dashed' },
    },
    { selector: '.gap', style: { 'border-color': '#e0a95c', 'border-width': 4 } },
    {
      selector: '.eol',
      style: { 'border-color': '#c0504d', 'border-width': 4, 'border-style': 'dashed' },
    },
    {
      selector: 'edge',
      style: {
        width: 2,
        'line-color': '#9aa7a5',
        'target-arrow-color': '#9aa7a5',
        'target-arrow-shape': 'triangle',
        'curve-style': 'bezier',
        'arrow-scale': 1,
      },
    },
    {
      selector: 'edge.legacy',
      style: {
        'line-color': '#c0504d',
        'target-arrow-color': '#c0504d',
        'line-style': 'dashed',
      },
    },
    {
      selector: 'edge.hi',
      style: {
        width: 4,
        'line-color': '#0E4A47',
        'target-arrow-color': '#0E4A47',
        'z-index': 99,
      },
    },
    { selector: 'edge.dim', style: { opacity: 0.08 } },
    // Impact / blast-radius highlighting (from getNodeImpact):
    // incoming provider edges (upstream -> origin) vs outgoing consumer edges.
    {
      selector: 'edge.impact-in',
      style: {
        width: 4,
        'line-color': '#2f77b4',
        'target-arrow-color': '#2f77b4',
        'z-index': 99,
      },
    },
    {
      selector: 'edge.impact-out',
      style: {
        width: 4,
        'line-color': '#e07b39',
        'target-arrow-color': '#e07b39',
        'z-index': 99,
      },
    },
    {
      selector: 'node.impact-origin',
      style: { 'border-width': 5, 'border-color': '#0E4A47' },
    },
    {
      selector: 'node[type="process"]',
      style: {
        'background-color': '#0E4A47',
        shape: 'round-rectangle',
        width: '120px',
        height: '40px',
        'font-size': '11px',
      },
    },
    {
      selector: 'node[type="domain"]',
      style: {
        width: '130px',
        height: '70px',
        'font-size': '13px',
        'font-weight': '700',
      },
    },
  ]
}

/**
 * Layout configuration per frame, ported from the prototype (layoutFor()).
 * @param {string} frame - The active observation frame.
 */
function layoutFor(frame) {
  if (frame === 'domain') return { name: 'circle', padding: 40 }
  if (frame === 'process') {
    return { name: 'breadthfirst', directed: true, padding: 30, spacingFactor: 1.15 }
  }
  return { name: 'cose', padding: 30, nodeRepulsion: 9000, idealEdgeLength: 110, animate: false }
}

/** CSS classes used for the transient impact/selection highlight. */
const HIGHLIGHT_CLASSES = 'dim impact-in impact-out impact-origin'

/** Removes any active blast-radius highlight from the graph. */
function clearHighlight(cy) {
  cy.elements().removeClass(HIGHLIGHT_CLASSES)
}

/**
 * Highlights the blast radius returned by getNodeImpact(): dims everything,
 * un-dims affected nodes, and colors incoming (provider) edges differently
 * from outgoing (consumer) edges relative to the origin.
 *
 * @param {object} cy - The Cytoscape instance.
 * @param {string} originId - The tapped node id.
 * @param {object} result - The ImpactAnalysisResult from the backend.
 */
function applyImpactHighlight(cy, originId, result) {
  const affected = result?.affected ?? []
  const upstream = new Set(result?.upstream ?? [])
  const downstream = new Set(result?.downstream ?? [])

  cy.batch(() => {
    cy.elements().addClass('dim')

    cy.getElementById(originId).removeClass('dim').addClass('impact-origin')
    for (const id of affected) {
      cy.getElementById(id).removeClass('dim')
    }

    for (const edge of result?.edges ?? []) {
      const el = cy.getElementById(edge.id)
      if (el.empty()) continue
      el.removeClass('dim')
      // Incoming: provider feeds the origin (or the upstream chain).
      const incoming = upstream.has(edge.source) && (edge.target === originId || upstream.has(edge.target))
      // Outgoing: origin feeds a consumer (or the downstream chain).
      const outgoing = downstream.has(edge.target) && (edge.source === originId || downstream.has(edge.source))
      el.addClass(incoming ? 'impact-in' : outgoing ? 'impact-out' : 'impact-out')
    }
  })
}

/**
/** Fallback highlight for frames whose node ids are not applications (domain /
 * process). Dims everything except the tapped node's closed neighborhood.
 */
function applyNeighborhoodHighlight(cy, node) {
  cy.batch(() => {
    cy.elements().addClass('dim')
    node.closedNeighborhood().removeClass('dim')
    node.addClass('impact-origin')
    node.connectedEdges().removeClass('dim').addClass('impact-out')
  })
}

/**
 * Client-side filtering ported from the prototype's applyFilters(): hides
 * non-matching application nodes and any edge with a hidden endpoint. Only the
 * application frame is filterable; other frames are left fully visible.
 *
 * @param {object} cy - The Cytoscape instance.
 * @param {string} frame - The active frame.
 * @param {object} [filters] - { domain, lifecycle, gapOnly, eolOnly, search }.
 */
function applyFilters(cy, frame, filters = {}) {
  const { domain, lifecycle, gapOnly, eolOnly, search } = filters

  cy.batch(() => {
    if (frame !== 'application') {
      cy.elements().style('display', 'element')
      return
    }

    const q = (search ?? '').trim().toLowerCase()
    cy.nodes().forEach((n) => {
      const d = n.data()
      let show = true
      if (domain && d.domain !== domain) show = false
      if (lifecycle && d.lifecycleStatus !== lifecycle) show = false
      if (gapOnly && d.owner) show = false
      if (eolOnly && !(d.lifecycleStatus === 'EOL' || d.lifecycleStatus === 'DEPRECATED')) {
        show = false
      }
      if (q && !(d.label ?? '').toLowerCase().includes(q)) show = false
      n.style('display', show ? 'element' : 'none')
    })

    cy.edges().forEach((e) => {
      const source = cy.getElementById(e.data('source'))
      const target = cy.getElementById(e.data('target'))
      const visible = source.style('display') !== 'none' && target.style('display') !== 'none'
      e.style('display', visible ? 'element' : 'none')
    })
  })
}

/**
 * Renders an interactive Cytoscape graph.
 *
 * @param {object} props
 * @param {Array<object>} props.elements - Cytoscape elements (nodes + edges).
 * @param {string} props.frame - The active frame, used to pick the layout.
 * @param {boolean} [props.loading] - Whether a graph fetch is in progress.
 * @param {unknown} [props.error] - Error from the graph fetch, if any.
 * @param {Record<string, string>} [props.nodeClasses] - Map of node id -> issue
 *   class string (e.g. "gap eol") for highlighting ownership gaps, EOL and SPOF nodes.
 * @param {object} [props.filters] - Client-side filter state
 *   ({ domain, lifecycle, gapOnly, eolOnly, search }) applied to the application frame.
 * @param {(node: object | null) => void} [props.onNodeSelect] - Called with the
 *   selected node's data on tap, or null when the selection is cleared.
 * @param {(cy: object | null) => void} [props.onReady] - Called with the Cytoscape
 *   instance once initialized (and null on unmount), e.g. for PNG export.
 */
function GraphCanvas({
  elements = [],
  frame = 'application',
  loading = false,
  error = null,
  nodeClasses = {},
  filters,
  onNodeSelect,
  onReady,
}) {
  const containerRef = useRef(null)
  const cyRef = useRef(null)
  // Guards against stale async getNodeImpact() responses.
  const impactTokenRef = useRef(0)
  // Keep the latest callbacks/frame without forcing the graph to re-init.
  const handlersRef = useRef({ onNodeSelect, frame, onReady })
  handlersRef.current = { onNodeSelect, frame, onReady }

  // Initialize Cytoscape once, tear it down on unmount.
  useEffect(() => {
    const cy = cytoscape({
      container: containerRef.current,
      elements: [],
      style: baseStyle(),
      wheelSensitivity: 0.2,
    })
    cyRef.current = cy
    handlersRef.current.onReady?.(cy)

    cy.on('tap', 'node', (e) => {
      const node = e.target
      const id = node.id()
      const { onNodeSelect: onSelect, frame: activeFrame } = handlersRef.current

      // Emit the node data enriched with its connection count (graph degree).
      onSelect?.({ ...node.data(), connections: node.degree(false) })
      clearHighlight(cy)

      // Applications resolve a real blast radius from the backend; other frames
      // (domain / process) fall back to a local neighborhood highlight.
      if (activeFrame === 'application') {
        const token = (impactTokenRef.current += 1)
        getNodeImpact(id)
          .then((result) => {
            if (token !== impactTokenRef.current || cyRef.current !== cy) return
            applyImpactHighlight(cy, id, result)
          })
          .catch(() => {
            if (token === impactTokenRef.current) applyNeighborhoodHighlight(cy, node)
          })
      } else {
        applyNeighborhoodHighlight(cy, node)
      }
    })

    cy.on('tap', (e) => {
      if (e.target !== cy) return
      // Background click: invalidate any pending impact request and reset.
      impactTokenRef.current += 1
      clearHighlight(cy)
      handlersRef.current.onNodeSelect?.(null)
    })

    return () => {
      handlersRef.current.onReady?.(null)
      cy.destroy()
      cyRef.current = null
    }
  }, [])

  // Re-render elements and re-run the layout whenever elements or frame change.
  useEffect(() => {
    const cy = cyRef.current
    if (!cy) return

    // A new projection clears any active selection/highlight.
    impactTokenRef.current += 1
    handlersRef.current.onNodeSelect?.(null)

    cy.batch(() => {
      cy.elements().remove()
      cy.add(elements)
    })
    cy.layout(layoutFor(frame)).run()
  }, [elements, frame])

  // Apply issue-highlight rings (gap / eol / spof) from insight findings.
  // Runs after the elements effect above, and again when the map changes.
  useEffect(() => {
    const cy = cyRef.current
    if (!cy) return

    cy.batch(() => {
      // Clear any stale rings first.
      cy.nodes().removeClass(ISSUE_CLASSES.join(' '))
      for (const [id, classes] of Object.entries(nodeClasses)) {
        if (classes) cy.getElementById(id).addClass(classes)
      }
    })
  }, [elements, nodeClasses])

  // Apply client-side filters (hide non-matching nodes/edges). Runs after the
  // elements effect, and again when filters or the frame change.
  useEffect(() => {
    const cy = cyRef.current
    if (!cy) return
    applyFilters(cy, frame, filters)
  }, [elements, frame, filters])

  return (
    <div className="graph-canvas-wrap">
      <div ref={containerRef} className="graph-canvas-cy" />

      {loading && (
        <div className="graph-canvas-loading" role="status" aria-live="polite">
          <span className="graph-canvas-spinner" aria-hidden="true" />
          <span>Loading graph…</span>
        </div>
      )}

      {!loading && error && (
        <div className="graph-canvas-state graph-canvas-state--error" role="alert">
          <span className="graph-canvas-state-icon" aria-hidden="true">⚠</span>
          <p className="graph-canvas-state-title">Couldn’t load the graph</p>
          <p className="graph-canvas-state-text">
            Is the backend running at <code>localhost:8080</code>? Try uploading a dataset.
          </p>
        </div>
      )}

      {!loading && !error && elements.length === 0 && (
        <div className="graph-canvas-state" role="status">
          <span className="graph-canvas-state-icon" aria-hidden="true">◍</span>
          <p className="graph-canvas-state-title">Nothing to display</p>
          <p className="graph-canvas-state-text">
            No elements in this frame. Upload a dataset or switch frames.
          </p>
        </div>
      )}
    </div>
  )
}

export default GraphCanvas

