import './InsightsPanel.css'

/**
 * Detected-issue categories, in display order. Each maps a backend FindingType
 * to a friendly label and a colored row variant (ported from the prototype's
 * .stat.gap / .eol / .spof / .ok rows).
 */
const ISSUE_CATEGORIES = [
  { type: 'OWNERSHIP_GAP', label: 'Ownership gaps', variant: 'gap' },
  { type: 'LIFECYCLE_RISK', label: 'Lifecycle risks (EOL/Deprecated)', variant: 'eol' },
  { type: 'DEPENDENCY_HOTSPOT', label: 'Single points of failure', variant: 'spof' },
  { type: 'MISSING_PROCESS_MAPPING', label: 'Missing process mapping', variant: 'ok' },
  { type: 'ORPHAN_INTERFACE', label: 'Orphan interfaces', variant: 'orphan' },
]

/**
 * Right-panel insights, ported from the prototype: an AI summary box plus a
 * detected-issues list with colored rows. Populated from the backend
 * getSummary() and getInsights() calls instead of computing locally.
 *
 * @param {object} props
 * @param {string} [props.summary] - Natural-language summary text.
 * @param {boolean} [props.summaryLoading] - Whether the summary is loading.
 * @param {unknown} [props.summaryError] - Error from the summary fetch, if any.
 * @param {Array<{type: string}>} [props.findings] - Insight findings.
 * @param {boolean} [props.findingsLoading] - Whether the findings are loading.
 * @param {unknown} [props.findingsError] - Error from the findings fetch, if any.
 * @param {boolean} [props.canUseAiSummary] - Whether the user holds AI_SUMMARY.
 * @param {boolean} [props.canSeeFindings] - Whether the user holds ANALYSIS_RISK.
 */
function InsightsPanel({
  summary,
  summaryLoading = false,
  summaryError = null,
  findings = [],
  findingsLoading = false,
  findingsError = null,
  canUseAiSummary = true,
  canSeeFindings = true,
}) {
  // Tally findings by category.
  const counts = findings.reduce((acc, f) => {
    if (f?.type) acc[f.type] = (acc[f.type] ?? 0) + 1
    return acc
  }, {})

  return (
    <div className="insights-content">
      <h3 className="insights-label">AI Summary</h3>
      <div className="ai-box">
        {!canUseAiSummary ? (
          <span className="ai-box-muted">
            AI summaries are not enabled for your role.
          </span>
        ) : summaryLoading ? (
          <span className="ai-box-loading">
            <span className="ai-box-spinner" aria-hidden="true" />
            Generating summary…
          </span>
        ) : summaryError ? (
          <span className="ai-box-error">{summaryErrorMessage(summaryError)}</span>
        ) : summary ? (
          summary
        ) : (
          <span className="ai-box-muted">No summary available.</span>
        )}
      </div>

      <h3 className="insights-label">Detected Issues</h3>
      {!canSeeFindings ? (
        <div className="stat-muted">Risk analysis is not enabled for your role.</div>
      ) : findingsLoading ? (
        <div className="stat-muted">
          <span className="ai-box-spinner" aria-hidden="true" /> Analyzing landscape…
        </div>
      ) : findingsError ? (
        <div className="stat-error">Couldn’t load insights.</div>
      ) : (
        <div className="stat-list">
          {ISSUE_CATEGORIES.map(({ type, label, variant }) => (
            <div key={type} className={`stat-row stat-row--${variant}`}>
              <span>{label}</span>
              <b>{counts[type] ?? 0}</b>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

/**
 * Turns an AI summary failure into an actionable message: quota exhaustion and
 * administrator-disabled AI have dedicated backend status codes.
 * @param {unknown} error
 */
function summaryErrorMessage(error) {
  const status = error?.response?.status
  if (status === 429) return 'Your daily AI token budget is exhausted.'
  if (status === 503) return 'AI features are currently disabled by an administrator.'
  if (status === 403) return 'AI summaries are not enabled for your role.'
  return 'Couldn’t load the summary.'
}

export default InsightsPanel

