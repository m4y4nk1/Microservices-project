import { useEffect, useRef, useState } from 'react'
import { exportDiagram } from '../services/api'
import './ExportButton.css'

const OPTIONS = [
  { type: 'png', label: 'PNG image' },
  { type: 'pdf', label: 'PDF document' },
  { type: 'pptx', label: 'PowerPoint (PPTX)' },
]

/** Triggers a browser download for a Blob or data-URI string. */
function triggerDownload(source, filename) {
  const isString = typeof source === 'string'
  const url = isString ? source : URL.createObjectURL(source)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  if (!isString) URL.revokeObjectURL(url)
}

/**
 * Top-bar export control with a PNG / PDF / PPTX dropdown.
 * PNG is rendered client-side from the Cytoscape instance; PDF and PPTX are
 * produced by the backend via exportDiagram(type).
 *
 * @param {object} props
 * @param {() => object | null} props.getCy - Returns the live Cytoscape instance.
 * @param {(error: unknown) => void} [props.onError] - Called on export failure.
 */
function ExportButton({ getCy, onError }) {
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const rootRef = useRef(null)

  // Close the dropdown on outside click.
  useEffect(() => {
    const onDocMouseDown = (e) => {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onDocMouseDown)
    return () => document.removeEventListener('mousedown', onDocMouseDown)
  }, [])

  const handleExport = async (type) => {
    setOpen(false)

    if (type === 'png') {
      const cy = getCy?.()
      if (!cy) {
        onError?.(new Error('Graph is not ready to export.'))
        return
      }
      const uri = cy.png({ full: true, scale: 2, bg: '#ffffff' })
      triggerDownload(uri, 'ea-context-diagram.png')
      return
    }

    // PDF / PPTX are generated on the backend.
    setBusy(true)
    try {
      const blob = await exportDiagram(type)
      triggerDownload(blob, `ea-context-diagram.${type}`)
    } catch (err) {
      onError?.(err)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="export" ref={rootRef}>
      <button
        type="button"
        className="export-btn"
        disabled={busy}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
      >
        {busy ? 'Exporting…' : '⬇ Export'}
        <span className="export-caret" aria-hidden="true">▾</span>
      </button>
      {open && (
        <ul className="export-menu" role="menu">
          {OPTIONS.map((o) => (
            <li key={o.type} role="none">
              <button
                type="button"
                role="menuitem"
                className="export-item"
                onClick={() => handleExport(o.type)}
              >
                {o.label}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

export default ExportButton

