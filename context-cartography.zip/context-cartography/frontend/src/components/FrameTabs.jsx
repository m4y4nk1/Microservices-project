import './FrameTabs.css'

/**
 * The observation frames, mapped to the backend API slugs.
 * @see com.vw.eacontext.dto.Frame
 */
const FRAMES = [
  { slug: 'application', label: 'Application' },
  { slug: 'domain', label: 'Domain' },
  { slug: 'process', label: 'Process' },
  { slug: 'infoflow', label: 'Information Flow' },
]

/**
 * Row of tabs for switching the active observation frame.
 *
 * Controlled by the parent so the active frame can be corrected when the user's
 * permissions do not cover it. Frames the user may not view are hidden — the
 * backend rejects them with 403 regardless.
 *
 * @param {object} props
 * @param {string} props.activeFrame - Slug of the currently active frame.
 * @param {string[]} [props.allowedFrames] - Slugs the user is permitted to view.
 * @param {(frame: string) => void} [props.onFrameChange] - Called with the slug when the frame changes.
 */
function FrameTabs({ activeFrame = 'application', allowedFrames, onFrameChange }) {
  const visible = allowedFrames
    ? FRAMES.filter((f) => allowedFrames.includes(f.slug))
    : FRAMES

  const handleClick = (slug) => {
    if (slug === activeFrame) return
    onFrameChange?.(slug)
  }

  if (visible.length === 0) {
    return (
      <div className="frame-tabs frame-tabs--empty">
        No diagram frames are available for your role.
      </div>
    )
  }

  return (
    <div className="frame-tabs" role="tablist" aria-label="Observation frame">
      {visible.map(({ slug, label }) => {
        const isActive = slug === activeFrame
        return (
          <button
            key={slug}
            type="button"
            role="tab"
            aria-selected={isActive}
            className={`frame-tab${isActive ? ' frame-tab--active' : ''}`}
            onClick={() => handleClick(slug)}
          >
            {label}
          </button>
        )
      })}
    </div>
  )
}

export default FrameTabs

