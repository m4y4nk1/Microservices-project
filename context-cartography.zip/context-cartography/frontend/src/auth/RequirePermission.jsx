import { useAuth } from './AuthContext'

/**
 * Renders its children only when the user holds the required permission.
 *
 * Purely cosmetic: the backend enforces the same rule with @PreAuthorize.
 *
 * @param {object} props
 * @param {string} [props.perm] - A single required permission code.
 * @param {string[]} [props.anyOf] - Render if the user holds any of these.
 * @param {React.ReactNode} [props.fallback] - Rendered when not permitted.
 */
export default function RequirePermission({ perm, anyOf, fallback = null, children }) {
  const { can, canAny } = useAuth()
  const allowed = perm ? can(perm) : anyOf ? canAny(anyOf) : true
  return allowed ? children : fallback
}

