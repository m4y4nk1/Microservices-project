import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { login as loginRequest, logout as logoutRequest, getMe } from '../services/authApi'

const STORAGE_KEY = 'contexa_user'
const TOKEN_KEY = 'contexa_token'

const AuthContext = createContext(null)

/**
 * Access the current auth state.
 * @returns {{
 *   user: object|null,
 *   login: (email: string, password: string) => Promise<object>,
 *   logout: () => void,
 *   refresh: () => Promise<void>,
 *   can: (permission: string) => boolean,
 *   canAny: (permissions: string[]) => boolean,
 *   isAuthenticated: boolean,
 *   loading: boolean,
 *   error: unknown
 * }}
 */
export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>')
  return ctx
}

/**
 * Holds the authenticated user and exposes permission helpers.
 *
 * The permission list is used only to hide controls the user cannot use — the
 * backend re-checks every rule with @PreAuthorize, so this is UX, not security.
 */
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      return raw ? JSON.parse(raw) : null
    } catch {
      return null
    }
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const login = useCallback(async (email, password) => {
    setLoading(true)
    setError(null)
    try {
      const data = await loginRequest(email, password)
      localStorage.setItem(TOKEN_KEY, data.token)
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
      setUser(data)
      return data
    } catch (err) {
      setError(err)
      throw err
    } finally {
      setLoading(false)
    }
  }, [])

  const logout = useCallback(() => {
    logoutRequest()
    setUser(null)
    setError(null)
  }, [])

  /** Re-reads permissions from the server (e.g. after an admin changed them). */
  const refresh = useCallback(async () => {
    if (!localStorage.getItem(TOKEN_KEY)) return
    try {
      const me = await getMe()
      setUser((prev) => {
        const next = { ...(prev ?? {}), ...me }
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
        return next
      })
    } catch {
      // Token expired or revoked: drop the session.
      logout()
    }
  }, [logout])

  const value = useMemo(() => {
    const permissions = user?.permissions ?? []
    const can = (permission) => permissions.includes(permission)
    const canAny = (list) => (list ?? []).some((p) => permissions.includes(p))
    return {
      user,
      login,
      logout,
      refresh,
      can,
      canAny,
      isAuthenticated: Boolean(user),
      loading,
      error,
    }
  }, [user, login, logout, refresh, loading, error])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

