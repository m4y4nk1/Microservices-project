import api from './api';

/**
 * Contexa Admin console calls against /api/admin.
 * Every one of these is additionally permission-checked on the server.
 */

// ---- Users ---------------------------------------------------------------

/** @returns {Promise<Array<object>>} All users with role and permissions. */
export async function listUsers() {
  const { data } = await api.get('/admin/users');
  return data;
}

/**
 * Creates a user, or invites one when password is omitted.
 * @param {{name: string, email: string, password?: string, roleName: string}} payload
 */
export async function createUser(payload) {
  const { data } = await api.post('/admin/users', payload);
  return data;
}

/**
 * Updates a user's name, role and activation state.
 * @param {number} id
 * @param {{name: string, roleName: string, active: boolean}} payload
 */
export async function updateUser(id, payload) {
  const { data } = await api.put(`/admin/users/${id}`, payload);
  return data;
}

/** Re-assigns a user's role. */
export async function changeUserRole(id, roleName) {
  const { data } = await api.put(`/admin/users/${id}/role`, null, { params: { roleName } });
  return data;
}

/** Activates or deactivates a user. */
export async function setUserActive(id, active) {
  const { data } = await api.put(`/admin/users/${id}/active`, null, { params: { active } });
  return data;
}

/** @returns {Promise<string>} A one-time temporary password. */
export async function resetUserPassword(id) {
  const { data } = await api.post(`/admin/users/${id}/reset-password`);
  return data.temporaryPassword;
}

/** Permanently deletes a user. */
export async function deleteUser(id) {
  await api.delete(`/admin/users/${id}`);
}

// ---- Roles & permissions -------------------------------------------------

/** @returns {Promise<Array<object>>} All roles with their permissions. */
export async function listRoles() {
  const { data } = await api.get('/admin/roles');
  return data;
}

/** @returns {Promise<Array<object>>} The full permission catalogue. */
export async function listPermissions() {
  const { data } = await api.get('/admin/permissions');
  return data;
}

/**
 * Replaces a role's permission set.
 * @param {string} roleName
 * @param {string[]} permissions
 */
export async function updateRolePermissions(roleName, permissions) {
  const { data } = await api.put(`/admin/roles/${roleName}/permissions`, { permissions });
  return data;
}

// ---- AI settings ---------------------------------------------------------

/** @returns {Promise<object>} Current AI governance settings. */
export async function getAiSettings() {
  const { data } = await api.get('/admin/ai-settings');
  return data;
}

/** Persists new AI governance settings. */
export async function updateAiSettings(settings) {
  const { data } = await api.put('/admin/ai-settings', settings);
  return data;
}

// ---- Audit ---------------------------------------------------------------

/**
 * @param {{actor?: string, page?: number, size?: number}} [params]
 * @returns {Promise<Array<object>>} Audit entries, newest first.
 */
export async function getAuditLog(params = {}) {
  const { data } = await api.get('/admin/audit', { params });
  return data;
}

/** @returns {Promise<Array<object>>} AI-related audit entries only. */
export async function getAiAuditLog(params = {}) {
  const { data } = await api.get('/admin/audit/ai', { params });
  return data;
}

