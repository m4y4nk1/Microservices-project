import api, { TOKEN_KEY, USER_KEY } from './api';

/**
 * Authentication calls against /api/auth.
 */

/**
 * Exchanges credentials for an access token.
 * @param {string} email
 * @param {string} password
 * @returns {Promise<object>} Token, role and effective permissions.
 */
export async function login(email, password) {
  const { data } = await api.post('/auth/login', { email, password });
  return data;
}

/**
 * Returns the caller's identity and permissions from the server.
 * @returns {Promise<object>}
 */
export async function getMe() {
  const { data } = await api.get('/auth/me');
  return data;
}

/**
 * Replaces the caller's own password.
 * @param {string} currentPassword
 * @param {string} newPassword
 */
export async function changePassword(currentPassword, newPassword) {
  await api.post('/auth/change-password', { currentPassword, newPassword });
}

/** Clears the locally stored session. */
export function logout() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

