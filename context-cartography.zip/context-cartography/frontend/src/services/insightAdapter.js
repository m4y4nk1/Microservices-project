/**
 * Maps insight findings (from getInsights()) onto Cytoscape node CSS classes,
 * replicating the prototype's issue rings:
 *   - ownership gap        -> orange solid border   (.gap)
 *   - EOL / deprecated     -> red dashed border     (.eol)
 *   - dependency hotspot   -> gold dashed border    (.spof, single point of failure)
 */

/** FindingType -> node class name. Types without a ring are omitted. */
const FINDING_CLASS = {
  OWNERSHIP_GAP: 'gap',
  LIFECYCLE_RISK: 'eol',
  DEPENDENCY_HOTSPOT: 'spof',
}

/** All issue classes this adapter can assign (used to clear stale rings). */
export const ISSUE_CLASSES = ['gap', 'eol', 'spof']

/**
 * Builds a map of node id -> space-separated class string from findings.
 * A node can carry several rings (e.g. an unowned EOL app is both gap + eol).
 *
 * @param {Array<{type: string, entityId: string}>} [findings]
 * @returns {Record<string, string>} e.g. { "APP08": "eol", "APP01": "gap spof" }
 */
export function nodeClassesFromFindings(findings) {
  const byId = {}
  for (const finding of findings ?? []) {
    const cls = FINDING_CLASS[finding?.type]
    if (!cls || !finding.entityId) continue
    const existing = byId[finding.entityId]
    // Avoid duplicate class tokens.
    if (!existing) {
      byId[finding.entityId] = cls
    } else if (!existing.split(' ').includes(cls)) {
      byId[finding.entityId] = `${existing} ${cls}`
    }
  }
  return byId
}

