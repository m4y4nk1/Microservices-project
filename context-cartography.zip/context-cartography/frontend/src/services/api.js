import axios from 'axios';

/**
 * Shared Axios instance pointed at the EA context backend.
 */
const api = axios.create({
  baseURL: 'http://localhost:8080/api',
});

/** Storage keys shared with the auth layer. */
export const TOKEN_KEY = 'contexa_token';
export const USER_KEY = 'contexa_user';

/**
 * Attaches the bearer token to every outgoing request.
 */
api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

/**
 * Clears the session on 401 so the app falls back to the login screen.
 * 403 is left alone: the user is signed in, just not permitted.
 */
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error?.response?.status;
    const isLoginCall = error?.config?.url?.includes('/auth/login');
    if (status === 401 && !isLoginCall) {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
      window.dispatchEvent(new CustomEvent('contexa:unauthenticated'));
    }
    return Promise.reject(error);
  },
);

/**
 * Logs the error with a contextual label and rethrows it so callers can handle it.
 * @param {string} context - Human-readable description of the failed operation.
 * @param {unknown} error - The error thrown by Axios.
 */
function handleError(context, error) {
  const message = error?.response?.data ?? error?.message ?? error;
  console.error(`[api] ${context} failed:`, message);
  throw error;
}

/**
 * Uploads a dataset file (JSON, XLSX, or ZIP of CSVs) and returns the validation report.
 * @param {File} file - The dataset file to upload.
 * @returns {Promise<object>} The validation report.
 */
export async function uploadDataset(file) {
  try {
    const formData = new FormData();
    formData.append('file', file);
    const { data } = await api.post('/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return data;
  } catch (error) {
    handleError('uploadDataset', error);
  }
}

/**
 * Fetches the node/edge graph projection for the requested observation frame.
 * @param {string} frame - The frame slug.
 * @returns {Promise<object>} The graph DTO.
 */
export async function getGraph(frame) {
  try {
    const { data } = await api.get(`/graph/${encodeURIComponent(frame)}`);
    return data;
  } catch (error) {
    handleError('getGraph', error);
  }
}

/**
 * Fetches the blast radius (upstream + downstream impact) for a node.
 * @param {string} id - The node/application id.
 * @returns {Promise<object>} The impact analysis result.
 */
export async function getNodeImpact(id) {
  try {
    const { data } = await api.get(`/node/${encodeURIComponent(id)}/impact`);
    return data;
  } catch (error) {
    handleError('getNodeImpact', error);
  }
}

/**
 * Fetches all insight findings for the cached model.
 * @returns {Promise<Array<object>>} The list of findings.
 */
export async function getInsights() {
  try {
    const { data } = await api.get('/insights');
    return data;
  } catch (error) {
    handleError('getInsights', error);
  }
}

/**
 * Fetches a natural-language summary of the cached model.
 * @returns {Promise<object>} The summary response.
 */
export async function getSummary() {
  try {
    const { data } = await api.get('/summary');
    return data;
  } catch (error) {
    handleError('getSummary', error);
  }
}

/**
 * Exports the current landscape as a downloadable file (png, pdf, or pptx).
 * @param {string} type - The export format: 'png', 'pdf', or 'pptx'.
 * @returns {Promise<Blob>} The exported file as a Blob.
 */
export async function exportDiagram(type) {
  try {
    const { data } = await api.get('/export', {
      params: { type },
      responseType: 'blob',
    });
    return data;
  } catch (error) {
    handleError('exportDiagram', error);
  }
}

export default api;
export { api };

