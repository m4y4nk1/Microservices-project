/**
 * Converts the backend GraphDto (nodes/edges) into the element format that
 * Cytoscape expects: `{ data: { ... }, classes?: string }`.
 *
 * The backend does not emit presentation colors, so node colors are derived
 * from the domain here (matching the vanilla prototype's DOMAIN_COLORS).
 */

/** Known domain colors, ported from the prototype. */
const DOMAIN_COLORS = {
  Sales: '#2f77b4',
  Finance: '#2ca089',
  Operations: '#e0a95c',
  Analytics: '#8a63c7',
  Security: '#c0504d',
  Platform: '#4b8b3b',
}

/** Stable fallback palette for domains not present in DOMAIN_COLORS. */
const FALLBACK_PALETTE = [
  '#2f77b4', '#2ca089', '#e0a95c', '#8a63c7',
  '#c0504d', '#4b8b3b', '#4a90a4', '#b4739e',
]

const PROCESS_COLOR = '#0E4A47'
const INFO_OBJECT_COLOR = '#5b6472'

/**
 * Resolves a stable color for a domain, falling back to a hashed palette color.
 * @param {string} [domain]
 * @returns {string} A hex color.
 */
function colorForDomain(domain) {
  if (!domain) return INFO_OBJECT_COLOR
  if (DOMAIN_COLORS[domain]) return DOMAIN_COLORS[domain]
  let hash = 0
  for (let i = 0; i < domain.length; i += 1) {
    hash = (hash * 31 + domain.codePointAt(i)) >>> 0
  }
  return FALLBACK_PALETTE[hash % FALLBACK_PALETTE.length]
}

/**
 * Picks a node color based on its type/domain.
 * @param {object} node - A GraphNode from the backend.
 */
function colorForNode(node) {
  const data = node.data ?? {}
  switch (node.type) {
    case 'process':
      return PROCESS_COLOR
    case 'informationObject':
      return INFO_OBJECT_COLOR
    case 'domain':
      // Domain nodes carry no `domain` attr; derive from the plain name
      // (label is "Name (count)", id is the domain key).
      return colorForDomain(stripCount(node.label) || node.id)
    default:
      return colorForDomain(data.domain)
  }
}

/** Strips a trailing " (n)" suffix from a domain label. */
function stripCount(label) {
  return typeof label === 'string' ? label.replace(/\(\d+\)$/, '').trim() : label
}

/**
 * Converts a GraphDto into an array of Cytoscape elements.
 * @param {{ nodes?: Array<object>, edges?: Array<object> } | null | undefined} graph
 * @returns {Array<object>} Cytoscape elements (nodes first, then edges).
 */
export function toCytoscapeElements(graph) {
  if (!graph) return []

  const nodes = (graph.nodes ?? []).map((node) => ({
    data: {
      ...node.data,
      id: node.id,
      label: node.label,
      type: node.type,
      color: colorForNode(node),
    },
  }))

  const edges = (graph.edges ?? []).map((edge) => ({
    data: {
      ...edge.data,
      id: edge.id,
      source: edge.source,
      target: edge.target,
      label: edge.label,
      type: edge.type,
    },
  }))

  return [...nodes, ...edges]
}

export { DOMAIN_COLORS }

