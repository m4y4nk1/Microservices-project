import { useEffect, useState } from 'react'
import { useAuth } from '../auth/AuthContext'
import {
  changeUserRole,
  createUser,
  deleteUser,
  getAiSettings,
  getAuditLog,
  listPermissions,
  listRoles,
  listUsers,
  resetUserPassword,
  setUserActive,
  updateAiSettings,
  updateRolePermissions,
} from '../services/adminApi'
import './ContexaAdmin.css'

/**
 * The Contexa Admin console. Each tab is rendered only when the signed-in user
 * holds the corresponding permission; the server enforces the same rules.
 */
export default function ContexaAdmin({ onClose }) {
  const { can } = useAuth()

  const tabs = [
    { id: 'users', label: 'Users', perm: 'USER_MANAGE' },
    { id: 'roles', label: 'Roles', perm: 'ROLE_MANAGE' },
    { id: 'ai', label: 'AI Settings', perm: 'AI_CONFIG' },
    { id: 'audit', label: 'Audit', perm: 'AUDIT_VIEW' },
  ].filter((t) => can(t.perm))

  const [tab, setTab] = useState(tabs[0]?.id ?? null)

  if (tabs.length === 0) {
    return <div className="admin-denied">Access denied — you have no administration permissions.</div>
  }

  return (
    <div className="contexa-admin">
      <header className="admin-header">
        <h1>🛡️ Contexa Admin Console</h1>
        <button type="button" className="admin-close" onClick={onClose}>
          ← Back to diagram
        </button>
      </header>

      <nav className="admin-tabs">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            className={tab === t.id ? 'admin-tab active' : 'admin-tab'}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <div className="admin-body">
        {tab === 'users' && <UsersTab />}
        {tab === 'roles' && <RolesTab />}
        {tab === 'ai' && <AiTab />}
        {tab === 'audit' && <AuditTab />}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ Users */

function UsersTab() {
  const [users, setUsers] = useState([])
  const [roles, setRoles] = useState([])
  const [notice, setNotice] = useState(null)
  const [form, setForm] = useState({ name: '', email: '', password: '', roleName: 'VIEWER' })

  const reload = () => listUsers().then(setUsers).catch(() => setNotice('Failed to load users.'))

  useEffect(() => {
    reload()
    listRoles().then(setRoles).catch(() => {})
  }, [])

  const handleCreate = async (e) => {
    e.preventDefault()
    setNotice(null)
    try {
      await createUser({ ...form, password: form.password || undefined })
      setForm({ name: '', email: '', password: '', roleName: 'VIEWER' })
      setNotice('User created.')
      reload()
    } catch (err) {
      setNotice(err?.response?.data?.message ?? 'Could not create the user.')
    }
  }

  const handleReset = async (id) => {
    try {
      const temp = await resetUserPassword(id)
      setNotice(`Temporary password (shown once): ${temp}`)
      reload()
    } catch (err) {
      setNotice(err?.response?.data?.message ?? 'Password reset failed.')
    }
  }

  const guard = (promise) =>
    promise.then(reload).catch((err) =>
      setNotice(err?.response?.data?.message ?? 'Operation failed.'),
    )

  return (
    <div className="admin-panel">
      {notice && <div className="admin-notice">{notice}</div>}

      <form className="admin-form" onSubmit={handleCreate}>
        <h3>Add or invite a user</h3>
        <input
          placeholder="Full name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <input
          type="email"
          placeholder="email@company.com"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          required
        />
        <input
          type="password"
          placeholder="Password (blank = invite)"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />
        <select
          value={form.roleName}
          onChange={(e) => setForm({ ...form, roleName: e.target.value })}
        >
          {roles.map((r) => (
            <option key={r.id} value={r.name}>{r.name}</option>
          ))}
        </select>
        <button type="submit">Create</button>
      </form>

      <table className="admin-table">
        <thead>
          <tr>
            <th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last login</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td>{u.name}</td>
              <td>{u.email}</td>
              <td>
                <select
                  value={u.role ?? ''}
                  onChange={(e) => guard(changeUserRole(u.id, e.target.value))}
                >
                  {roles.map((r) => <option key={r.id} value={r.name}>{r.name}</option>)}
                </select>
              </td>
              <td>
                <span className={u.active ? 'pill pill-ok' : 'pill pill-off'}>
                  {u.active ? 'Active' : 'Disabled'}
                </span>
                {u.mustChangePassword && <span className="pill pill-warn">Pending</span>}
              </td>
              <td className="muted">
                {u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString() : '—'}
              </td>
              <td className="admin-actions">
                <button type="button" onClick={() => guard(setUserActive(u.id, !u.active))}>
                  {u.active ? 'Disable' : 'Enable'}
                </button>
                <button type="button" onClick={() => handleReset(u.id)}>Reset pw</button>
                <button type="button" className="danger" onClick={() => guard(deleteUser(u.id))}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

/* ------------------------------------------------------------------ Roles */

function RolesTab() {
  const [roles, setRoles] = useState([])
  const [permissions, setPermissions] = useState([])
  const [selected, setSelected] = useState(null)
  const [draft, setDraft] = useState([])
  const [notice, setNotice] = useState(null)

  useEffect(() => {
    listRoles().then(setRoles).catch(() => {})
    listPermissions().then(setPermissions).catch(() => {})
  }, [])

  const pick = (name) => {
    const role = roles.find((r) => r.name === name) ?? null
    setSelected(role)
    setDraft(role?.permissions ?? [])
    setNotice(null)
  }

  const toggle = (code) =>
    setDraft((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]))

  const save = async () => {
    try {
      const updated = await updateRolePermissions(selected.name, draft)
      setRoles((prev) => prev.map((r) => (r.name === updated.name ? updated : r)))
      setNotice(`Saved ${updated.name} (${updated.permissions.length} permissions).`)
    } catch (err) {
      setNotice(err?.response?.data?.message ?? 'Could not save the role.')
    }
  }

  const categories = [...new Set(permissions.map((p) => p.category))]

  return (
    <div className="admin-panel">
      {notice && <div className="admin-notice">{notice}</div>}

      <div className="role-picker">
        <label>
          Role
          <select value={selected?.name ?? ''} onChange={(e) => pick(e.target.value)}>
            <option value="">— select a role —</option>
            {roles.map((r) => (
              <option key={r.id} value={r.name}>
                {r.name} ({r.userCount} user{r.userCount === 1 ? '' : 's'})
              </option>
            ))}
          </select>
        </label>
        {selected && <p className="muted">{selected.description}</p>}
      </div>

      {selected && (
        <>
          {categories.map((cat) => (
            <fieldset key={cat} className="perm-group">
              <legend>{cat}</legend>
              <div className="perm-grid">
                {permissions.filter((p) => p.category === cat).map((p) => (
                  <label key={p.code} className="perm-item" title={p.description}>
                    <input
                      type="checkbox"
                      checked={draft.includes(p.code)}
                      onChange={() => toggle(p.code)}
                    />
                    <code>{p.code}</code>
                  </label>
                ))}
              </div>
            </fieldset>
          ))}
          <button type="button" className="primary" onClick={save}>
            Save {selected.name}
          </button>
        </>
      )}
    </div>
  )
}

/* ------------------------------------------------------------- AI settings */

function AiTab() {
  const [settings, setSettings] = useState(null)
  const [notice, setNotice] = useState(null)

  useEffect(() => {
    getAiSettings().then(setSettings).catch(() => setNotice('Failed to load AI settings.'))
  }, [])

  if (!settings) return <div className="admin-panel muted">Loading…</div>

  const set = (patch) => setSettings({ ...settings, ...patch })

  const save = async () => {
    try {
      setSettings(await updateAiSettings(settings))
      setNotice('AI settings saved.')
    } catch (err) {
      setNotice(err?.response?.data?.message ?? 'Could not save AI settings.')
    }
  }

  const toggles = [
    ['summaryEnabled', 'Landscape summary'],
    ['queryEnabled', 'Natural-language query'],
    ['enrichmentEnabled', 'Smart ingestion (AI mapping)'],
    ['recommendationEnabled', 'Remediation recommendations'],
    ['agentEnabled', 'Autonomous agent'],
  ]

  return (
    <div className="admin-panel">
      {notice && <div className="admin-notice">{notice}</div>}

      <label className="ai-row master">
        <input
          type="checkbox"
          checked={settings.aiEnabled}
          onChange={(e) => set({ aiEnabled: e.target.checked })}
        />
        <strong>Master AI switch</strong>
        <span className="muted">Disables every AI feature instantly.</span>
      </label>

      <label className="ai-row">
        Model
        <select value={settings.model} onChange={(e) => set({ model: e.target.value })}>
          <option value="gpt-4o-mini">gpt-4o-mini</option>
          <option value="gpt-4o">gpt-4o</option>
        </select>
      </label>

      <label className="ai-row">
        Daily token budget per user
        <input
          type="number"
          min="0"
          value={settings.dailyTokenBudgetPerUser}
          onChange={(e) => set({ dailyTokenBudgetPerUser: Number(e.target.value) })}
        />
        <span className="muted">0 = unlimited</span>
      </label>

      <fieldset className="perm-group">
        <legend>Feature toggles</legend>
        {toggles.map(([key, label]) => (
          <label key={key} className="ai-row">
            <input
              type="checkbox"
              checked={settings[key]}
              onChange={(e) => set({ [key]: e.target.checked })}
            />
            {label}
          </label>
        ))}
      </fieldset>

      <button type="button" className="primary" onClick={save}>Save AI settings</button>
    </div>
  )
}

/* ------------------------------------------------------------------ Audit */

function AuditTab() {
  const [entries, setEntries] = useState([])
  const [actor, setActor] = useState('')

  const load = () =>
    getAuditLog(actor ? { actor, size: 200 } : { size: 200 })
      .then(setEntries)
      .catch(() => setEntries([]))

  useEffect(() => { load() }, [])

  return (
    <div className="admin-panel">
      <div className="audit-filter">
        <input
          placeholder="Filter by actor email"
          value={actor}
          onChange={(e) => setActor(e.target.value)}
        />
        <button type="button" onClick={load}>Search</button>
      </div>

      <table className="admin-table">
        <thead>
          <tr><th>When</th><th>Actor</th><th>Action</th><th>Detail</th><th>Tokens</th><th>OK</th></tr>
        </thead>
        <tbody>
          {entries.map((e) => (
            <tr key={e.id}>
              <td className="muted">{new Date(e.createdAt).toLocaleString()}</td>
              <td>{e.actor}</td>
              <td><code>{e.action}</code></td>
              <td className="detail">{e.detail}</td>
              <td>{e.tokensUsed ?? '—'}</td>
              <td>{e.success ? '✓' : '✗'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

