import { useState } from 'react'
import { useAuth } from '../auth/AuthContext'
import './LoginPage.css'

/**
 * Credential screen shown whenever no valid session exists.
 */
export default function LoginPage() {
  const { login, loading } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [message, setMessage] = useState(null)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setMessage(null)
    try {
      await login(email.trim(), password)
    } catch (err) {
      const status = err?.response?.status
      setMessage(
        status === 401
          ? err?.response?.data?.message ?? 'Invalid email or password.'
          : 'Could not reach the server. Is the backend running?',
      )
    }
  }

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={handleSubmit}>
        <h1 className="login-title">Contexa</h1>
        <p className="login-subtitle">AI-Powered Enterprise Context Diagram Generator</p>

        <label className="login-field">
          <span>Email</span>
          <input
            type="email"
            autoComplete="username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>

        <label className="login-field">
          <span>Password</span>
          <input
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>

        {message && <div className="login-error" role="alert">{message}</div>}

        <button className="login-btn" type="submit" disabled={loading}>
          {loading ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </div>
  )
}

