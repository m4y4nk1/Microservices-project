import { useEffect, useMemo, useRef, useState } from 'react'
import FrameTabs from './components/FrameTabs'
import FilterPanel, { EMPTY_FILTERS } from './components/FilterPanel'
import ExportButton from './components/ExportButton'
import GraphCanvas from './components/GraphCanvas'
import InsightsPanel from './components/InsightsPanel'
import NodeDetail from './components/NodeDetail'
import Toast from './components/Toast'
import UploadButton from './components/UploadButton'
import LoginPage from './pages/LoginPage'
import ContexaAdmin from './pages/ContexaAdmin'
import RequirePermission from './auth/RequirePermission'
import { useAuth } from './auth/AuthContext'
import { useGraphData } from './hooks/useGraphData'
import { useInsights } from './hooks/useInsights'
import { useSummary } from './hooks/useSummary'
import { nodeClassesFromFindings } from './services/insightAdapter'
import './App.css'

/** Frame slug -> the permission required to view it. */
const FRAME_PERMISSIONS = {
  application: 'DIAGRAM_VIEW_APPLICATION',
  process: 'DIAGRAM_VIEW_PROCESS',
  domain: 'DIAGRAM_VIEW_DOMAIN',
  infoflow: 'DIAGRAM_VIEW_INFOFLOW',
}

function App() {
  const { user, isAuthenticated, logout, can, canAny } = useAuth()

  // First frame the user is actually allowed to see.
  const firstAllowedFrame = useMemo(
    () => Object.keys(FRAME_PERMISSIONS).find((f) => can(FRAME_PERMISSIONS[f])) ?? 'application',
    [can],
  )

  const [frame, setFrame] = useState(firstAllowedFrame)
  const [showAdmin, setShowAdmin] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)
  const { elements, loading, error: graphError } = useGraphData(frame, refreshKey)
  const { findings, loading: findingsLoading, error: findingsError } =
    useInsights(refreshKey, can('ANALYSIS_RISK'))
  const { summary, loading: summaryLoading, error: summaryError } =
    useSummary(refreshKey, can('AI_SUMMARY'))
  const [selectedNode, setSelectedNode] = useState(null)
  const [filters, setFilters] = useState(EMPTY_FILTERS)
  const [toast, setToast] = useState(null)
  // Holds the live Cytoscape instance for client-side PNG export.
  const cyRef = useRef(null)

  // Session expiry raised by the Axios interceptor.
  useEffect(() => {
    const onExpired = () => {
      logout()
      setToast({ variant: 'error', message: 'Your session expired. Please sign in again.' })
    }
    window.addEventListener('contexa:unauthenticated', onExpired)
    return () => window.removeEventListener('contexa:unauthenticated', onExpired)
  }, [logout])

  // Keep the active frame legal if permissions change.
  useEffect(() => {
    if (isAuthenticated && !can(FRAME_PERMISSIONS[frame])) {
      setFrame(firstAllowedFrame)
    }
  }, [isAuthenticated, can, frame, firstAllowedFrame])

  // Map node ids -> issue-ring classes (gap / eol / spof) from the findings.
  const nodeClasses = useMemo(
    () => nodeClassesFromFindings(findings),
    [findings],
  )

  // Distinct domains present among application nodes, for the filter dropdown.
  const domains = useMemo(() => {
    const set = new Set()
    for (const el of elements) {
      const d = el.data
      if (d && d.type === 'application' && d.domain) set.add(d.domain)
    }
    return [...set].sort()
  }, [elements])

  const handleFrameChange = (nextFrame) => {
    setFrame(nextFrame)
  }

  // After a successful upload, refresh all data and toast the validation result.
  const handleUploaded = (report) => {
    const issues = report?.issues ?? []
    const errors = issues.filter((i) => i.severity === 'ERROR').length
    const warnings = issues.filter((i) => i.severity === 'WARNING').length

    setSelectedNode(null)
    setFilters(EMPTY_FILTERS)
    setRefreshKey((k) => k + 1)

    setToast({
      variant: errors > 0 ? 'error' : issues.length > 0 ? 'warning' : 'success',
      message:
        `Dataset loaded — ${issues.length} validation issue${issues.length === 1 ? '' : 's'}` +
        (issues.length > 0 ? ` (${errors} error${errors === 1 ? '' : 's'}, ${warnings} warning${warnings === 1 ? '' : 's'}).` : '.'),
    })
  }

  const handleUploadError = () => {
    setToast({ variant: 'error', message: 'Upload failed. Please check the file and try again.' })
  }

  const handleExportError = () => {
    setToast({ variant: 'error', message: 'Export failed. Please try again.' })
  }

  // Not signed in -> credential screen only.
  if (!isAuthenticated) {
    return <LoginPage />
  }

  // Admin console takes over the whole viewport.
  if (showAdmin) {
    return <ContexaAdmin onClose={() => setShowAdmin(false)} />
  }

  const canAdminister = canAny(['USER_MANAGE', 'ROLE_MANAGE', 'AI_CONFIG', 'AUDIT_VIEW'])

  return (
    <div className="app">
      <header className="app-header">
        <h1 className="app-title">
          AI-Powered Enterprise Context Diagram Generator
        </h1>
        <div className="app-header-actions">
          <RequirePermission anyOf={['EXPORT_PNG', 'EXPORT_PDF', 'EXPORT_PPTX']}>
            <ExportButton getCy={() => cyRef.current} onError={handleExportError} />
          </RequirePermission>
          {canAdminister && (
            <button type="button" className="admin-link" onClick={() => setShowAdmin(true)}>
              🛡️ Contexa Admin
            </button>
          )}
          <span className="app-user" title={user?.email}>
            {user?.name ?? user?.email} · {user?.role}
          </span>
          <button type="button" className="logout-btn" onClick={logout}>
            Sign out
          </button>
        </div>
      </header>

      <div className="app-body">
        <aside className="control-panel" aria-label="Controls">
          <h2 className="panel-heading">Controls</h2>
          <RequirePermission
            perm="DATA_UPLOAD"
            fallback={<p className="panel-note">You have read-only access.</p>}
          >
            <UploadButton onUploaded={handleUploaded} onError={handleUploadError} />
          </RequirePermission>
          <FilterPanel
            filters={filters}
            onChange={setFilters}
            onReset={() => setFilters(EMPTY_FILTERS)}
            domains={domains}
            disabled={frame !== 'application'}
          />
        </aside>

        <main className="graph-canvas" aria-label="Graph canvas">
          <div className="frame-tabs-bar">
            <FrameTabs
              activeFrame={frame}
              onFrameChange={handleFrameChange}
              allowedFrames={Object.keys(FRAME_PERMISSIONS).filter((f) =>
                can(FRAME_PERMISSIONS[f]),
              )}
            />
          </div>
          <div className="graph-canvas-body">
            <GraphCanvas
              elements={elements}
              frame={frame}
              loading={loading}
              error={graphError}
              nodeClasses={nodeClasses}
              filters={filters}
              onNodeSelect={setSelectedNode}
              onReady={(cy) => {
                cyRef.current = cy
              }}
            />
          </div>
        </main>

        <aside className="insights-panel" aria-label="Insights">
          <h2 className="panel-heading">Insights</h2>
          <InsightsPanel
            summary={summary}
            summaryLoading={summaryLoading}
            summaryError={summaryError}
            findings={findings}
            findingsLoading={findingsLoading}
            findingsError={findingsError}
            canUseAiSummary={can('AI_SUMMARY')}
            canSeeFindings={can('ANALYSIS_RISK')}
          />
          <h3 className="insights-label">Selection</h3>
          <NodeDetail
            node={selectedNode}
            issueClasses={selectedNode ? nodeClasses[selectedNode.id] ?? '' : ''}
          />
        </aside>
      </div>

      {toast && (
        <Toast
          message={toast.message}
          variant={toast.variant}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  )
}

export default App
